function z = power(x,y)
% CADA overloaded POWER function: calls cadabinaryarraymath
z = cadabinaryarraymath(x,y,1,1,'power');