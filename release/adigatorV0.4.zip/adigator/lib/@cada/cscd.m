function y = cscd(x)
% CADA overloaded CSCD function: calls cadaunarymath
y = cadaunarymath(x,0,'cscd');