function y = log10(x)
% CADA overloaded LOG10 function: calls cadaunarymath
y = cadaunarymath(x,0,'log10');