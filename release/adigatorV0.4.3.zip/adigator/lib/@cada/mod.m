function z = mod(x,y)
% CADA overloaded MOD function: calls cadabinaryarraymath
z = cadabinaryarraymath(x,y,1,0,'mod');