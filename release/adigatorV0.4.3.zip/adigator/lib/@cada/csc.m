function y = csc(x)
% CADA overloaded CSC function: calls cadaunarymath
y = cadaunarymath(x,0,'csc');