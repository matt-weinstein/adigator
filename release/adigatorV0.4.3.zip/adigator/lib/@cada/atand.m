function y = atand(x)
% CADA overloaded ATAND function: calls cadaunarymath
y = cadaunarymath(x,1,'atand');