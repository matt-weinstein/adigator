function z = plus(x,y)
% CADA overloaded PLUS function: calls cadabinaryarraymath
z = cadabinaryarraymath(x,y,0,0,'plus');