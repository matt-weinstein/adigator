function y = sech(x)
% CADA overloaded SECH function: calls cadaunarymath
y = cadaunarymath(x,0,'sech');