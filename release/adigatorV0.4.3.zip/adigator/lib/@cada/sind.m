function y = sind(x)
% CADA overloaded SIND function: calls cadaunarymath
y = cadaunarymath(x,1,'sind');