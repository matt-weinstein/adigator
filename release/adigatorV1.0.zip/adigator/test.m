global mydata
mydata(1).v = 1;
mydata(2).v = 2;


n = 10;
adix = adigatorCreateDerivInput([n,1],'x');
% input2.x = adix;
% input2.a = a;
% input(1) = input2;
% input(2) = input2;
v = rand(n,1)+1;

a = rand(n/2,1);
A = diag(a);

%A = rand(n/2);

adigatorGenJacFile('myfun',{adix,A});
addpath '~/Dropbox/IntLab_V6/utility'
tic
for i = 1:11
gx = gradientinit(v);
gy = myfun(gx,A);
J1 = gy.dx;
end
toc
rmpath '~/Dropbox/IntLab_V6/utility'
tic
for i = 1:11
J2 = myfun_Jac(v,A);
end
toc

max(abs(J1(:)-J2(:)))
tic
for i = 1:11
mx = fmad(v,sparse(eye(n)));
my = myfun(mx,A);
end
toc
J3 = getinternalderivs(my);