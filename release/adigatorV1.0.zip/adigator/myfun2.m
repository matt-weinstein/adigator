function y = myfun2(x)

%xi.f = x;
%xi.dx = ones(size(xi.f));
a = 5;

input2.x.f = x;
input2.x.dx = ones(size(x));
input2.a.f = a;
input(1) = input2;
input(2) = input2;
w.a = 1;
w.b = 2;

z = myderiv(input,w);
y = z.dx;