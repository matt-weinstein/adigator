function y = myfun(x,a)

y = prod(x);