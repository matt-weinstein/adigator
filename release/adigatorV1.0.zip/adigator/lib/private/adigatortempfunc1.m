function [adigatorFunInfo, adigatorOutputs] = adigatortempfunc1(adigatorFunInfo,adigatorInputs)
[flag, adigatorFunInfo, adigatorInputs, adigatorDerivData] = adigatorFunctionInitialize(1,adigatorFunInfo,adigatorInputs);
if flag; adigatorOutputs = adigatorInputs; return; end;
Gator1Data = adigatorDerivData.Gator1Data;
input = adigatorInputs{1};
adigatorVarAnalyzer('%User Line: % phase 1: coast 1 state, no control');
adigatorVarAnalyzer('%User Line: % phase 2: burn  7 state components, 3 control components');
adigatorVarAnalyzer('%User Line: % phase 3: coast 1 state, no control');
adigatorVarAnalyzer('%User Line: % phase 4: burn  7 state components, 3 control components');
adigatorVarAnalyzer('%User Line: % phase 5: coast 1 state, no control');
adigatorVarAnalyzer('%User Line: % Isp     = input.auxdata.Isp;');
adigatorVarAnalyzer('%User Line: % g0      = input.auxdata.g0;');
adigatorVarAnalyzer('%User Line: % T       = input.auxdata.T;');
adigatorVarAnalyzer('%User Line: % mu      = input.auxdata.mu;');
adigatorVarAnalyzer('%User Line: % p0      = input.auxdata.p0;');
if ~exist('Isp','var'); Isp = cadastruct([],'Isp',[],0); end
Isp.f = input.auxdata.SCALEDIsp;
Isp = adigatorVarAnalyzer('Isp.f = input.auxdata.SCALEDIsp;',Isp,'Isp',1);
adigatorVarAnalyzer('%User Line: Isp     = input.auxdata.SCALEDIsp;');
if ~exist('g0','var'); g0 = cadastruct([],'g0',[],0); end
g0.f = input.auxdata.SCALEDg0;
g0 = adigatorVarAnalyzer('g0.f = input.auxdata.SCALEDg0;',g0,'g0',1);
adigatorVarAnalyzer('%User Line: g0      = input.auxdata.SCALEDg0;');
if ~exist('T','var'); T = cadastruct([],'T',[],0); end
T.f = input.auxdata.SCALEDT;
T = adigatorVarAnalyzer('T.f = input.auxdata.SCALEDT;',T,'T',1);
adigatorVarAnalyzer('%User Line: T       = input.auxdata.SCALEDT;');
if ~exist('mu','var'); mu = cadastruct([],'mu',[],0); end
mu.f = input.auxdata.SCALEDmu;
mu = adigatorVarAnalyzer('mu.f = input.auxdata.SCALEDmu;',mu,'mu',1);
adigatorVarAnalyzer('%User Line: mu      = input.auxdata.SCALEDmu;');
adigatorVarAnalyzer('%User Line: % Coast Phase');
if ~exist('cadaforvar1','var'); cadaforvar1 = cadastruct([],'cadaforvar1',[],0); end
cadaforvar1.f =  1:2:3;
cadaforvar1 = adigatorVarAnalyzer('cadaforvar1.f =  1:2:3;',cadaforvar1,'cadaforvar1',1);
adigatorVarAnalyzer('%User Line: cadaforvar1 = 1:2:3;');
if ~exist('output','var'); output = cadastruct([],'output',[],0); end
output(1,3).dynamics.dV = zeros(0,16);
output = adigatorVarAnalyzer('output(1,3).dynamics.dV = zeros(0,16);',output,'output',1);
if ~exist('output','var'); output = cadastruct([],'output',[],0); end
output(1,3).dynamics.f = zeros(0,4);
output = adigatorVarAnalyzer('output(1,3).dynamics.f = zeros(0,4);',output,'output',1);
if ~exist('output','var'); output = cadastruct([],'output',[],0); end
output(1,1).dynamics.dV = zeros(0,16);
output = adigatorVarAnalyzer('output(1,1).dynamics.dV = zeros(0,16);',output,'output',1);
if ~exist('output','var'); output = cadastruct([],'output',[],0); end
output(1,1).dynamics.f = zeros(0,4);
output = adigatorVarAnalyzer('output(1,1).dynamics.f = zeros(0,4);',output,'output',1);
% ADiGator FOR Statement #1: START
[adigatorForVariable1, adigatorForEvalStr, adigatorForEvalVar] = adigatorForInitialize(1,1:2,0);%#ok<NASGU>
if ~isempty(adigatorForEvalStr)
    adigatorSetCellEvalFlag(1); cellfun(@eval,adigatorForEvalStr); adigatorSetCellEvalFlag(0);
end
for adigatorForVariable1i = adigatorForVariable1
cadaforcount1 = adigatorForIterStart(1,adigatorForVariable1i);
    if ~exist('iphase','var'); iphase = cadastruct([],'iphase',[],0); end
    iphase.f = cadaforvar1.f(:,cadaforcount1);
    iphase = adigatorVarAnalyzer('iphase.f = cadaforvar1.f(:,cadaforcount1);',iphase,'iphase',1);
    adigatorVarAnalyzer('%User Line: iphase = cadaforvar1(:,cadaforcount1);');
    adigatorVarAnalyzer('%User Line: %Ldot4 = [];');
    cada1tempf1 = input.phase(iphase.f).state.f;
    cada1tempf1 = adigatorVarAnalyzer('cada1tempf1 = input.phase(iphase.f).state.f;',cada1tempf1,'cada1tempf1',0);
    cada1f1 = cada1tempf1;
    cada1f1 = adigatorVarAnalyzer('cada1f1 = cada1tempf1;',cada1f1,'cada1f1',0);
    cada1f2 = size(cada1f1,1);
    cada1f2 = adigatorVarAnalyzer('cada1f2 = size(cada1f1,1);',cada1f2,'cada1f2',0);
    if ~exist('Ldot4','var'); Ldot4 = cadastruct([],'Ldot4',[],0); end
    Ldot4.f = zeros(cada1f2,4);
    Ldot4 = adigatorVarAnalyzer('Ldot4.f = zeros(cada1f2,4);',Ldot4,'Ldot4',1);
    if ~exist('Ldot4','var'); Ldot4 = cadastruct([],'Ldot4',[],0); end
    Ldot4.dV = zeros(size(Ldot4.f,1),16);
    Ldot4 = adigatorVarAnalyzer('Ldot4.dV = zeros(size(Ldot4.f,1),16);',Ldot4,'Ldot4',1);
    adigatorVarAnalyzer('%User Line: Ldot4 = zeros(size(input.phase(iphase).state,1),4);');
    if ~exist('cadaforvar2','var'); cadaforvar2 = cadastruct([],'cadaforvar2',[],0); end
    cadaforvar2.f =  1:4;
    cadaforvar2 = adigatorVarAnalyzer('cadaforvar2.f =  1:4;',cadaforvar2,'cadaforvar2',1);
    adigatorVarAnalyzer('%User Line: cadaforvar2 = 1:4;');
    % ADiGator FOR Statement #2: START
    adigatorForVariable2 = adigatorForInitialize(2,1:4,0);
    for adigatorForVariable2i = adigatorForVariable2
    cadaforcount2 = adigatorForIterStart(2,adigatorForVariable2i);
        if ~exist('i','var'); i = cadastruct([],'i',[],0); end
        i.f = cadaforvar2.f(:,cadaforcount2);
        i = adigatorVarAnalyzer('i.f = cadaforvar2.f(:,cadaforcount2);',i,'i',1);
        adigatorVarAnalyzer('%User Line: i = cadaforvar2(:,cadaforcount2);');
        cada1tempf1 = input.phase(iphase.f).state.f;
        cada1tempf1 = adigatorVarAnalyzer('cada1tempf1 = input.phase(iphase.f).state.f;',cada1tempf1,'cada1tempf1',0);
        if ~exist('L','var'); L = cadastruct([],'L',[],0); end
        L.dV = input.phase(iphase.f).state.dV;
        L = adigatorVarAnalyzer('L.dV = input.phase(iphase.f).state.dV;',L,'L',1);
        if ~exist('L','var'); L = cadastruct([],'L',[],0); end
        L.f = cada1tempf1;
        L = adigatorVarAnalyzer('L.f = cada1tempf1;',L,'L',1);
        cada1td1 = zeros(size(L.f,1),4);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(L.f,1),4);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,logical(Gator1Data.Index1(:,cadaforcount2))) = L.dV(:,nonzeros(Gator1Data.Index1(:,cadaforcount2)));
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,logical(Gator1Data.Index1(:,cadaforcount2))) = L.dV(:,nonzeros(Gator1Data.Index1(:,cadaforcount2)));',cada1td1,'cada1td1',1);
        if ~exist('L','var'); L = cadastruct([],'L',[],0); end
        L.dV = cada1td1;
        L = adigatorVarAnalyzer('L.dV = cada1td1;',L,'L',1);
        if ~exist('L','var'); L = cadastruct([],'L',[],0); end
        L.f = L.f(:,i.f);
        L = adigatorVarAnalyzer('L.f = L.f(:,i.f);',L,'L',1);
        adigatorVarAnalyzer('%User Line: L     = input.phase(iphase).state(:,i);');
        cada1f1 = i.f - 1;
        cada1f1 = adigatorVarAnalyzer('cada1f1 = i.f - 1;',cada1f1,'cada1f1',0);
        cada1f2 = 3*cada1f1;
        cada1f2 = adigatorVarAnalyzer('cada1f2 = 3*cada1f1;',cada1f2,'cada1f2',0);
        cada1f3 = cada1f2 + 1;
        cada1f3 = adigatorVarAnalyzer('cada1f3 = cada1f2 + 1;',cada1f3,'cada1f3',0);
        cada1tempf1 = input.phase(iphase.f).parameter.f;
        cada1tempf1 = adigatorVarAnalyzer('cada1tempf1 = input.phase(iphase.f).parameter.f;',cada1tempf1,'cada1tempf1',0);
        if ~exist('p','var'); p = cadastruct([],'p',[],0); end
        p.dV = input.phase(iphase.f).parameter.dV;
        p = adigatorVarAnalyzer('p.dV = input.phase(iphase.f).parameter.dV;',p,'p',1);
        if ~exist('p','var'); p = cadastruct([],'p',[],0); end
        p.f = cada1tempf1;
        p = adigatorVarAnalyzer('p.f = cada1tempf1;',p,'p',1);
        cada1td1 = zeros(size(p.f,1),4);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(p.f,1),4);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,logical(Gator1Data.Index2(:,cadaforcount2))) = p.dV(:,nonzeros(Gator1Data.Index2(:,cadaforcount2)));
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,logical(Gator1Data.Index2(:,cadaforcount2))) = p.dV(:,nonzeros(Gator1Data.Index2(:,cadaforcount2)));',cada1td1,'cada1td1',1);
        if ~exist('p','var'); p = cadastruct([],'p',[],0); end
        p.dV = cada1td1;
        p = adigatorVarAnalyzer('p.dV = cada1td1;',p,'p',1);
        if ~exist('p','var'); p = cadastruct([],'p',[],0); end
        p.f = p.f(:,cada1f3);
        p = adigatorVarAnalyzer('p.f = p.f(:,cada1f3);',p,'p',1);
        adigatorVarAnalyzer('%User Line: p     = input.phase(iphase).parameter(:,3*(i-1) + 1);');
        cada1f1 = i.f - 1;
        cada1f1 = adigatorVarAnalyzer('cada1f1 = i.f - 1;',cada1f1,'cada1f1',0);
        cada1f2 = 3*cada1f1;
        cada1f2 = adigatorVarAnalyzer('cada1f2 = 3*cada1f1;',cada1f2,'cada1f2',0);
        cada1f3 = cada1f2 + 2;
        cada1f3 = adigatorVarAnalyzer('cada1f3 = cada1f2 + 2;',cada1f3,'cada1f3',0);
        cada1tempf1 = input.phase(iphase.f).parameter.f;
        cada1tempf1 = adigatorVarAnalyzer('cada1tempf1 = input.phase(iphase.f).parameter.f;',cada1tempf1,'cada1tempf1',0);
        if ~exist('P1','var'); P1 = cadastruct([],'P1',[],0); end
        P1.dV = input.phase(iphase.f).parameter.dV;
        P1 = adigatorVarAnalyzer('P1.dV = input.phase(iphase.f).parameter.dV;',P1,'P1',1);
        if ~exist('P1','var'); P1 = cadastruct([],'P1',[],0); end
        P1.f = cada1tempf1;
        P1 = adigatorVarAnalyzer('P1.f = cada1tempf1;',P1,'P1',1);
        cada1td1 = zeros(size(P1.f,1),4);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(P1.f,1),4);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,logical(Gator1Data.Index3(:,cadaforcount2))) = P1.dV(:,nonzeros(Gator1Data.Index3(:,cadaforcount2)));
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,logical(Gator1Data.Index3(:,cadaforcount2))) = P1.dV(:,nonzeros(Gator1Data.Index3(:,cadaforcount2)));',cada1td1,'cada1td1',1);
        if ~exist('P1','var'); P1 = cadastruct([],'P1',[],0); end
        P1.dV = cada1td1;
        P1 = adigatorVarAnalyzer('P1.dV = cada1td1;',P1,'P1',1);
        if ~exist('P1','var'); P1 = cadastruct([],'P1',[],0); end
        P1.f = P1.f(:,cada1f3);
        P1 = adigatorVarAnalyzer('P1.f = P1.f(:,cada1f3);',P1,'P1',1);
        adigatorVarAnalyzer('%User Line: P1    = input.phase(iphase).parameter(:,3*(i-1) + 2);');
        cada1f1 = i.f - 1;
        cada1f1 = adigatorVarAnalyzer('cada1f1 = i.f - 1;',cada1f1,'cada1f1',0);
        cada1f2 = 3*cada1f1;
        cada1f2 = adigatorVarAnalyzer('cada1f2 = 3*cada1f1;',cada1f2,'cada1f2',0);
        cada1f3 = cada1f2 + 3;
        cada1f3 = adigatorVarAnalyzer('cada1f3 = cada1f2 + 3;',cada1f3,'cada1f3',0);
        cada1tempf1 = input.phase(iphase.f).parameter.f;
        cada1tempf1 = adigatorVarAnalyzer('cada1tempf1 = input.phase(iphase.f).parameter.f;',cada1tempf1,'cada1tempf1',0);
        if ~exist('P2','var'); P2 = cadastruct([],'P2',[],0); end
        P2.dV = input.phase(iphase.f).parameter.dV;
        P2 = adigatorVarAnalyzer('P2.dV = input.phase(iphase.f).parameter.dV;',P2,'P2',1);
        if ~exist('P2','var'); P2 = cadastruct([],'P2',[],0); end
        P2.f = cada1tempf1;
        P2 = adigatorVarAnalyzer('P2.f = cada1tempf1;',P2,'P2',1);
        cada1td1 = zeros(size(P2.f,1),4);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(P2.f,1),4);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,logical(Gator1Data.Index4(:,cadaforcount2))) = P2.dV(:,nonzeros(Gator1Data.Index4(:,cadaforcount2)));
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,logical(Gator1Data.Index4(:,cadaforcount2))) = P2.dV(:,nonzeros(Gator1Data.Index4(:,cadaforcount2)));',cada1td1,'cada1td1',1);
        if ~exist('P2','var'); P2 = cadastruct([],'P2',[],0); end
        P2.dV = cada1td1;
        P2 = adigatorVarAnalyzer('P2.dV = cada1td1;',P2,'P2',1);
        if ~exist('P2','var'); P2 = cadastruct([],'P2',[],0); end
        P2.f = P2.f(:,cada1f3);
        P2 = adigatorVarAnalyzer('P2.f = P2.f(:,cada1f3);',P2,'P2',1);
        adigatorVarAnalyzer('%User Line: P2    = input.phase(iphase).parameter(:,3*(i-1) + 3);');
        adigatorVarAnalyzer('%User Line: %Ldot  = sqrt(mu*p)./p.^2.*(1+P1.*sin(L)+P2.*cos(L)).^2;');
        adigatorVarAnalyzer('%User Line: %Ldot4 = [Ldot4 Ldot];');
        cada1f1dV = mu.f.*p.dV;
        cada1f1dV = adigatorVarAnalyzer('cada1f1dV = mu.f.*p.dV;',cada1f1dV,'cada1f1dV',0);
        cada1f1 = mu.f*p.f;
        cada1f1 = adigatorVarAnalyzer('cada1f1 = mu.f*p.f;',cada1f1,'cada1f1',0);
        cada1tf1 = cada1f1(:,Gator1Data.Index25);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f1(:,Gator1Data.Index25);',cada1tf1,'cada1tf1',0);
        cada1f2dV = (1/2)./sqrt(cada1tf1).*cada1f1dV;
        cada1f2dV = adigatorVarAnalyzer('cada1f2dV = (1/2)./sqrt(cada1tf1).*cada1f1dV;',cada1f2dV,'cada1f2dV',0);
        if ~exist('cada1f2dV','var'); cada1f2dV = cadastruct([],'cada1f2dV',[],0); end
        cada1f2dV(cada1tf1 == 0 & cada1f1dV == 0) = 0;
        cada1f2dV = adigatorVarAnalyzer('cada1f2dV(cada1tf1 == 0 & cada1f1dV == 0) = 0;',cada1f2dV,'cada1f2dV',1);
        cada1f2 = sqrt(cada1f1);
        cada1f2 = adigatorVarAnalyzer('cada1f2 = sqrt(cada1f1);',cada1f2,'cada1f2',0);
        cada1tf2 = p.f(:,Gator1Data.Index26);
        cada1tf2 = adigatorVarAnalyzer('cada1tf2 = p.f(:,Gator1Data.Index26);',cada1tf2,'cada1tf2',0);
        cada1f3dV = 2.*cada1tf2.^(2-1).*p.dV;
        cada1f3dV = adigatorVarAnalyzer('cada1f3dV = 2.*cada1tf2.^(2-1).*p.dV;',cada1f3dV,'cada1f3dV',0);
        cada1f3 = p.f.^2;
        cada1f3 = adigatorVarAnalyzer('cada1f3 = p.f.^2;',cada1f3,'cada1f3',0);
        cada1tf1 = cada1f3(:,Gator1Data.Index27);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f3(:,Gator1Data.Index27);',cada1tf1,'cada1tf1',0);
        cada1td1 = cada1f2dV./cada1tf1;
        cada1td1 = adigatorVarAnalyzer('cada1td1 = cada1f2dV./cada1tf1;',cada1td1,'cada1td1',0);
        cada1tf1 = cada1f2(:,Gator1Data.Index28);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f2(:,Gator1Data.Index28);',cada1tf1,'cada1tf1',0);
        cada1tf2 = cada1f3(:,Gator1Data.Index29);
        cada1tf2 = adigatorVarAnalyzer('cada1tf2 = cada1f3(:,Gator1Data.Index29);',cada1tf2,'cada1tf2',0);
        cada1td1 = cada1td1 + -cada1tf1./cada1tf2.^2.*cada1f3dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1 = cada1td1 + -cada1tf1./cada1tf2.^2.*cada1f3dV;',cada1td1,'cada1td1',0);
        cada1f4dV = cada1td1;
        cada1f4dV = adigatorVarAnalyzer('cada1f4dV = cada1td1;',cada1f4dV,'cada1f4dV',0);
        cada1f4 = cada1f2./cada1f3;
        cada1f4 = adigatorVarAnalyzer('cada1f4 = cada1f2./cada1f3;',cada1f4,'cada1f4',0);
        cada1tf1 = L.f(:,Gator1Data.Index30);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = L.f(:,Gator1Data.Index30);',cada1tf1,'cada1tf1',0);
        cada1f5dV = cos(cada1tf1).*L.dV;
        cada1f5dV = adigatorVarAnalyzer('cada1f5dV = cos(cada1tf1).*L.dV;',cada1f5dV,'cada1f5dV',0);
        cada1f5 = sin(L.f);
        cada1f5 = adigatorVarAnalyzer('cada1f5 = sin(L.f);',cada1f5,'cada1f5',0);
        cada1tf1 = cada1f5(:,Gator1Data.Index31);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f5(:,Gator1Data.Index31);',cada1tf1,'cada1tf1',0);
        cada1td1 = zeros(size(P1.dV,1),8);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(P1.dV,1),8);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index32) = cada1tf1.*P1.dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index32) = cada1tf1.*P1.dV;',cada1td1,'cada1td1',1);
        cada1tf1 = P1.f(:,Gator1Data.Index33);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = P1.f(:,Gator1Data.Index33);',cada1tf1,'cada1tf1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index34) = cada1td1(:,Gator1Data.Index34) + cada1tf1.*cada1f5dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index34) = cada1td1(:,Gator1Data.Index34) + cada1tf1.*cada1f5dV;',cada1td1,'cada1td1',1);
        cada1f6dV = cada1td1;
        cada1f6dV = adigatorVarAnalyzer('cada1f6dV = cada1td1;',cada1f6dV,'cada1f6dV',0);
        cada1f6 = P1.f.*cada1f5;
        cada1f6 = adigatorVarAnalyzer('cada1f6 = P1.f.*cada1f5;',cada1f6,'cada1f6',0);
        cada1f7dV = cada1f6dV;
        cada1f7dV = adigatorVarAnalyzer('cada1f7dV = cada1f6dV;',cada1f7dV,'cada1f7dV',0);
        cada1f7 = 1 + cada1f6;
        cada1f7 = adigatorVarAnalyzer('cada1f7 = 1 + cada1f6;',cada1f7,'cada1f7',0);
        cada1tf1 = L.f(:,Gator1Data.Index35);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = L.f(:,Gator1Data.Index35);',cada1tf1,'cada1tf1',0);
        cada1f8dV = -sin(cada1tf1).*L.dV;
        cada1f8dV = adigatorVarAnalyzer('cada1f8dV = -sin(cada1tf1).*L.dV;',cada1f8dV,'cada1f8dV',0);
        cada1f8 = cos(L.f);
        cada1f8 = adigatorVarAnalyzer('cada1f8 = cos(L.f);',cada1f8,'cada1f8',0);
        cada1tf1 = cada1f8(:,Gator1Data.Index36);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f8(:,Gator1Data.Index36);',cada1tf1,'cada1tf1',0);
        cada1td1 = zeros(size(P2.dV,1),8);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(P2.dV,1),8);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index37) = cada1tf1.*P2.dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index37) = cada1tf1.*P2.dV;',cada1td1,'cada1td1',1);
        cada1tf1 = P2.f(:,Gator1Data.Index38);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = P2.f(:,Gator1Data.Index38);',cada1tf1,'cada1tf1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index39) = cada1td1(:,Gator1Data.Index39) + cada1tf1.*cada1f8dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index39) = cada1td1(:,Gator1Data.Index39) + cada1tf1.*cada1f8dV;',cada1td1,'cada1td1',1);
        cada1f9dV = cada1td1;
        cada1f9dV = adigatorVarAnalyzer('cada1f9dV = cada1td1;',cada1f9dV,'cada1f9dV',0);
        cada1f9 = P2.f.*cada1f8;
        cada1f9 = adigatorVarAnalyzer('cada1f9 = P2.f.*cada1f8;',cada1f9,'cada1f9',0);
        cada1td1 = zeros(size(cada1f7dV,1),12);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(cada1f7dV,1),12);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index40) = cada1f7dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index40) = cada1f7dV;',cada1td1,'cada1td1',1);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index41) = cada1td1(:,Gator1Data.Index41) + cada1f9dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index41) = cada1td1(:,Gator1Data.Index41) + cada1f9dV;',cada1td1,'cada1td1',1);
        cada1f10dV = cada1td1;
        cada1f10dV = adigatorVarAnalyzer('cada1f10dV = cada1td1;',cada1f10dV,'cada1f10dV',0);
        cada1f10 = cada1f7 + cada1f9;
        cada1f10 = adigatorVarAnalyzer('cada1f10 = cada1f7 + cada1f9;',cada1f10,'cada1f10',0);
        cada1tf2 = cada1f10(:,Gator1Data.Index42);
        cada1tf2 = adigatorVarAnalyzer('cada1tf2 = cada1f10(:,Gator1Data.Index42);',cada1tf2,'cada1tf2',0);
        cada1f11dV = 2.*cada1tf2.^(2-1).*cada1f10dV;
        cada1f11dV = adigatorVarAnalyzer('cada1f11dV = 2.*cada1tf2.^(2-1).*cada1f10dV;',cada1f11dV,'cada1f11dV',0);
        cada1f11 = cada1f10.^2;
        cada1f11 = adigatorVarAnalyzer('cada1f11 = cada1f10.^2;',cada1f11,'cada1f11',0);
        cada1tf1 = cada1f11(:,Gator1Data.Index43);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f11(:,Gator1Data.Index43);',cada1tf1,'cada1tf1',0);
        cada1td1 = zeros(size(cada1f4dV,1),16);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(cada1f4dV,1),16);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index44) = cada1tf1.*cada1f4dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index44) = cada1tf1.*cada1f4dV;',cada1td1,'cada1td1',1);
        cada1tf1 = cada1f4(:,Gator1Data.Index45);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f4(:,Gator1Data.Index45);',cada1tf1,'cada1tf1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index46) = cada1td1(:,Gator1Data.Index46) + cada1tf1.*cada1f11dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index46) = cada1td1(:,Gator1Data.Index46) + cada1tf1.*cada1f11dV;',cada1td1,'cada1td1',1);
        cada1f12dV = cada1td1;
        cada1f12dV = adigatorVarAnalyzer('cada1f12dV = cada1td1;',cada1f12dV,'cada1f12dV',0);
        cada1f12 = cada1f4.*cada1f11;
        cada1f12 = adigatorVarAnalyzer('cada1f12 = cada1f4.*cada1f11;',cada1f12,'cada1f12',0);
        if ~exist('Ldot4','var'); Ldot4 = cadastruct([],'Ldot4',[],0); end
        Ldot4.dV(:,logical(Gator1Data.Index5(:,cadaforcount2))) = cada1f12dV(:,nonzeros(Gator1Data.Index5(:,cadaforcount2)));
        Ldot4 = adigatorVarAnalyzer('Ldot4.dV(:,logical(Gator1Data.Index5(:,cadaforcount2))) = cada1f12dV(:,nonzeros(Gator1Data.Index5(:,cadaforcount2)));',Ldot4,'Ldot4',1);
        if ~exist('Ldot4','var'); Ldot4 = cadastruct([],'Ldot4',[],0); end
        Ldot4.f(:,i.f) = cada1f12;
        Ldot4 = adigatorVarAnalyzer('Ldot4.f(:,i.f) = cada1f12;',Ldot4,'Ldot4',1);
        adigatorVarAnalyzer('%User Line: Ldot4(:,i) = sqrt(mu*p)./p.^2.*(1+P1.*sin(L)+P2.*cos(L)).^2;');
    [adigatorForEvalStr, adigatorForEvalVar]= adigatorForIterEnd(2,adigatorForVariable2i);
    if ~isempty(adigatorForEvalStr)
        adigatorSetCellEvalFlag(1); cellfun(@eval,adigatorForEvalStr); adigatorSetCellEvalFlag(0);
    end
    end
    % ADiGator FOR Statement #2: END
    if ~exist('output','var'); output = cadastruct([],'output',[],0); end
    output(iphase.f).dynamics.dV = Ldot4.dV;
    output = adigatorVarAnalyzer('output(iphase.f).dynamics.dV = Ldot4.dV;',output,'output',1);
    if ~exist('output','var'); output = cadastruct([],'output',[],0); end
    output(iphase.f).dynamics.f = Ldot4.f;
    output = adigatorVarAnalyzer('output(iphase.f).dynamics.f = Ldot4.f;',output,'output',1);
    adigatorVarAnalyzer('%User Line: output(iphase).dynamics  = Ldot4;');
[adigatorForEvalStr, adigatorForEvalVar]= adigatorForIterEnd(1,adigatorForVariable1i);
if ~isempty(adigatorForEvalStr)
    adigatorSetCellEvalFlag(1); cellfun(@eval,adigatorForEvalStr); adigatorSetCellEvalFlag(0);
end
end
% ADiGator FOR Statement #1: END
adigatorVarAnalyzer('%User Line: % for iphase = 1:2:3');
adigatorVarAnalyzer('%User Line: %');
adigatorVarAnalyzer('%User Line: %     % Find weights and LGR points');
adigatorVarAnalyzer('%User Line: %');
adigatorVarAnalyzer('%User Line: %     N = 10; % Number of LGR Points');
adigatorVarAnalyzer('%User Line: %');
adigatorVarAnalyzer('%User Line: %     [tau, weights] = PointsWeightsLGRI(N);');
adigatorVarAnalyzer('%User Line: %');
adigatorVarAnalyzer('%User Line: %     for i = 1:4');
adigatorVarAnalyzer('%User Line: %');
adigatorVarAnalyzer('%User Line: %         p  = input.phase(iphase).parameter(:,5*(i-1) + 1);');
adigatorVarAnalyzer('%User Line: %         P1 = input.phase(iphase).parameter(:,5*(i-1) + 2);');
adigatorVarAnalyzer('%User Line: %         P2 = input.phase(iphase).parameter(:,5*(i-1) + 3);');
adigatorVarAnalyzer('%User Line: %         L0 = input.phase(iphase).parameter(:,5*(i-1) + 4);');
adigatorVarAnalyzer('%User Line: %         Lf = input.phase(iphase).parameter(:,5*(i-1) + 5);');
adigatorVarAnalyzer('%User Line: %');
adigatorVarAnalyzer('%User Line: %         Ldot  = @(L1) sqrt(mu*p)./p.^2.*(1+P1.*sin(L1)+P2.*cos(L1)).^2;');
adigatorVarAnalyzer('%User Line: %');
adigatorVarAnalyzer('%User Line: %         % Integrate Ldot using Gaussian Quadrature');
adigatorVarAnalyzer('%User Line: %');
adigatorVarAnalyzer('%User Line: %         integ = weights*Ldot(tau); % Integration from -1 to 1');
adigatorVarAnalyzer('%User Line: %');
adigatorVarAnalyzer('%User Line: %         % Scale integration from L0 to Lf');
adigatorVarAnalyzer('%User Line: %         L02Lf = (Lf - L0)/2 * integ ;');
adigatorVarAnalyzer('%User Line: %');
adigatorVarAnalyzer('%User Line: %     end');
adigatorVarAnalyzer('%User Line: % end');
adigatorVarAnalyzer('%User Line: % Burn Phase');
if ~exist('cadaforvar3','var'); cadaforvar3 = cadastruct([],'cadaforvar3',[],0); end
cadaforvar3.f =  2:2:4;
cadaforvar3 = adigatorVarAnalyzer('cadaforvar3.f =  2:2:4;',cadaforvar3,'cadaforvar3',1);
adigatorVarAnalyzer('%User Line: cadaforvar3 = 2:2:4;');
if ~exist('output','var'); output = cadastruct([],'output',[],0); end
output(1,4).path.dV = zeros(0,12);
output = adigatorVarAnalyzer('output(1,4).path.dV = zeros(0,12);',output,'output',1);
if ~exist('output','var'); output = cadastruct([],'output',[],0); end
output(1,4).path.f = zeros(0,4);
output = adigatorVarAnalyzer('output(1,4).path.f = zeros(0,4);',output,'output',1);
if ~exist('output','var'); output = cadastruct([],'output',[],0); end
output(1,2).path.dV = zeros(0,12);
output = adigatorVarAnalyzer('output(1,2).path.dV = zeros(0,12);',output,'output',1);
if ~exist('output','var'); output = cadastruct([],'output',[],0); end
output(1,2).path.f = zeros(0,4);
output = adigatorVarAnalyzer('output(1,2).path.f = zeros(0,4);',output,'output',1);
if ~exist('output','var'); output = cadastruct([],'output',[],0); end
output(1,4).dynamics.dV = zeros(0,196);
output = adigatorVarAnalyzer('output(1,4).dynamics.dV = zeros(0,196);',output,'output',1);
if ~exist('output','var'); output = cadastruct([],'output',[],0); end
output(1,4).dynamics.f = zeros(0,28);
output = adigatorVarAnalyzer('output(1,4).dynamics.f = zeros(0,28);',output,'output',1);
if ~exist('output','var'); output = cadastruct([],'output',[],0); end
output(1,2).dynamics.dV = zeros(0,196);
output = adigatorVarAnalyzer('output(1,2).dynamics.dV = zeros(0,196);',output,'output',1);
if ~exist('output','var'); output = cadastruct([],'output',[],0); end
output(1,2).dynamics.f = zeros(0,28);
output = adigatorVarAnalyzer('output(1,2).dynamics.f = zeros(0,28);',output,'output',1);
% ADiGator FOR Statement #3: START
[adigatorForVariable3, adigatorForEvalStr, adigatorForEvalVar] = adigatorForInitialize(3,1:2,0);%#ok<NASGU>
if ~isempty(adigatorForEvalStr)
    adigatorSetCellEvalFlag(1); cellfun(@eval,adigatorForEvalStr); adigatorSetCellEvalFlag(0);
end
for adigatorForVariable3i = adigatorForVariable3
cadaforcount3 = adigatorForIterStart(3,adigatorForVariable3i);
    if ~exist('iphase','var'); iphase = cadastruct([],'iphase',[],0); end
    iphase.f = cadaforvar3.f(:,cadaforcount3);
    iphase = adigatorVarAnalyzer('iphase.f = cadaforvar3.f(:,cadaforcount3);',iphase,'iphase',1);
    adigatorVarAnalyzer('%User Line: iphase = cadaforvar3(:,cadaforcount3);');
    cada1tempf1 = input.phase(iphase.f).time.f;
    cada1tempf1 = adigatorVarAnalyzer('cada1tempf1 = input.phase(iphase.f).time.f;',cada1tempf1,'cada1tempf1',0);
    if ~exist('t','var'); t = cadastruct([],'t',[],0); end
    t.dV = input.phase(iphase.f).time.dV;
    t = adigatorVarAnalyzer('t.dV = input.phase(iphase.f).time.dV;',t,'t',1);
    if ~exist('t','var'); t = cadastruct([],'t',[],0); end
    t.f = cada1tempf1;
    t = adigatorVarAnalyzer('t.f = cada1tempf1;',t,'t',1);
    adigatorVarAnalyzer('%User Line: t  = input.phase(iphase).time;');
    adigatorVarAnalyzer('%User Line: %path4 = [];');
    adigatorVarAnalyzer('%User Line: %dyna4 = [];');
    cada1f1 = length(t.f);
    cada1f1 = adigatorVarAnalyzer('cada1f1 = length(t.f);',cada1f1,'cada1f1',0);
    if ~exist('path4','var'); path4 = cadastruct([],'path4',[],0); end
    path4.f = zeros(cada1f1,4);
    path4 = adigatorVarAnalyzer('path4.f = zeros(cada1f1,4);',path4,'path4',1);
    if ~exist('path4','var'); path4 = cadastruct([],'path4',[],0); end
    path4.dV = zeros(size(path4.f,1),12);
    path4 = adigatorVarAnalyzer('path4.dV = zeros(size(path4.f,1),12);',path4,'path4',1);
    adigatorVarAnalyzer('%User Line: path4 = zeros(length(t),4);');
    cada1f1 = length(t.f);
    cada1f1 = adigatorVarAnalyzer('cada1f1 = length(t.f);',cada1f1,'cada1f1',0);
    if ~exist('dyna4','var'); dyna4 = cadastruct([],'dyna4',[],0); end
    dyna4.f = zeros(cada1f1,28);
    dyna4 = adigatorVarAnalyzer('dyna4.f = zeros(cada1f1,28);',dyna4,'dyna4',1);
    if ~exist('dyna4','var'); dyna4 = cadastruct([],'dyna4',[],0); end
    dyna4.dV = zeros(size(dyna4.f,1),196);
    dyna4 = adigatorVarAnalyzer('dyna4.dV = zeros(size(dyna4.f,1),196);',dyna4,'dyna4',1);
    adigatorVarAnalyzer('%User Line: dyna4 = zeros(length(t),28);');
    if ~exist('cadaforvar4','var'); cadaforvar4 = cadastruct([],'cadaforvar4',[],0); end
    cadaforvar4.f =  1:4;
    cadaforvar4 = adigatorVarAnalyzer('cadaforvar4.f =  1:4;',cadaforvar4,'cadaforvar4',1);
    adigatorVarAnalyzer('%User Line: cadaforvar4 = 1:4;');
    % ADiGator FOR Statement #4: START
    adigatorForVariable4 = adigatorForInitialize(4,1:4,0);
    for adigatorForVariable4i = adigatorForVariable4
    cadaforcount4 = adigatorForIterStart(4,adigatorForVariable4i);
        if ~exist('i','var'); i = cadastruct([],'i',[],0); end
        i.f = cadaforvar4.f(:,cadaforcount4);
        i = adigatorVarAnalyzer('i.f = cadaforvar4.f(:,cadaforcount4);',i,'i',1);
        adigatorVarAnalyzer('%User Line: i = cadaforvar4(:,cadaforcount4);');
        cada1f1 = i.f - 1;
        cada1f1 = adigatorVarAnalyzer('cada1f1 = i.f - 1;',cada1f1,'cada1f1',0);
        cada1f2 = 7*cada1f1;
        cada1f2 = adigatorVarAnalyzer('cada1f2 = 7*cada1f1;',cada1f2,'cada1f2',0);
        cada1f3 = cada1f2 + 1;
        cada1f3 = adigatorVarAnalyzer('cada1f3 = cada1f2 + 1;',cada1f3,'cada1f3',0);
        cada1tempf1 = input.phase(iphase.f).state.f;
        cada1tempf1 = adigatorVarAnalyzer('cada1tempf1 = input.phase(iphase.f).state.f;',cada1tempf1,'cada1tempf1',0);
        if ~exist('p','var'); p = cadastruct([],'p',[],0); end
        p.dV = input.phase(iphase.f).state.dV;
        p = adigatorVarAnalyzer('p.dV = input.phase(iphase.f).state.dV;',p,'p',1);
        if ~exist('p','var'); p = cadastruct([],'p',[],0); end
        p.f = cada1tempf1;
        p = adigatorVarAnalyzer('p.f = cada1tempf1;',p,'p',1);
        cada1td1 = zeros(size(p.f,1),4);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(p.f,1),4);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,logical(Gator1Data.Index6(:,cadaforcount4))) = p.dV(:,nonzeros(Gator1Data.Index6(:,cadaforcount4)));
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,logical(Gator1Data.Index6(:,cadaforcount4))) = p.dV(:,nonzeros(Gator1Data.Index6(:,cadaforcount4)));',cada1td1,'cada1td1',1);
        if ~exist('p','var'); p = cadastruct([],'p',[],0); end
        p.dV = cada1td1;
        p = adigatorVarAnalyzer('p.dV = cada1td1;',p,'p',1);
        if ~exist('p','var'); p = cadastruct([],'p',[],0); end
        p.f = p.f(:,cada1f3);
        p = adigatorVarAnalyzer('p.f = p.f(:,cada1f3);',p,'p',1);
        adigatorVarAnalyzer('%User Line: p  = input.phase(iphase).state(:, 7*(i-1) + 1);');
        cada1f1 = i.f - 1;
        cada1f1 = adigatorVarAnalyzer('cada1f1 = i.f - 1;',cada1f1,'cada1f1',0);
        cada1f2 = 7*cada1f1;
        cada1f2 = adigatorVarAnalyzer('cada1f2 = 7*cada1f1;',cada1f2,'cada1f2',0);
        cada1f3 = cada1f2 + 2;
        cada1f3 = adigatorVarAnalyzer('cada1f3 = cada1f2 + 2;',cada1f3,'cada1f3',0);
        cada1tempf1 = input.phase(iphase.f).state.f;
        cada1tempf1 = adigatorVarAnalyzer('cada1tempf1 = input.phase(iphase.f).state.f;',cada1tempf1,'cada1tempf1',0);
        if ~exist('P1','var'); P1 = cadastruct([],'P1',[],0); end
        P1.dV = input.phase(iphase.f).state.dV;
        P1 = adigatorVarAnalyzer('P1.dV = input.phase(iphase.f).state.dV;',P1,'P1',1);
        if ~exist('P1','var'); P1 = cadastruct([],'P1',[],0); end
        P1.f = cada1tempf1;
        P1 = adigatorVarAnalyzer('P1.f = cada1tempf1;',P1,'P1',1);
        cada1td1 = zeros(size(P1.f,1),4);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(P1.f,1),4);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,logical(Gator1Data.Index7(:,cadaforcount4))) = P1.dV(:,nonzeros(Gator1Data.Index7(:,cadaforcount4)));
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,logical(Gator1Data.Index7(:,cadaforcount4))) = P1.dV(:,nonzeros(Gator1Data.Index7(:,cadaforcount4)));',cada1td1,'cada1td1',1);
        if ~exist('P1','var'); P1 = cadastruct([],'P1',[],0); end
        P1.dV = cada1td1;
        P1 = adigatorVarAnalyzer('P1.dV = cada1td1;',P1,'P1',1);
        if ~exist('P1','var'); P1 = cadastruct([],'P1',[],0); end
        P1.f = P1.f(:,cada1f3);
        P1 = adigatorVarAnalyzer('P1.f = P1.f(:,cada1f3);',P1,'P1',1);
        adigatorVarAnalyzer('%User Line: P1 = input.phase(iphase).state(:, 7*(i-1) + 2);');
        cada1f1 = i.f - 1;
        cada1f1 = adigatorVarAnalyzer('cada1f1 = i.f - 1;',cada1f1,'cada1f1',0);
        cada1f2 = 7*cada1f1;
        cada1f2 = adigatorVarAnalyzer('cada1f2 = 7*cada1f1;',cada1f2,'cada1f2',0);
        cada1f3 = cada1f2 + 3;
        cada1f3 = adigatorVarAnalyzer('cada1f3 = cada1f2 + 3;',cada1f3,'cada1f3',0);
        cada1tempf1 = input.phase(iphase.f).state.f;
        cada1tempf1 = adigatorVarAnalyzer('cada1tempf1 = input.phase(iphase.f).state.f;',cada1tempf1,'cada1tempf1',0);
        if ~exist('P2','var'); P2 = cadastruct([],'P2',[],0); end
        P2.dV = input.phase(iphase.f).state.dV;
        P2 = adigatorVarAnalyzer('P2.dV = input.phase(iphase.f).state.dV;',P2,'P2',1);
        if ~exist('P2','var'); P2 = cadastruct([],'P2',[],0); end
        P2.f = cada1tempf1;
        P2 = adigatorVarAnalyzer('P2.f = cada1tempf1;',P2,'P2',1);
        cada1td1 = zeros(size(P2.f,1),4);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(P2.f,1),4);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,logical(Gator1Data.Index8(:,cadaforcount4))) = P2.dV(:,nonzeros(Gator1Data.Index8(:,cadaforcount4)));
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,logical(Gator1Data.Index8(:,cadaforcount4))) = P2.dV(:,nonzeros(Gator1Data.Index8(:,cadaforcount4)));',cada1td1,'cada1td1',1);
        if ~exist('P2','var'); P2 = cadastruct([],'P2',[],0); end
        P2.dV = cada1td1;
        P2 = adigatorVarAnalyzer('P2.dV = cada1td1;',P2,'P2',1);
        if ~exist('P2','var'); P2 = cadastruct([],'P2',[],0); end
        P2.f = P2.f(:,cada1f3);
        P2 = adigatorVarAnalyzer('P2.f = P2.f(:,cada1f3);',P2,'P2',1);
        adigatorVarAnalyzer('%User Line: P2 = input.phase(iphase).state(:, 7*(i-1) + 3);');
        cada1f1 = i.f - 1;
        cada1f1 = adigatorVarAnalyzer('cada1f1 = i.f - 1;',cada1f1,'cada1f1',0);
        cada1f2 = 7*cada1f1;
        cada1f2 = adigatorVarAnalyzer('cada1f2 = 7*cada1f1;',cada1f2,'cada1f2',0);
        cada1f3 = cada1f2 + 4;
        cada1f3 = adigatorVarAnalyzer('cada1f3 = cada1f2 + 4;',cada1f3,'cada1f3',0);
        cada1tempf1 = input.phase(iphase.f).state.f;
        cada1tempf1 = adigatorVarAnalyzer('cada1tempf1 = input.phase(iphase.f).state.f;',cada1tempf1,'cada1tempf1',0);
        if ~exist('Q1','var'); Q1 = cadastruct([],'Q1',[],0); end
        Q1.dV = input.phase(iphase.f).state.dV;
        Q1 = adigatorVarAnalyzer('Q1.dV = input.phase(iphase.f).state.dV;',Q1,'Q1',1);
        if ~exist('Q1','var'); Q1 = cadastruct([],'Q1',[],0); end
        Q1.f = cada1tempf1;
        Q1 = adigatorVarAnalyzer('Q1.f = cada1tempf1;',Q1,'Q1',1);
        cada1td1 = zeros(size(Q1.f,1),4);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(Q1.f,1),4);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,logical(Gator1Data.Index9(:,cadaforcount4))) = Q1.dV(:,nonzeros(Gator1Data.Index9(:,cadaforcount4)));
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,logical(Gator1Data.Index9(:,cadaforcount4))) = Q1.dV(:,nonzeros(Gator1Data.Index9(:,cadaforcount4)));',cada1td1,'cada1td1',1);
        if ~exist('Q1','var'); Q1 = cadastruct([],'Q1',[],0); end
        Q1.dV = cada1td1;
        Q1 = adigatorVarAnalyzer('Q1.dV = cada1td1;',Q1,'Q1',1);
        if ~exist('Q1','var'); Q1 = cadastruct([],'Q1',[],0); end
        Q1.f = Q1.f(:,cada1f3);
        Q1 = adigatorVarAnalyzer('Q1.f = Q1.f(:,cada1f3);',Q1,'Q1',1);
        adigatorVarAnalyzer('%User Line: Q1 = input.phase(iphase).state(:, 7*(i-1) + 4);');
        cada1f1 = i.f - 1;
        cada1f1 = adigatorVarAnalyzer('cada1f1 = i.f - 1;',cada1f1,'cada1f1',0);
        cada1f2 = 7*cada1f1;
        cada1f2 = adigatorVarAnalyzer('cada1f2 = 7*cada1f1;',cada1f2,'cada1f2',0);
        cada1f3 = cada1f2 + 5;
        cada1f3 = adigatorVarAnalyzer('cada1f3 = cada1f2 + 5;',cada1f3,'cada1f3',0);
        cada1tempf1 = input.phase(iphase.f).state.f;
        cada1tempf1 = adigatorVarAnalyzer('cada1tempf1 = input.phase(iphase.f).state.f;',cada1tempf1,'cada1tempf1',0);
        if ~exist('Q2','var'); Q2 = cadastruct([],'Q2',[],0); end
        Q2.dV = input.phase(iphase.f).state.dV;
        Q2 = adigatorVarAnalyzer('Q2.dV = input.phase(iphase.f).state.dV;',Q2,'Q2',1);
        if ~exist('Q2','var'); Q2 = cadastruct([],'Q2',[],0); end
        Q2.f = cada1tempf1;
        Q2 = adigatorVarAnalyzer('Q2.f = cada1tempf1;',Q2,'Q2',1);
        cada1td1 = zeros(size(Q2.f,1),4);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(Q2.f,1),4);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,logical(Gator1Data.Index10(:,cadaforcount4))) = Q2.dV(:,nonzeros(Gator1Data.Index10(:,cadaforcount4)));
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,logical(Gator1Data.Index10(:,cadaforcount4))) = Q2.dV(:,nonzeros(Gator1Data.Index10(:,cadaforcount4)));',cada1td1,'cada1td1',1);
        if ~exist('Q2','var'); Q2 = cadastruct([],'Q2',[],0); end
        Q2.dV = cada1td1;
        Q2 = adigatorVarAnalyzer('Q2.dV = cada1td1;',Q2,'Q2',1);
        if ~exist('Q2','var'); Q2 = cadastruct([],'Q2',[],0); end
        Q2.f = Q2.f(:,cada1f3);
        Q2 = adigatorVarAnalyzer('Q2.f = Q2.f(:,cada1f3);',Q2,'Q2',1);
        adigatorVarAnalyzer('%User Line: Q2 = input.phase(iphase).state(:, 7*(i-1) + 5);');
        cada1f1 = i.f - 1;
        cada1f1 = adigatorVarAnalyzer('cada1f1 = i.f - 1;',cada1f1,'cada1f1',0);
        cada1f2 = 7*cada1f1;
        cada1f2 = adigatorVarAnalyzer('cada1f2 = 7*cada1f1;',cada1f2,'cada1f2',0);
        cada1f3 = cada1f2 + 6;
        cada1f3 = adigatorVarAnalyzer('cada1f3 = cada1f2 + 6;',cada1f3,'cada1f3',0);
        cada1tempf1 = input.phase(iphase.f).state.f;
        cada1tempf1 = adigatorVarAnalyzer('cada1tempf1 = input.phase(iphase.f).state.f;',cada1tempf1,'cada1tempf1',0);
        if ~exist('L','var'); L = cadastruct([],'L',[],0); end
        L.dV = input.phase(iphase.f).state.dV;
        L = adigatorVarAnalyzer('L.dV = input.phase(iphase.f).state.dV;',L,'L',1);
        if ~exist('L','var'); L = cadastruct([],'L',[],0); end
        L.f = cada1tempf1;
        L = adigatorVarAnalyzer('L.f = cada1tempf1;',L,'L',1);
        cada1td1 = zeros(size(L.f,1),4);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(L.f,1),4);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,logical(Gator1Data.Index11(:,cadaforcount4))) = L.dV(:,nonzeros(Gator1Data.Index11(:,cadaforcount4)));
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,logical(Gator1Data.Index11(:,cadaforcount4))) = L.dV(:,nonzeros(Gator1Data.Index11(:,cadaforcount4)));',cada1td1,'cada1td1',1);
        if ~exist('L','var'); L = cadastruct([],'L',[],0); end
        L.dV = cada1td1;
        L = adigatorVarAnalyzer('L.dV = cada1td1;',L,'L',1);
        if ~exist('L','var'); L = cadastruct([],'L',[],0); end
        L.f = L.f(:,cada1f3);
        L = adigatorVarAnalyzer('L.f = L.f(:,cada1f3);',L,'L',1);
        adigatorVarAnalyzer('%User Line: L  = input.phase(iphase).state(:, 7*(i-1) + 6);');
        cada1f1 = i.f - 1;
        cada1f1 = adigatorVarAnalyzer('cada1f1 = i.f - 1;',cada1f1,'cada1f1',0);
        cada1f2 = 7*cada1f1;
        cada1f2 = adigatorVarAnalyzer('cada1f2 = 7*cada1f1;',cada1f2,'cada1f2',0);
        cada1f3 = cada1f2 + 7;
        cada1f3 = adigatorVarAnalyzer('cada1f3 = cada1f2 + 7;',cada1f3,'cada1f3',0);
        cada1tempf1 = input.phase(iphase.f).state.f;
        cada1tempf1 = adigatorVarAnalyzer('cada1tempf1 = input.phase(iphase.f).state.f;',cada1tempf1,'cada1tempf1',0);
        if ~exist('m','var'); m = cadastruct([],'m',[],0); end
        m.dV = input.phase(iphase.f).state.dV;
        m = adigatorVarAnalyzer('m.dV = input.phase(iphase.f).state.dV;',m,'m',1);
        if ~exist('m','var'); m = cadastruct([],'m',[],0); end
        m.f = cada1tempf1;
        m = adigatorVarAnalyzer('m.f = cada1tempf1;',m,'m',1);
        cada1td1 = zeros(size(m.f,1),4);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(m.f,1),4);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,logical(Gator1Data.Index12(:,cadaforcount4))) = m.dV(:,nonzeros(Gator1Data.Index12(:,cadaforcount4)));
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,logical(Gator1Data.Index12(:,cadaforcount4))) = m.dV(:,nonzeros(Gator1Data.Index12(:,cadaforcount4)));',cada1td1,'cada1td1',1);
        if ~exist('m','var'); m = cadastruct([],'m',[],0); end
        m.dV = cada1td1;
        m = adigatorVarAnalyzer('m.dV = cada1td1;',m,'m',1);
        if ~exist('m','var'); m = cadastruct([],'m',[],0); end
        m.f = m.f(:,cada1f3);
        m = adigatorVarAnalyzer('m.f = m.f(:,cada1f3);',m,'m',1);
        adigatorVarAnalyzer('%User Line: m  = input.phase(iphase).state(:, 7*(i-1) + 7);');
        cada1f1 = i.f - 1;
        cada1f1 = adigatorVarAnalyzer('cada1f1 = i.f - 1;',cada1f1,'cada1f1',0);
        cada1f2 = 3*cada1f1;
        cada1f2 = adigatorVarAnalyzer('cada1f2 = 3*cada1f1;',cada1f2,'cada1f2',0);
        cada1f3 = cada1f2 + 1;
        cada1f3 = adigatorVarAnalyzer('cada1f3 = cada1f2 + 1;',cada1f3,'cada1f3',0);
        cada1tempf1 = input.phase(iphase.f).control.f;
        cada1tempf1 = adigatorVarAnalyzer('cada1tempf1 = input.phase(iphase.f).control.f;',cada1tempf1,'cada1tempf1',0);
        if ~exist('ur','var'); ur = cadastruct([],'ur',[],0); end
        ur.dV = input.phase(iphase.f).control.dV;
        ur = adigatorVarAnalyzer('ur.dV = input.phase(iphase.f).control.dV;',ur,'ur',1);
        if ~exist('ur','var'); ur = cadastruct([],'ur',[],0); end
        ur.f = cada1tempf1;
        ur = adigatorVarAnalyzer('ur.f = cada1tempf1;',ur,'ur',1);
        cada1td1 = zeros(size(ur.f,1),4);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(ur.f,1),4);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,logical(Gator1Data.Index13(:,cadaforcount4))) = ur.dV(:,nonzeros(Gator1Data.Index13(:,cadaforcount4)));
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,logical(Gator1Data.Index13(:,cadaforcount4))) = ur.dV(:,nonzeros(Gator1Data.Index13(:,cadaforcount4)));',cada1td1,'cada1td1',1);
        if ~exist('ur','var'); ur = cadastruct([],'ur',[],0); end
        ur.dV = cada1td1;
        ur = adigatorVarAnalyzer('ur.dV = cada1td1;',ur,'ur',1);
        if ~exist('ur','var'); ur = cadastruct([],'ur',[],0); end
        ur.f = ur.f(:,cada1f3);
        ur = adigatorVarAnalyzer('ur.f = ur.f(:,cada1f3);',ur,'ur',1);
        adigatorVarAnalyzer('%User Line: ur = input.phase(iphase).control(:, 3*(i-1) + 1);');
        cada1f1 = i.f - 1;
        cada1f1 = adigatorVarAnalyzer('cada1f1 = i.f - 1;',cada1f1,'cada1f1',0);
        cada1f2 = 3*cada1f1;
        cada1f2 = adigatorVarAnalyzer('cada1f2 = 3*cada1f1;',cada1f2,'cada1f2',0);
        cada1f3 = cada1f2 + 2;
        cada1f3 = adigatorVarAnalyzer('cada1f3 = cada1f2 + 2;',cada1f3,'cada1f3',0);
        cada1tempf1 = input.phase(iphase.f).control.f;
        cada1tempf1 = adigatorVarAnalyzer('cada1tempf1 = input.phase(iphase.f).control.f;',cada1tempf1,'cada1tempf1',0);
        if ~exist('ut','var'); ut = cadastruct([],'ut',[],0); end
        ut.dV = input.phase(iphase.f).control.dV;
        ut = adigatorVarAnalyzer('ut.dV = input.phase(iphase.f).control.dV;',ut,'ut',1);
        if ~exist('ut','var'); ut = cadastruct([],'ut',[],0); end
        ut.f = cada1tempf1;
        ut = adigatorVarAnalyzer('ut.f = cada1tempf1;',ut,'ut',1);
        cada1td1 = zeros(size(ut.f,1),4);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(ut.f,1),4);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,logical(Gator1Data.Index14(:,cadaforcount4))) = ut.dV(:,nonzeros(Gator1Data.Index14(:,cadaforcount4)));
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,logical(Gator1Data.Index14(:,cadaforcount4))) = ut.dV(:,nonzeros(Gator1Data.Index14(:,cadaforcount4)));',cada1td1,'cada1td1',1);
        if ~exist('ut','var'); ut = cadastruct([],'ut',[],0); end
        ut.dV = cada1td1;
        ut = adigatorVarAnalyzer('ut.dV = cada1td1;',ut,'ut',1);
        if ~exist('ut','var'); ut = cadastruct([],'ut',[],0); end
        ut.f = ut.f(:,cada1f3);
        ut = adigatorVarAnalyzer('ut.f = ut.f(:,cada1f3);',ut,'ut',1);
        adigatorVarAnalyzer('%User Line: ut = input.phase(iphase).control(:, 3*(i-1) + 2);');
        cada1f1 = i.f - 1;
        cada1f1 = adigatorVarAnalyzer('cada1f1 = i.f - 1;',cada1f1,'cada1f1',0);
        cada1f2 = 3*cada1f1;
        cada1f2 = adigatorVarAnalyzer('cada1f2 = 3*cada1f1;',cada1f2,'cada1f2',0);
        cada1f3 = cada1f2 + 3;
        cada1f3 = adigatorVarAnalyzer('cada1f3 = cada1f2 + 3;',cada1f3,'cada1f3',0);
        cada1tempf1 = input.phase(iphase.f).control.f;
        cada1tempf1 = adigatorVarAnalyzer('cada1tempf1 = input.phase(iphase.f).control.f;',cada1tempf1,'cada1tempf1',0);
        if ~exist('un','var'); un = cadastruct([],'un',[],0); end
        un.dV = input.phase(iphase.f).control.dV;
        un = adigatorVarAnalyzer('un.dV = input.phase(iphase.f).control.dV;',un,'un',1);
        if ~exist('un','var'); un = cadastruct([],'un',[],0); end
        un.f = cada1tempf1;
        un = adigatorVarAnalyzer('un.f = cada1tempf1;',un,'un',1);
        cada1td1 = zeros(size(un.f,1),4);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(un.f,1),4);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,logical(Gator1Data.Index15(:,cadaforcount4))) = un.dV(:,nonzeros(Gator1Data.Index15(:,cadaforcount4)));
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,logical(Gator1Data.Index15(:,cadaforcount4))) = un.dV(:,nonzeros(Gator1Data.Index15(:,cadaforcount4)));',cada1td1,'cada1td1',1);
        if ~exist('un','var'); un = cadastruct([],'un',[],0); end
        un.dV = cada1td1;
        un = adigatorVarAnalyzer('un.dV = cada1td1;',un,'un',1);
        if ~exist('un','var'); un = cadastruct([],'un',[],0); end
        un.f = un.f(:,cada1f3);
        un = adigatorVarAnalyzer('un.f = un.f(:,cada1f3);',un,'un',1);
        adigatorVarAnalyzer('%User Line: un = input.phase(iphase).control(:, 3*(i-1) + 3);');
        adigatorVarAnalyzer('%User Line: %path  = ur.^2 + ut.^2 + un.^2;');
        adigatorVarAnalyzer('%User Line: %path4 = [path4 path];');
        cada1tf2 = ur.f(:,Gator1Data.Index47);
        cada1tf2 = adigatorVarAnalyzer('cada1tf2 = ur.f(:,Gator1Data.Index47);',cada1tf2,'cada1tf2',0);
        cada1f1dV = 2.*cada1tf2.^(2-1).*ur.dV;
        cada1f1dV = adigatorVarAnalyzer('cada1f1dV = 2.*cada1tf2.^(2-1).*ur.dV;',cada1f1dV,'cada1f1dV',0);
        cada1f1 = ur.f.^2;
        cada1f1 = adigatorVarAnalyzer('cada1f1 = ur.f.^2;',cada1f1,'cada1f1',0);
        cada1tf2 = ut.f(:,Gator1Data.Index48);
        cada1tf2 = adigatorVarAnalyzer('cada1tf2 = ut.f(:,Gator1Data.Index48);',cada1tf2,'cada1tf2',0);
        cada1f2dV = 2.*cada1tf2.^(2-1).*ut.dV;
        cada1f2dV = adigatorVarAnalyzer('cada1f2dV = 2.*cada1tf2.^(2-1).*ut.dV;',cada1f2dV,'cada1f2dV',0);
        cada1f2 = ut.f.^2;
        cada1f2 = adigatorVarAnalyzer('cada1f2 = ut.f.^2;',cada1f2,'cada1f2',0);
        cada1td1 = zeros(size(cada1f1dV,1),8);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(cada1f1dV,1),8);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index49) = cada1f1dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index49) = cada1f1dV;',cada1td1,'cada1td1',1);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index50) = cada1td1(:,Gator1Data.Index50) + cada1f2dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index50) = cada1td1(:,Gator1Data.Index50) + cada1f2dV;',cada1td1,'cada1td1',1);
        cada1f3dV = cada1td1;
        cada1f3dV = adigatorVarAnalyzer('cada1f3dV = cada1td1;',cada1f3dV,'cada1f3dV',0);
        cada1f3 = cada1f1 + cada1f2;
        cada1f3 = adigatorVarAnalyzer('cada1f3 = cada1f1 + cada1f2;',cada1f3,'cada1f3',0);
        cada1tf2 = un.f(:,Gator1Data.Index51);
        cada1tf2 = adigatorVarAnalyzer('cada1tf2 = un.f(:,Gator1Data.Index51);',cada1tf2,'cada1tf2',0);
        cada1f4dV = 2.*cada1tf2.^(2-1).*un.dV;
        cada1f4dV = adigatorVarAnalyzer('cada1f4dV = 2.*cada1tf2.^(2-1).*un.dV;',cada1f4dV,'cada1f4dV',0);
        cada1f4 = un.f.^2;
        cada1f4 = adigatorVarAnalyzer('cada1f4 = un.f.^2;',cada1f4,'cada1f4',0);
        cada1td1 = zeros(size(cada1f3dV,1),12);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(cada1f3dV,1),12);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index52) = cada1f3dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index52) = cada1f3dV;',cada1td1,'cada1td1',1);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index53) = cada1td1(:,Gator1Data.Index53) + cada1f4dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index53) = cada1td1(:,Gator1Data.Index53) + cada1f4dV;',cada1td1,'cada1td1',1);
        cada1f5dV = cada1td1;
        cada1f5dV = adigatorVarAnalyzer('cada1f5dV = cada1td1;',cada1f5dV,'cada1f5dV',0);
        cada1f5 = cada1f3 + cada1f4;
        cada1f5 = adigatorVarAnalyzer('cada1f5 = cada1f3 + cada1f4;',cada1f5,'cada1f5',0);
        if ~exist('path4','var'); path4 = cadastruct([],'path4',[],0); end
        path4.dV(:,logical(Gator1Data.Index16(:,cadaforcount4))) = cada1f5dV(:,nonzeros(Gator1Data.Index16(:,cadaforcount4)));
        path4 = adigatorVarAnalyzer('path4.dV(:,logical(Gator1Data.Index16(:,cadaforcount4))) = cada1f5dV(:,nonzeros(Gator1Data.Index16(:,cadaforcount4)));',path4,'path4',1);
        if ~exist('path4','var'); path4 = cadastruct([],'path4',[],0); end
        path4.f(:,i.f) = cada1f5;
        path4 = adigatorVarAnalyzer('path4.f(:,i.f) = cada1f5;',path4,'path4',1);
        adigatorVarAnalyzer('%User Line: path4(:,i) = ur.^2 + ut.^2 + un.^2;');
        cada1tf1 = L.f(:,Gator1Data.Index54);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = L.f(:,Gator1Data.Index54);',cada1tf1,'cada1tf1',0);
        cada1f1dV = cos(cada1tf1).*L.dV;
        cada1f1dV = adigatorVarAnalyzer('cada1f1dV = cos(cada1tf1).*L.dV;',cada1f1dV,'cada1f1dV',0);
        cada1f1 = sin(L.f);
        cada1f1 = adigatorVarAnalyzer('cada1f1 = sin(L.f);',cada1f1,'cada1f1',0);
        cada1tf1 = cada1f1(:,Gator1Data.Index55);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f1(:,Gator1Data.Index55);',cada1tf1,'cada1tf1',0);
        cada1td1 = zeros(size(P1.dV,1),8);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(P1.dV,1),8);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index56) = cada1tf1.*P1.dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index56) = cada1tf1.*P1.dV;',cada1td1,'cada1td1',1);
        cada1tf1 = P1.f(:,Gator1Data.Index57);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = P1.f(:,Gator1Data.Index57);',cada1tf1,'cada1tf1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index58) = cada1td1(:,Gator1Data.Index58) + cada1tf1.*cada1f1dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index58) = cada1td1(:,Gator1Data.Index58) + cada1tf1.*cada1f1dV;',cada1td1,'cada1td1',1);
        cada1f2dV = cada1td1;
        cada1f2dV = adigatorVarAnalyzer('cada1f2dV = cada1td1;',cada1f2dV,'cada1f2dV',0);
        cada1f2 = P1.f.*cada1f1;
        cada1f2 = adigatorVarAnalyzer('cada1f2 = P1.f.*cada1f1;',cada1f2,'cada1f2',0);
        cada1f3dV = cada1f2dV;
        cada1f3dV = adigatorVarAnalyzer('cada1f3dV = cada1f2dV;',cada1f3dV,'cada1f3dV',0);
        cada1f3 = 1 + cada1f2;
        cada1f3 = adigatorVarAnalyzer('cada1f3 = 1 + cada1f2;',cada1f3,'cada1f3',0);
        cada1tf1 = L.f(:,Gator1Data.Index59);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = L.f(:,Gator1Data.Index59);',cada1tf1,'cada1tf1',0);
        cada1f4dV = -sin(cada1tf1).*L.dV;
        cada1f4dV = adigatorVarAnalyzer('cada1f4dV = -sin(cada1tf1).*L.dV;',cada1f4dV,'cada1f4dV',0);
        cada1f4 = cos(L.f);
        cada1f4 = adigatorVarAnalyzer('cada1f4 = cos(L.f);',cada1f4,'cada1f4',0);
        cada1tf1 = cada1f4(:,Gator1Data.Index60);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f4(:,Gator1Data.Index60);',cada1tf1,'cada1tf1',0);
        cada1td1 = zeros(size(P2.dV,1),8);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(P2.dV,1),8);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index61) = cada1tf1.*P2.dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index61) = cada1tf1.*P2.dV;',cada1td1,'cada1td1',1);
        cada1tf1 = P2.f(:,Gator1Data.Index62);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = P2.f(:,Gator1Data.Index62);',cada1tf1,'cada1tf1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index63) = cada1td1(:,Gator1Data.Index63) + cada1tf1.*cada1f4dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index63) = cada1td1(:,Gator1Data.Index63) + cada1tf1.*cada1f4dV;',cada1td1,'cada1td1',1);
        cada1f5dV = cada1td1;
        cada1f5dV = adigatorVarAnalyzer('cada1f5dV = cada1td1;',cada1f5dV,'cada1f5dV',0);
        cada1f5 = P2.f.*cada1f4;
        cada1f5 = adigatorVarAnalyzer('cada1f5 = P2.f.*cada1f4;',cada1f5,'cada1f5',0);
        cada1td1 = zeros(size(cada1f3dV,1),12);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(cada1f3dV,1),12);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index64) = cada1f3dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index64) = cada1f3dV;',cada1td1,'cada1td1',1);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index65) = cada1td1(:,Gator1Data.Index65) + cada1f5dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index65) = cada1td1(:,Gator1Data.Index65) + cada1f5dV;',cada1td1,'cada1td1',1);
        if ~exist('w','var'); w = cadastruct([],'w',[],0); end
        w.dV = cada1td1;
        w = adigatorVarAnalyzer('w.dV = cada1td1;',w,'w',1);
        if ~exist('w','var'); w = cadastruct([],'w',[],0); end
        w.f = cada1f3 + cada1f5;
        w = adigatorVarAnalyzer('w.f = cada1f3 + cada1f5;',w,'w',1);
        adigatorVarAnalyzer('%User Line: w  = 1 + P1.*sin(L) + P2.*cos(L);');
        adigatorVarAnalyzer('%User Line: %             if w == 0');
        adigatorVarAnalyzer('%User Line: %');
        adigatorVarAnalyzer('%User Line: %                 keyboard;');
        adigatorVarAnalyzer('%User Line: %');
        adigatorVarAnalyzer('%User Line: %             end');
        adigatorVarAnalyzer('%User Line: %     s  = sqrt(1+Q1.^2+Q2.^2);');
        cada1tf2 = Q1.f(:,Gator1Data.Index66);
        cada1tf2 = adigatorVarAnalyzer('cada1tf2 = Q1.f(:,Gator1Data.Index66);',cada1tf2,'cada1tf2',0);
        cada1f1dV = 2.*cada1tf2.^(2-1).*Q1.dV;
        cada1f1dV = adigatorVarAnalyzer('cada1f1dV = 2.*cada1tf2.^(2-1).*Q1.dV;',cada1f1dV,'cada1f1dV',0);
        cada1f1 = Q1.f.^2;
        cada1f1 = adigatorVarAnalyzer('cada1f1 = Q1.f.^2;',cada1f1,'cada1f1',0);
        cada1f2dV = cada1f1dV;
        cada1f2dV = adigatorVarAnalyzer('cada1f2dV = cada1f1dV;',cada1f2dV,'cada1f2dV',0);
        cada1f2 = 1 + cada1f1;
        cada1f2 = adigatorVarAnalyzer('cada1f2 = 1 + cada1f1;',cada1f2,'cada1f2',0);
        cada1tf2 = Q2.f(:,Gator1Data.Index67);
        cada1tf2 = adigatorVarAnalyzer('cada1tf2 = Q2.f(:,Gator1Data.Index67);',cada1tf2,'cada1tf2',0);
        cada1f3dV = 2.*cada1tf2.^(2-1).*Q2.dV;
        cada1f3dV = adigatorVarAnalyzer('cada1f3dV = 2.*cada1tf2.^(2-1).*Q2.dV;',cada1f3dV,'cada1f3dV',0);
        cada1f3 = Q2.f.^2;
        cada1f3 = adigatorVarAnalyzer('cada1f3 = Q2.f.^2;',cada1f3,'cada1f3',0);
        cada1td1 = zeros(size(cada1f2dV,1),8);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(cada1f2dV,1),8);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index68) = cada1f2dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index68) = cada1f2dV;',cada1td1,'cada1td1',1);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index69) = cada1td1(:,Gator1Data.Index69) + cada1f3dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index69) = cada1td1(:,Gator1Data.Index69) + cada1f3dV;',cada1td1,'cada1td1',1);
        if ~exist('sSquare','var'); sSquare = cadastruct([],'sSquare',[],0); end
        sSquare.dV = cada1td1;
        sSquare = adigatorVarAnalyzer('sSquare.dV = cada1td1;',sSquare,'sSquare',1);
        if ~exist('sSquare','var'); sSquare = cadastruct([],'sSquare',[],0); end
        sSquare.f = cada1f2 + cada1f3;
        sSquare = adigatorVarAnalyzer('sSquare.f = cada1f2 + cada1f3;',sSquare,'sSquare',1);
        adigatorVarAnalyzer('%User Line: sSquare = 1 + Q1.^2 + Q2.^2;');
        cada1tf2 = m.f(:,Gator1Data.Index70);
        cada1tf2 = adigatorVarAnalyzer('cada1tf2 = m.f(:,Gator1Data.Index70);',cada1tf2,'cada1tf2',0);
        cada1f1dV = -T.f./cada1tf2.^2.*m.dV;
        cada1f1dV = adigatorVarAnalyzer('cada1f1dV = -T.f./cada1tf2.^2.*m.dV;',cada1f1dV,'cada1f1dV',0);
        cada1f1 = T.f./m.f;
        cada1f1 = adigatorVarAnalyzer('cada1f1 = T.f./m.f;',cada1f1,'cada1f1',0);
        cada1tf1 = ur.f(:,Gator1Data.Index71);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = ur.f(:,Gator1Data.Index71);',cada1tf1,'cada1tf1',0);
        cada1td1 = zeros(size(cada1f1dV,1),8);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(cada1f1dV,1),8);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index72) = cada1tf1.*cada1f1dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index72) = cada1tf1.*cada1f1dV;',cada1td1,'cada1td1',1);
        cada1tf1 = cada1f1(:,Gator1Data.Index73);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f1(:,Gator1Data.Index73);',cada1tf1,'cada1tf1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index74) = cada1td1(:,Gator1Data.Index74) + cada1tf1.*ur.dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index74) = cada1td1(:,Gator1Data.Index74) + cada1tf1.*ur.dV;',cada1td1,'cada1td1',1);
        if ~exist('ar','var'); ar = cadastruct([],'ar',[],0); end
        ar.dV = cada1td1;
        ar = adigatorVarAnalyzer('ar.dV = cada1td1;',ar,'ar',1);
        if ~exist('ar','var'); ar = cadastruct([],'ar',[],0); end
        ar.f = cada1f1.*ur.f;
        ar = adigatorVarAnalyzer('ar.f = cada1f1.*ur.f;',ar,'ar',1);
        adigatorVarAnalyzer('%User Line: ar = T./m.*ur;');
        cada1tf2 = m.f(:,Gator1Data.Index75);
        cada1tf2 = adigatorVarAnalyzer('cada1tf2 = m.f(:,Gator1Data.Index75);',cada1tf2,'cada1tf2',0);
        cada1f1dV = -T.f./cada1tf2.^2.*m.dV;
        cada1f1dV = adigatorVarAnalyzer('cada1f1dV = -T.f./cada1tf2.^2.*m.dV;',cada1f1dV,'cada1f1dV',0);
        cada1f1 = T.f./m.f;
        cada1f1 = adigatorVarAnalyzer('cada1f1 = T.f./m.f;',cada1f1,'cada1f1',0);
        cada1tf1 = ut.f(:,Gator1Data.Index76);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = ut.f(:,Gator1Data.Index76);',cada1tf1,'cada1tf1',0);
        cada1td1 = zeros(size(cada1f1dV,1),8);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(cada1f1dV,1),8);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index77) = cada1tf1.*cada1f1dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index77) = cada1tf1.*cada1f1dV;',cada1td1,'cada1td1',1);
        cada1tf1 = cada1f1(:,Gator1Data.Index78);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f1(:,Gator1Data.Index78);',cada1tf1,'cada1tf1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index79) = cada1td1(:,Gator1Data.Index79) + cada1tf1.*ut.dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index79) = cada1td1(:,Gator1Data.Index79) + cada1tf1.*ut.dV;',cada1td1,'cada1td1',1);
        if ~exist('at','var'); at = cadastruct([],'at',[],0); end
        at.dV = cada1td1;
        at = adigatorVarAnalyzer('at.dV = cada1td1;',at,'at',1);
        if ~exist('at','var'); at = cadastruct([],'at',[],0); end
        at.f = cada1f1.*ut.f;
        at = adigatorVarAnalyzer('at.f = cada1f1.*ut.f;',at,'at',1);
        adigatorVarAnalyzer('%User Line: at = T./m.*ut;');
        cada1tf2 = m.f(:,Gator1Data.Index80);
        cada1tf2 = adigatorVarAnalyzer('cada1tf2 = m.f(:,Gator1Data.Index80);',cada1tf2,'cada1tf2',0);
        cada1f1dV = -T.f./cada1tf2.^2.*m.dV;
        cada1f1dV = adigatorVarAnalyzer('cada1f1dV = -T.f./cada1tf2.^2.*m.dV;',cada1f1dV,'cada1f1dV',0);
        cada1f1 = T.f./m.f;
        cada1f1 = adigatorVarAnalyzer('cada1f1 = T.f./m.f;',cada1f1,'cada1f1',0);
        cada1tf1 = un.f(:,Gator1Data.Index81);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = un.f(:,Gator1Data.Index81);',cada1tf1,'cada1tf1',0);
        cada1td1 = zeros(size(cada1f1dV,1),8);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(cada1f1dV,1),8);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index82) = cada1tf1.*cada1f1dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index82) = cada1tf1.*cada1f1dV;',cada1td1,'cada1td1',1);
        cada1tf1 = cada1f1(:,Gator1Data.Index83);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f1(:,Gator1Data.Index83);',cada1tf1,'cada1tf1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index84) = cada1td1(:,Gator1Data.Index84) + cada1tf1.*un.dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index84) = cada1td1(:,Gator1Data.Index84) + cada1tf1.*un.dV;',cada1td1,'cada1td1',1);
        if ~exist('an','var'); an = cadastruct([],'an',[],0); end
        an.dV = cada1td1;
        an = adigatorVarAnalyzer('an.dV = cada1td1;',an,'an',1);
        if ~exist('an','var'); an = cadastruct([],'an',[],0); end
        an.f = cada1f1.*un.f;
        an = adigatorVarAnalyzer('an.f = cada1f1.*un.f;',an,'an',1);
        adigatorVarAnalyzer('%User Line: an = T./m.*un;');
        cada1f1dV = 2.*p.dV;
        cada1f1dV = adigatorVarAnalyzer('cada1f1dV = 2.*p.dV;',cada1f1dV,'cada1f1dV',0);
        cada1f1 = 2*p.f;
        cada1f1 = adigatorVarAnalyzer('cada1f1 = 2*p.f;',cada1f1,'cada1f1',0);
        cada1tf1 = w.f(:,Gator1Data.Index85);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = w.f(:,Gator1Data.Index85);',cada1tf1,'cada1tf1',0);
        cada1td1 = zeros(size(cada1f1dV,1),16);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(cada1f1dV,1),16);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index86) = cada1f1dV./cada1tf1;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index86) = cada1f1dV./cada1tf1;',cada1td1,'cada1td1',1);
        cada1tf1 = cada1f1(:,Gator1Data.Index87);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f1(:,Gator1Data.Index87);',cada1tf1,'cada1tf1',0);
        cada1tf2 = w.f(:,Gator1Data.Index88);
        cada1tf2 = adigatorVarAnalyzer('cada1tf2 = w.f(:,Gator1Data.Index88);',cada1tf2,'cada1tf2',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index89) = cada1td1(:,Gator1Data.Index89) + -cada1tf1./cada1tf2.^2.*w.dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index89) = cada1td1(:,Gator1Data.Index89) + -cada1tf1./cada1tf2.^2.*w.dV;',cada1td1,'cada1td1',1);
        cada1f2dV = cada1td1;
        cada1f2dV = adigatorVarAnalyzer('cada1f2dV = cada1td1;',cada1f2dV,'cada1f2dV',0);
        cada1f2 = cada1f1./w.f;
        cada1f2 = adigatorVarAnalyzer('cada1f2 = cada1f1./w.f;',cada1f2,'cada1f2',0);
        cada1f3dV = p.dV./mu.f;
        cada1f3dV = adigatorVarAnalyzer('cada1f3dV = p.dV./mu.f;',cada1f3dV,'cada1f3dV',0);
        cada1f3 = p.f/mu.f;
        cada1f3 = adigatorVarAnalyzer('cada1f3 = p.f/mu.f;',cada1f3,'cada1f3',0);
        cada1tf1 = cada1f3(:,Gator1Data.Index90);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f3(:,Gator1Data.Index90);',cada1tf1,'cada1tf1',0);
        cada1f4dV = (1/2)./sqrt(cada1tf1).*cada1f3dV;
        cada1f4dV = adigatorVarAnalyzer('cada1f4dV = (1/2)./sqrt(cada1tf1).*cada1f3dV;',cada1f4dV,'cada1f4dV',0);
        if ~exist('cada1f4dV','var'); cada1f4dV = cadastruct([],'cada1f4dV',[],0); end
        cada1f4dV(cada1tf1 == 0 & cada1f3dV == 0) = 0;
        cada1f4dV = adigatorVarAnalyzer('cada1f4dV(cada1tf1 == 0 & cada1f3dV == 0) = 0;',cada1f4dV,'cada1f4dV',1);
        cada1f4 = sqrt(cada1f3);
        cada1f4 = adigatorVarAnalyzer('cada1f4 = sqrt(cada1f3);',cada1f4,'cada1f4',0);
        cada1tf1 = cada1f4(:,Gator1Data.Index91);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f4(:,Gator1Data.Index91);',cada1tf1,'cada1tf1',0);
        cada1td1 = cada1tf1.*cada1f2dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1 = cada1tf1.*cada1f2dV;',cada1td1,'cada1td1',0);
        cada1tf1 = cada1f2(:,Gator1Data.Index92);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f2(:,Gator1Data.Index92);',cada1tf1,'cada1tf1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index93) = cada1td1(:,Gator1Data.Index93) + cada1tf1.*cada1f4dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index93) = cada1td1(:,Gator1Data.Index93) + cada1tf1.*cada1f4dV;',cada1td1,'cada1td1',1);
        cada1f5dV = cada1td1;
        cada1f5dV = adigatorVarAnalyzer('cada1f5dV = cada1td1;',cada1f5dV,'cada1f5dV',0);
        cada1f5 = cada1f2.*cada1f4;
        cada1f5 = adigatorVarAnalyzer('cada1f5 = cada1f2.*cada1f4;',cada1f5,'cada1f5',0);
        cada1tf1 = at.f(:,Gator1Data.Index94);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = at.f(:,Gator1Data.Index94);',cada1tf1,'cada1tf1',0);
        cada1td1 = zeros(size(cada1f5dV,1),24);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(cada1f5dV,1),24);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index95) = cada1tf1.*cada1f5dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index95) = cada1tf1.*cada1f5dV;',cada1td1,'cada1td1',1);
        cada1tf1 = cada1f5(:,Gator1Data.Index96);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f5(:,Gator1Data.Index96);',cada1tf1,'cada1tf1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index97) = cada1td1(:,Gator1Data.Index97) + cada1tf1.*at.dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index97) = cada1td1(:,Gator1Data.Index97) + cada1tf1.*at.dV;',cada1td1,'cada1td1',1);
        if ~exist('pdot','var'); pdot = cadastruct([],'pdot',[],0); end
        pdot.dV = cada1td1;
        pdot = adigatorVarAnalyzer('pdot.dV = cada1td1;',pdot,'pdot',1);
        if ~exist('pdot','var'); pdot = cadastruct([],'pdot',[],0); end
        pdot.f = cada1f5.*at.f;
        pdot = adigatorVarAnalyzer('pdot.f = cada1f5.*at.f;',pdot,'pdot',1);
        adigatorVarAnalyzer('%User Line: pdot   = 2*p./w.*sqrt(p./mu).*at;');
        cada1f1dV = p.dV./mu.f;
        cada1f1dV = adigatorVarAnalyzer('cada1f1dV = p.dV./mu.f;',cada1f1dV,'cada1f1dV',0);
        cada1f1 = p.f/mu.f;
        cada1f1 = adigatorVarAnalyzer('cada1f1 = p.f/mu.f;',cada1f1,'cada1f1',0);
        cada1tf1 = cada1f1(:,Gator1Data.Index98);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f1(:,Gator1Data.Index98);',cada1tf1,'cada1tf1',0);
        cada1f2dV = (1/2)./sqrt(cada1tf1).*cada1f1dV;
        cada1f2dV = adigatorVarAnalyzer('cada1f2dV = (1/2)./sqrt(cada1tf1).*cada1f1dV;',cada1f2dV,'cada1f2dV',0);
        if ~exist('cada1f2dV','var'); cada1f2dV = cadastruct([],'cada1f2dV',[],0); end
        cada1f2dV(cada1tf1 == 0 & cada1f1dV == 0) = 0;
        cada1f2dV = adigatorVarAnalyzer('cada1f2dV(cada1tf1 == 0 & cada1f1dV == 0) = 0;',cada1f2dV,'cada1f2dV',1);
        cada1f2 = sqrt(cada1f1);
        cada1f2 = adigatorVarAnalyzer('cada1f2 = sqrt(cada1f1);',cada1f2,'cada1f2',0);
        cada1f3dV = -ar.dV;
        cada1f3dV = adigatorVarAnalyzer('cada1f3dV = -ar.dV;',cada1f3dV,'cada1f3dV',0);
        cada1f3 = uminus(ar.f);
        cada1f3 = adigatorVarAnalyzer('cada1f3 = uminus(ar.f);',cada1f3,'cada1f3',0);
        cada1tf1 = L.f(:,Gator1Data.Index99);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = L.f(:,Gator1Data.Index99);',cada1tf1,'cada1tf1',0);
        cada1f4dV = -sin(cada1tf1).*L.dV;
        cada1f4dV = adigatorVarAnalyzer('cada1f4dV = -sin(cada1tf1).*L.dV;',cada1f4dV,'cada1f4dV',0);
        cada1f4 = cos(L.f);
        cada1f4 = adigatorVarAnalyzer('cada1f4 = cos(L.f);',cada1f4,'cada1f4',0);
        cada1tf1 = cada1f4(:,Gator1Data.Index100);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f4(:,Gator1Data.Index100);',cada1tf1,'cada1tf1',0);
        cada1td1 = zeros(size(cada1f3dV,1),12);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(cada1f3dV,1),12);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index101) = cada1tf1.*cada1f3dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index101) = cada1tf1.*cada1f3dV;',cada1td1,'cada1td1',1);
        cada1tf1 = cada1f3(:,Gator1Data.Index102);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f3(:,Gator1Data.Index102);',cada1tf1,'cada1tf1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index103) = cada1td1(:,Gator1Data.Index103) + cada1tf1.*cada1f4dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index103) = cada1td1(:,Gator1Data.Index103) + cada1tf1.*cada1f4dV;',cada1td1,'cada1td1',1);
        cada1f5dV = cada1td1;
        cada1f5dV = adigatorVarAnalyzer('cada1f5dV = cada1td1;',cada1f5dV,'cada1f5dV',0);
        cada1f5 = cada1f3.*cada1f4;
        cada1f5 = adigatorVarAnalyzer('cada1f5 = cada1f3.*cada1f4;',cada1f5,'cada1f5',0);
        cada1f6dV = w.dV;
        cada1f6dV = adigatorVarAnalyzer('cada1f6dV = w.dV;',cada1f6dV,'cada1f6dV',0);
        cada1f6 = w.f + 1;
        cada1f6 = adigatorVarAnalyzer('cada1f6 = w.f + 1;',cada1f6,'cada1f6',0);
        cada1tf1 = L.f(:,Gator1Data.Index104);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = L.f(:,Gator1Data.Index104);',cada1tf1,'cada1tf1',0);
        cada1f7dV = cos(cada1tf1).*L.dV;
        cada1f7dV = adigatorVarAnalyzer('cada1f7dV = cos(cada1tf1).*L.dV;',cada1f7dV,'cada1f7dV',0);
        cada1f7 = sin(L.f);
        cada1f7 = adigatorVarAnalyzer('cada1f7 = sin(L.f);',cada1f7,'cada1f7',0);
        cada1tf1 = cada1f7(:,Gator1Data.Index105);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f7(:,Gator1Data.Index105);',cada1tf1,'cada1tf1',0);
        cada1td1 = cada1tf1.*cada1f6dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1 = cada1tf1.*cada1f6dV;',cada1td1,'cada1td1',0);
        cada1tf1 = cada1f6(:,Gator1Data.Index106);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f6(:,Gator1Data.Index106);',cada1tf1,'cada1tf1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index107) = cada1td1(:,Gator1Data.Index107) + cada1tf1.*cada1f7dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index107) = cada1td1(:,Gator1Data.Index107) + cada1tf1.*cada1f7dV;',cada1td1,'cada1td1',1);
        cada1f8dV = cada1td1;
        cada1f8dV = adigatorVarAnalyzer('cada1f8dV = cada1td1;',cada1f8dV,'cada1f8dV',0);
        cada1f8 = cada1f6.*cada1f7;
        cada1f8 = adigatorVarAnalyzer('cada1f8 = cada1f6.*cada1f7;',cada1f8,'cada1f8',0);
        cada1td1 = cada1f8dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1 = cada1f8dV;',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index108) = cada1td1(:,Gator1Data.Index108) + P1.dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index108) = cada1td1(:,Gator1Data.Index108) + P1.dV;',cada1td1,'cada1td1',1);
        cada1f9dV = cada1td1;
        cada1f9dV = adigatorVarAnalyzer('cada1f9dV = cada1td1;',cada1f9dV,'cada1f9dV',0);
        cada1f9 = cada1f8 + P1.f;
        cada1f9 = adigatorVarAnalyzer('cada1f9 = cada1f8 + P1.f;',cada1f9,'cada1f9',0);
        cada1tf1 = at.f(:,Gator1Data.Index109);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = at.f(:,Gator1Data.Index109);',cada1tf1,'cada1tf1',0);
        cada1td1 = zeros(size(cada1f9dV,1),20);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(cada1f9dV,1),20);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index110) = cada1tf1.*cada1f9dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index110) = cada1tf1.*cada1f9dV;',cada1td1,'cada1td1',1);
        cada1tf1 = cada1f9(:,Gator1Data.Index111);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f9(:,Gator1Data.Index111);',cada1tf1,'cada1tf1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index112) = cada1td1(:,Gator1Data.Index112) + cada1tf1.*at.dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index112) = cada1td1(:,Gator1Data.Index112) + cada1tf1.*at.dV;',cada1td1,'cada1td1',1);
        cada1f10dV = cada1td1;
        cada1f10dV = adigatorVarAnalyzer('cada1f10dV = cada1td1;',cada1f10dV,'cada1f10dV',0);
        cada1f10 = cada1f9.*at.f;
        cada1f10 = adigatorVarAnalyzer('cada1f10 = cada1f9.*at.f;',cada1f10,'cada1f10',0);
        cada1tf1 = w.f(:,Gator1Data.Index113);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = w.f(:,Gator1Data.Index113);',cada1tf1,'cada1tf1',0);
        cada1td1 = cada1f10dV./cada1tf1;
        cada1td1 = adigatorVarAnalyzer('cada1td1 = cada1f10dV./cada1tf1;',cada1td1,'cada1td1',0);
        cada1tf1 = cada1f10(:,Gator1Data.Index114);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f10(:,Gator1Data.Index114);',cada1tf1,'cada1tf1',0);
        cada1tf2 = w.f(:,Gator1Data.Index115);
        cada1tf2 = adigatorVarAnalyzer('cada1tf2 = w.f(:,Gator1Data.Index115);',cada1tf2,'cada1tf2',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index116) = cada1td1(:,Gator1Data.Index116) + -cada1tf1./cada1tf2.^2.*w.dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index116) = cada1td1(:,Gator1Data.Index116) + -cada1tf1./cada1tf2.^2.*w.dV;',cada1td1,'cada1td1',1);
        cada1f11dV = cada1td1;
        cada1f11dV = adigatorVarAnalyzer('cada1f11dV = cada1td1;',cada1f11dV,'cada1f11dV',0);
        cada1f11 = cada1f10./w.f;
        cada1f11 = adigatorVarAnalyzer('cada1f11 = cada1f10./w.f;',cada1f11,'cada1f11',0);
        cada1td1 = zeros(size(cada1f5dV,1),24);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(cada1f5dV,1),24);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index117) = cada1f5dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index117) = cada1f5dV;',cada1td1,'cada1td1',1);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index118) = cada1td1(:,Gator1Data.Index118) + cada1f11dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index118) = cada1td1(:,Gator1Data.Index118) + cada1f11dV;',cada1td1,'cada1td1',1);
        cada1f12dV = cada1td1;
        cada1f12dV = adigatorVarAnalyzer('cada1f12dV = cada1td1;',cada1f12dV,'cada1f12dV',0);
        cada1f12 = cada1f5 + cada1f11;
        cada1f12 = adigatorVarAnalyzer('cada1f12 = cada1f5 + cada1f11;',cada1f12,'cada1f12',0);
        cada1tf1 = L.f(:,Gator1Data.Index119);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = L.f(:,Gator1Data.Index119);',cada1tf1,'cada1tf1',0);
        cada1f13dV = cos(cada1tf1).*L.dV;
        cada1f13dV = adigatorVarAnalyzer('cada1f13dV = cos(cada1tf1).*L.dV;',cada1f13dV,'cada1f13dV',0);
        cada1f13 = sin(L.f);
        cada1f13 = adigatorVarAnalyzer('cada1f13 = sin(L.f);',cada1f13,'cada1f13',0);
        cada1tf1 = cada1f13(:,Gator1Data.Index120);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f13(:,Gator1Data.Index120);',cada1tf1,'cada1tf1',0);
        cada1td1 = zeros(size(Q2.dV,1),8);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(Q2.dV,1),8);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index121) = cada1tf1.*Q2.dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index121) = cada1tf1.*Q2.dV;',cada1td1,'cada1td1',1);
        cada1tf1 = Q2.f(:,Gator1Data.Index122);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = Q2.f(:,Gator1Data.Index122);',cada1tf1,'cada1tf1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index123) = cada1td1(:,Gator1Data.Index123) + cada1tf1.*cada1f13dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index123) = cada1td1(:,Gator1Data.Index123) + cada1tf1.*cada1f13dV;',cada1td1,'cada1td1',1);
        cada1f14dV = cada1td1;
        cada1f14dV = adigatorVarAnalyzer('cada1f14dV = cada1td1;',cada1f14dV,'cada1f14dV',0);
        cada1f14 = Q2.f.*cada1f13;
        cada1f14 = adigatorVarAnalyzer('cada1f14 = Q2.f.*cada1f13;',cada1f14,'cada1f14',0);
        cada1tf1 = L.f(:,Gator1Data.Index124);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = L.f(:,Gator1Data.Index124);',cada1tf1,'cada1tf1',0);
        cada1f15dV = -sin(cada1tf1).*L.dV;
        cada1f15dV = adigatorVarAnalyzer('cada1f15dV = -sin(cada1tf1).*L.dV;',cada1f15dV,'cada1f15dV',0);
        cada1f15 = cos(L.f);
        cada1f15 = adigatorVarAnalyzer('cada1f15 = cos(L.f);',cada1f15,'cada1f15',0);
        cada1tf1 = cada1f15(:,Gator1Data.Index125);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f15(:,Gator1Data.Index125);',cada1tf1,'cada1tf1',0);
        cada1td1 = zeros(size(Q1.dV,1),8);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(Q1.dV,1),8);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index126) = cada1tf1.*Q1.dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index126) = cada1tf1.*Q1.dV;',cada1td1,'cada1td1',1);
        cada1tf1 = Q1.f(:,Gator1Data.Index127);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = Q1.f(:,Gator1Data.Index127);',cada1tf1,'cada1tf1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index128) = cada1td1(:,Gator1Data.Index128) + cada1tf1.*cada1f15dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index128) = cada1td1(:,Gator1Data.Index128) + cada1tf1.*cada1f15dV;',cada1td1,'cada1td1',1);
        cada1f16dV = cada1td1;
        cada1f16dV = adigatorVarAnalyzer('cada1f16dV = cada1td1;',cada1f16dV,'cada1f16dV',0);
        cada1f16 = Q1.f.*cada1f15;
        cada1f16 = adigatorVarAnalyzer('cada1f16 = Q1.f.*cada1f15;',cada1f16,'cada1f16',0);
        cada1td1 = zeros(size(cada1f14dV,1),12);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(cada1f14dV,1),12);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index129) = cada1f14dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index129) = cada1f14dV;',cada1td1,'cada1td1',1);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index130) = cada1td1(:,Gator1Data.Index130) + -cada1f16dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index130) = cada1td1(:,Gator1Data.Index130) + -cada1f16dV;',cada1td1,'cada1td1',1);
        cada1f17dV = cada1td1;
        cada1f17dV = adigatorVarAnalyzer('cada1f17dV = cada1td1;',cada1f17dV,'cada1f17dV',0);
        cada1f17 = cada1f14 - cada1f16;
        cada1f17 = adigatorVarAnalyzer('cada1f17 = cada1f14 - cada1f16;',cada1f17,'cada1f17',0);
        cada1tf1 = P2.f(:,Gator1Data.Index131);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = P2.f(:,Gator1Data.Index131);',cada1tf1,'cada1tf1',0);
        cada1td1 = zeros(size(cada1f17dV,1),16);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(cada1f17dV,1),16);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index132) = cada1tf1.*cada1f17dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index132) = cada1tf1.*cada1f17dV;',cada1td1,'cada1td1',1);
        cada1tf1 = cada1f17(:,Gator1Data.Index133);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f17(:,Gator1Data.Index133);',cada1tf1,'cada1tf1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index134) = cada1td1(:,Gator1Data.Index134) + cada1tf1.*P2.dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index134) = cada1td1(:,Gator1Data.Index134) + cada1tf1.*P2.dV;',cada1td1,'cada1td1',1);
        cada1f18dV = cada1td1;
        cada1f18dV = adigatorVarAnalyzer('cada1f18dV = cada1td1;',cada1f18dV,'cada1f18dV',0);
        cada1f18 = cada1f17.*P2.f;
        cada1f18 = adigatorVarAnalyzer('cada1f18 = cada1f17.*P2.f;',cada1f18,'cada1f18',0);
        cada1tf1 = at.f(:,Gator1Data.Index135);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = at.f(:,Gator1Data.Index135);',cada1tf1,'cada1tf1',0);
        cada1td1 = zeros(size(cada1f18dV,1),24);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(cada1f18dV,1),24);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index136) = cada1tf1.*cada1f18dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index136) = cada1tf1.*cada1f18dV;',cada1td1,'cada1td1',1);
        cada1tf1 = cada1f18(:,Gator1Data.Index137);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f18(:,Gator1Data.Index137);',cada1tf1,'cada1tf1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index138) = cada1td1(:,Gator1Data.Index138) + cada1tf1.*at.dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index138) = cada1td1(:,Gator1Data.Index138) + cada1tf1.*at.dV;',cada1td1,'cada1td1',1);
        cada1f19dV = cada1td1;
        cada1f19dV = adigatorVarAnalyzer('cada1f19dV = cada1td1;',cada1f19dV,'cada1f19dV',0);
        cada1f19 = cada1f18.*at.f;
        cada1f19 = adigatorVarAnalyzer('cada1f19 = cada1f18.*at.f;',cada1f19,'cada1f19',0);
        cada1tf1 = w.f(:,Gator1Data.Index139);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = w.f(:,Gator1Data.Index139);',cada1tf1,'cada1tf1',0);
        cada1td1 = zeros(size(cada1f19dV,1),28);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(cada1f19dV,1),28);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index140) = cada1f19dV./cada1tf1;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index140) = cada1f19dV./cada1tf1;',cada1td1,'cada1td1',1);
        cada1tf1 = cada1f19(:,Gator1Data.Index141);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f19(:,Gator1Data.Index141);',cada1tf1,'cada1tf1',0);
        cada1tf2 = w.f(:,Gator1Data.Index142);
        cada1tf2 = adigatorVarAnalyzer('cada1tf2 = w.f(:,Gator1Data.Index142);',cada1tf2,'cada1tf2',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index143) = cada1td1(:,Gator1Data.Index143) + -cada1tf1./cada1tf2.^2.*w.dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index143) = cada1td1(:,Gator1Data.Index143) + -cada1tf1./cada1tf2.^2.*w.dV;',cada1td1,'cada1td1',1);
        cada1f20dV = cada1td1;
        cada1f20dV = adigatorVarAnalyzer('cada1f20dV = cada1td1;',cada1f20dV,'cada1f20dV',0);
        cada1f20 = cada1f19./w.f;
        cada1f20 = adigatorVarAnalyzer('cada1f20 = cada1f19./w.f;',cada1f20,'cada1f20',0);
        cada1td1 = zeros(size(cada1f12dV,1),32);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(cada1f12dV,1),32);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index144) = cada1f12dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index144) = cada1f12dV;',cada1td1,'cada1td1',1);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index145) = cada1td1(:,Gator1Data.Index145) + cada1f20dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index145) = cada1td1(:,Gator1Data.Index145) + cada1f20dV;',cada1td1,'cada1td1',1);
        cada1f21dV = cada1td1;
        cada1f21dV = adigatorVarAnalyzer('cada1f21dV = cada1td1;',cada1f21dV,'cada1f21dV',0);
        cada1f21 = cada1f12 + cada1f20;
        cada1f21 = adigatorVarAnalyzer('cada1f21 = cada1f12 + cada1f20;',cada1f21,'cada1f21',0);
        cada1tf1 = cada1f21(:,Gator1Data.Index146);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f21(:,Gator1Data.Index146);',cada1tf1,'cada1tf1',0);
        cada1td1 = zeros(size(cada1f2dV,1),36);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(cada1f2dV,1),36);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index147) = cada1tf1.*cada1f2dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index147) = cada1tf1.*cada1f2dV;',cada1td1,'cada1td1',1);
        cada1tf1 = cada1f2(:,Gator1Data.Index148);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f2(:,Gator1Data.Index148);',cada1tf1,'cada1tf1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index149) = cada1td1(:,Gator1Data.Index149) + cada1tf1.*cada1f21dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index149) = cada1td1(:,Gator1Data.Index149) + cada1tf1.*cada1f21dV;',cada1td1,'cada1td1',1);
        if ~exist('P1dot','var'); P1dot = cadastruct([],'P1dot',[],0); end
        P1dot.dV = cada1td1;
        P1dot = adigatorVarAnalyzer('P1dot.dV = cada1td1;',P1dot,'P1dot',1);
        if ~exist('P1dot','var'); P1dot = cadastruct([],'P1dot',[],0); end
        P1dot.f = cada1f2.*cada1f21;
        P1dot = adigatorVarAnalyzer('P1dot.f = cada1f2.*cada1f21;',P1dot,'P1dot',1);
        adigatorVarAnalyzer('%User Line: P1dot  = sqrt(p./mu).*(-ar.*cos(L)+                ((w+1).*sin(L)+P1).*at./w+                (Q2.*sin(L)-Q1.*cos(L)).*P2.*at./w);');
        cada1f1dV = p.dV./mu.f;
        cada1f1dV = adigatorVarAnalyzer('cada1f1dV = p.dV./mu.f;',cada1f1dV,'cada1f1dV',0);
        cada1f1 = p.f/mu.f;
        cada1f1 = adigatorVarAnalyzer('cada1f1 = p.f/mu.f;',cada1f1,'cada1f1',0);
        cada1tf1 = cada1f1(:,Gator1Data.Index150);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f1(:,Gator1Data.Index150);',cada1tf1,'cada1tf1',0);
        cada1f2dV = (1/2)./sqrt(cada1tf1).*cada1f1dV;
        cada1f2dV = adigatorVarAnalyzer('cada1f2dV = (1/2)./sqrt(cada1tf1).*cada1f1dV;',cada1f2dV,'cada1f2dV',0);
        if ~exist('cada1f2dV','var'); cada1f2dV = cadastruct([],'cada1f2dV',[],0); end
        cada1f2dV(cada1tf1 == 0 & cada1f1dV == 0) = 0;
        cada1f2dV = adigatorVarAnalyzer('cada1f2dV(cada1tf1 == 0 & cada1f1dV == 0) = 0;',cada1f2dV,'cada1f2dV',1);
        cada1f2 = sqrt(cada1f1);
        cada1f2 = adigatorVarAnalyzer('cada1f2 = sqrt(cada1f1);',cada1f2,'cada1f2',0);
        cada1tf1 = L.f(:,Gator1Data.Index151);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = L.f(:,Gator1Data.Index151);',cada1tf1,'cada1tf1',0);
        cada1f3dV = cos(cada1tf1).*L.dV;
        cada1f3dV = adigatorVarAnalyzer('cada1f3dV = cos(cada1tf1).*L.dV;',cada1f3dV,'cada1f3dV',0);
        cada1f3 = sin(L.f);
        cada1f3 = adigatorVarAnalyzer('cada1f3 = sin(L.f);',cada1f3,'cada1f3',0);
        cada1tf1 = cada1f3(:,Gator1Data.Index152);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f3(:,Gator1Data.Index152);',cada1tf1,'cada1tf1',0);
        cada1td1 = zeros(size(ar.dV,1),12);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(ar.dV,1),12);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index153) = cada1tf1.*ar.dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index153) = cada1tf1.*ar.dV;',cada1td1,'cada1td1',1);
        cada1tf1 = ar.f(:,Gator1Data.Index154);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = ar.f(:,Gator1Data.Index154);',cada1tf1,'cada1tf1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index155) = cada1td1(:,Gator1Data.Index155) + cada1tf1.*cada1f3dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index155) = cada1td1(:,Gator1Data.Index155) + cada1tf1.*cada1f3dV;',cada1td1,'cada1td1',1);
        cada1f4dV = cada1td1;
        cada1f4dV = adigatorVarAnalyzer('cada1f4dV = cada1td1;',cada1f4dV,'cada1f4dV',0);
        cada1f4 = ar.f.*cada1f3;
        cada1f4 = adigatorVarAnalyzer('cada1f4 = ar.f.*cada1f3;',cada1f4,'cada1f4',0);
        cada1f5dV = w.dV;
        cada1f5dV = adigatorVarAnalyzer('cada1f5dV = w.dV;',cada1f5dV,'cada1f5dV',0);
        cada1f5 = w.f + 1;
        cada1f5 = adigatorVarAnalyzer('cada1f5 = w.f + 1;',cada1f5,'cada1f5',0);
        cada1tf1 = L.f(:,Gator1Data.Index156);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = L.f(:,Gator1Data.Index156);',cada1tf1,'cada1tf1',0);
        cada1f6dV = -sin(cada1tf1).*L.dV;
        cada1f6dV = adigatorVarAnalyzer('cada1f6dV = -sin(cada1tf1).*L.dV;',cada1f6dV,'cada1f6dV',0);
        cada1f6 = cos(L.f);
        cada1f6 = adigatorVarAnalyzer('cada1f6 = cos(L.f);',cada1f6,'cada1f6',0);
        cada1tf1 = cada1f6(:,Gator1Data.Index157);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f6(:,Gator1Data.Index157);',cada1tf1,'cada1tf1',0);
        cada1td1 = cada1tf1.*cada1f5dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1 = cada1tf1.*cada1f5dV;',cada1td1,'cada1td1',0);
        cada1tf1 = cada1f5(:,Gator1Data.Index158);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f5(:,Gator1Data.Index158);',cada1tf1,'cada1tf1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index159) = cada1td1(:,Gator1Data.Index159) + cada1tf1.*cada1f6dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index159) = cada1td1(:,Gator1Data.Index159) + cada1tf1.*cada1f6dV;',cada1td1,'cada1td1',1);
        cada1f7dV = cada1td1;
        cada1f7dV = adigatorVarAnalyzer('cada1f7dV = cada1td1;',cada1f7dV,'cada1f7dV',0);
        cada1f7 = cada1f5.*cada1f6;
        cada1f7 = adigatorVarAnalyzer('cada1f7 = cada1f5.*cada1f6;',cada1f7,'cada1f7',0);
        cada1td1 = cada1f7dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1 = cada1f7dV;',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index160) = cada1td1(:,Gator1Data.Index160) + P2.dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index160) = cada1td1(:,Gator1Data.Index160) + P2.dV;',cada1td1,'cada1td1',1);
        cada1f8dV = cada1td1;
        cada1f8dV = adigatorVarAnalyzer('cada1f8dV = cada1td1;',cada1f8dV,'cada1f8dV',0);
        cada1f8 = cada1f7 + P2.f;
        cada1f8 = adigatorVarAnalyzer('cada1f8 = cada1f7 + P2.f;',cada1f8,'cada1f8',0);
        cada1tf1 = at.f(:,Gator1Data.Index161);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = at.f(:,Gator1Data.Index161);',cada1tf1,'cada1tf1',0);
        cada1td1 = zeros(size(cada1f8dV,1),20);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(cada1f8dV,1),20);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index162) = cada1tf1.*cada1f8dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index162) = cada1tf1.*cada1f8dV;',cada1td1,'cada1td1',1);
        cada1tf1 = cada1f8(:,Gator1Data.Index163);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f8(:,Gator1Data.Index163);',cada1tf1,'cada1tf1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index164) = cada1td1(:,Gator1Data.Index164) + cada1tf1.*at.dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index164) = cada1td1(:,Gator1Data.Index164) + cada1tf1.*at.dV;',cada1td1,'cada1td1',1);
        cada1f9dV = cada1td1;
        cada1f9dV = adigatorVarAnalyzer('cada1f9dV = cada1td1;',cada1f9dV,'cada1f9dV',0);
        cada1f9 = cada1f8.*at.f;
        cada1f9 = adigatorVarAnalyzer('cada1f9 = cada1f8.*at.f;',cada1f9,'cada1f9',0);
        cada1tf1 = w.f(:,Gator1Data.Index165);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = w.f(:,Gator1Data.Index165);',cada1tf1,'cada1tf1',0);
        cada1td1 = cada1f9dV./cada1tf1;
        cada1td1 = adigatorVarAnalyzer('cada1td1 = cada1f9dV./cada1tf1;',cada1td1,'cada1td1',0);
        cada1tf1 = cada1f9(:,Gator1Data.Index166);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f9(:,Gator1Data.Index166);',cada1tf1,'cada1tf1',0);
        cada1tf2 = w.f(:,Gator1Data.Index167);
        cada1tf2 = adigatorVarAnalyzer('cada1tf2 = w.f(:,Gator1Data.Index167);',cada1tf2,'cada1tf2',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index168) = cada1td1(:,Gator1Data.Index168) + -cada1tf1./cada1tf2.^2.*w.dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index168) = cada1td1(:,Gator1Data.Index168) + -cada1tf1./cada1tf2.^2.*w.dV;',cada1td1,'cada1td1',1);
        cada1f10dV = cada1td1;
        cada1f10dV = adigatorVarAnalyzer('cada1f10dV = cada1td1;',cada1f10dV,'cada1f10dV',0);
        cada1f10 = cada1f9./w.f;
        cada1f10 = adigatorVarAnalyzer('cada1f10 = cada1f9./w.f;',cada1f10,'cada1f10',0);
        cada1td1 = zeros(size(cada1f4dV,1),24);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(cada1f4dV,1),24);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index169) = cada1f4dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index169) = cada1f4dV;',cada1td1,'cada1td1',1);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index170) = cada1td1(:,Gator1Data.Index170) + cada1f10dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index170) = cada1td1(:,Gator1Data.Index170) + cada1f10dV;',cada1td1,'cada1td1',1);
        cada1f11dV = cada1td1;
        cada1f11dV = adigatorVarAnalyzer('cada1f11dV = cada1td1;',cada1f11dV,'cada1f11dV',0);
        cada1f11 = cada1f4 + cada1f10;
        cada1f11 = adigatorVarAnalyzer('cada1f11 = cada1f4 + cada1f10;',cada1f11,'cada1f11',0);
        cada1tf1 = L.f(:,Gator1Data.Index171);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = L.f(:,Gator1Data.Index171);',cada1tf1,'cada1tf1',0);
        cada1f12dV = cos(cada1tf1).*L.dV;
        cada1f12dV = adigatorVarAnalyzer('cada1f12dV = cos(cada1tf1).*L.dV;',cada1f12dV,'cada1f12dV',0);
        cada1f12 = sin(L.f);
        cada1f12 = adigatorVarAnalyzer('cada1f12 = sin(L.f);',cada1f12,'cada1f12',0);
        cada1tf1 = cada1f12(:,Gator1Data.Index172);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f12(:,Gator1Data.Index172);',cada1tf1,'cada1tf1',0);
        cada1td1 = zeros(size(Q2.dV,1),8);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(Q2.dV,1),8);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index173) = cada1tf1.*Q2.dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index173) = cada1tf1.*Q2.dV;',cada1td1,'cada1td1',1);
        cada1tf1 = Q2.f(:,Gator1Data.Index174);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = Q2.f(:,Gator1Data.Index174);',cada1tf1,'cada1tf1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index175) = cada1td1(:,Gator1Data.Index175) + cada1tf1.*cada1f12dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index175) = cada1td1(:,Gator1Data.Index175) + cada1tf1.*cada1f12dV;',cada1td1,'cada1td1',1);
        cada1f13dV = cada1td1;
        cada1f13dV = adigatorVarAnalyzer('cada1f13dV = cada1td1;',cada1f13dV,'cada1f13dV',0);
        cada1f13 = Q2.f.*cada1f12;
        cada1f13 = adigatorVarAnalyzer('cada1f13 = Q2.f.*cada1f12;',cada1f13,'cada1f13',0);
        cada1tf1 = L.f(:,Gator1Data.Index176);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = L.f(:,Gator1Data.Index176);',cada1tf1,'cada1tf1',0);
        cada1f14dV = -sin(cada1tf1).*L.dV;
        cada1f14dV = adigatorVarAnalyzer('cada1f14dV = -sin(cada1tf1).*L.dV;',cada1f14dV,'cada1f14dV',0);
        cada1f14 = cos(L.f);
        cada1f14 = adigatorVarAnalyzer('cada1f14 = cos(L.f);',cada1f14,'cada1f14',0);
        cada1tf1 = cada1f14(:,Gator1Data.Index177);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f14(:,Gator1Data.Index177);',cada1tf1,'cada1tf1',0);
        cada1td1 = zeros(size(Q1.dV,1),8);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(Q1.dV,1),8);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index178) = cada1tf1.*Q1.dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index178) = cada1tf1.*Q1.dV;',cada1td1,'cada1td1',1);
        cada1tf1 = Q1.f(:,Gator1Data.Index179);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = Q1.f(:,Gator1Data.Index179);',cada1tf1,'cada1tf1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index180) = cada1td1(:,Gator1Data.Index180) + cada1tf1.*cada1f14dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index180) = cada1td1(:,Gator1Data.Index180) + cada1tf1.*cada1f14dV;',cada1td1,'cada1td1',1);
        cada1f15dV = cada1td1;
        cada1f15dV = adigatorVarAnalyzer('cada1f15dV = cada1td1;',cada1f15dV,'cada1f15dV',0);
        cada1f15 = Q1.f.*cada1f14;
        cada1f15 = adigatorVarAnalyzer('cada1f15 = Q1.f.*cada1f14;',cada1f15,'cada1f15',0);
        cada1td1 = zeros(size(cada1f13dV,1),12);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(cada1f13dV,1),12);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index181) = cada1f13dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index181) = cada1f13dV;',cada1td1,'cada1td1',1);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index182) = cada1td1(:,Gator1Data.Index182) + -cada1f15dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index182) = cada1td1(:,Gator1Data.Index182) + -cada1f15dV;',cada1td1,'cada1td1',1);
        cada1f16dV = cada1td1;
        cada1f16dV = adigatorVarAnalyzer('cada1f16dV = cada1td1;',cada1f16dV,'cada1f16dV',0);
        cada1f16 = cada1f13 - cada1f15;
        cada1f16 = adigatorVarAnalyzer('cada1f16 = cada1f13 - cada1f15;',cada1f16,'cada1f16',0);
        cada1tf1 = P1.f(:,Gator1Data.Index183);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = P1.f(:,Gator1Data.Index183);',cada1tf1,'cada1tf1',0);
        cada1td1 = zeros(size(cada1f16dV,1),16);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(cada1f16dV,1),16);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index184) = cada1tf1.*cada1f16dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index184) = cada1tf1.*cada1f16dV;',cada1td1,'cada1td1',1);
        cada1tf1 = cada1f16(:,Gator1Data.Index185);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f16(:,Gator1Data.Index185);',cada1tf1,'cada1tf1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index186) = cada1td1(:,Gator1Data.Index186) + cada1tf1.*P1.dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index186) = cada1td1(:,Gator1Data.Index186) + cada1tf1.*P1.dV;',cada1td1,'cada1td1',1);
        cada1f17dV = cada1td1;
        cada1f17dV = adigatorVarAnalyzer('cada1f17dV = cada1td1;',cada1f17dV,'cada1f17dV',0);
        cada1f17 = cada1f16.*P1.f;
        cada1f17 = adigatorVarAnalyzer('cada1f17 = cada1f16.*P1.f;',cada1f17,'cada1f17',0);
        cada1tf1 = an.f(:,Gator1Data.Index187);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = an.f(:,Gator1Data.Index187);',cada1tf1,'cada1tf1',0);
        cada1td1 = zeros(size(cada1f17dV,1),24);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(cada1f17dV,1),24);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index188) = cada1tf1.*cada1f17dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index188) = cada1tf1.*cada1f17dV;',cada1td1,'cada1td1',1);
        cada1tf1 = cada1f17(:,Gator1Data.Index189);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f17(:,Gator1Data.Index189);',cada1tf1,'cada1tf1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index190) = cada1td1(:,Gator1Data.Index190) + cada1tf1.*an.dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index190) = cada1td1(:,Gator1Data.Index190) + cada1tf1.*an.dV;',cada1td1,'cada1td1',1);
        cada1f18dV = cada1td1;
        cada1f18dV = adigatorVarAnalyzer('cada1f18dV = cada1td1;',cada1f18dV,'cada1f18dV',0);
        cada1f18 = cada1f17.*an.f;
        cada1f18 = adigatorVarAnalyzer('cada1f18 = cada1f17.*an.f;',cada1f18,'cada1f18',0);
        cada1tf1 = w.f(:,Gator1Data.Index191);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = w.f(:,Gator1Data.Index191);',cada1tf1,'cada1tf1',0);
        cada1td1 = zeros(size(cada1f18dV,1),28);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(cada1f18dV,1),28);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index192) = cada1f18dV./cada1tf1;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index192) = cada1f18dV./cada1tf1;',cada1td1,'cada1td1',1);
        cada1tf1 = cada1f18(:,Gator1Data.Index193);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f18(:,Gator1Data.Index193);',cada1tf1,'cada1tf1',0);
        cada1tf2 = w.f(:,Gator1Data.Index194);
        cada1tf2 = adigatorVarAnalyzer('cada1tf2 = w.f(:,Gator1Data.Index194);',cada1tf2,'cada1tf2',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index195) = cada1td1(:,Gator1Data.Index195) + -cada1tf1./cada1tf2.^2.*w.dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index195) = cada1td1(:,Gator1Data.Index195) + -cada1tf1./cada1tf2.^2.*w.dV;',cada1td1,'cada1td1',1);
        cada1f19dV = cada1td1;
        cada1f19dV = adigatorVarAnalyzer('cada1f19dV = cada1td1;',cada1f19dV,'cada1f19dV',0);
        cada1f19 = cada1f18./w.f;
        cada1f19 = adigatorVarAnalyzer('cada1f19 = cada1f18./w.f;',cada1f19,'cada1f19',0);
        cada1td1 = zeros(size(cada1f11dV,1),36);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(cada1f11dV,1),36);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index196) = cada1f11dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index196) = cada1f11dV;',cada1td1,'cada1td1',1);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index197) = cada1td1(:,Gator1Data.Index197) + -cada1f19dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index197) = cada1td1(:,Gator1Data.Index197) + -cada1f19dV;',cada1td1,'cada1td1',1);
        cada1f20dV = cada1td1;
        cada1f20dV = adigatorVarAnalyzer('cada1f20dV = cada1td1;',cada1f20dV,'cada1f20dV',0);
        cada1f20 = cada1f11 - cada1f19;
        cada1f20 = adigatorVarAnalyzer('cada1f20 = cada1f11 - cada1f19;',cada1f20,'cada1f20',0);
        cada1tf1 = cada1f20(:,Gator1Data.Index198);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f20(:,Gator1Data.Index198);',cada1tf1,'cada1tf1',0);
        cada1td1 = zeros(size(cada1f2dV,1),40);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(cada1f2dV,1),40);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index199) = cada1tf1.*cada1f2dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index199) = cada1tf1.*cada1f2dV;',cada1td1,'cada1td1',1);
        cada1tf1 = cada1f2(:,Gator1Data.Index200);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f2(:,Gator1Data.Index200);',cada1tf1,'cada1tf1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index201) = cada1td1(:,Gator1Data.Index201) + cada1tf1.*cada1f20dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index201) = cada1td1(:,Gator1Data.Index201) + cada1tf1.*cada1f20dV;',cada1td1,'cada1td1',1);
        if ~exist('P2dot','var'); P2dot = cadastruct([],'P2dot',[],0); end
        P2dot.dV = cada1td1;
        P2dot = adigatorVarAnalyzer('P2dot.dV = cada1td1;',P2dot,'P2dot',1);
        if ~exist('P2dot','var'); P2dot = cadastruct([],'P2dot',[],0); end
        P2dot.f = cada1f2.*cada1f20;
        P2dot = adigatorVarAnalyzer('P2dot.f = cada1f2.*cada1f20;',P2dot,'P2dot',1);
        adigatorVarAnalyzer('%User Line: P2dot  = sqrt(p./mu).*(ar.*sin(L)+                ((w+1).*cos(L)+P2).*at./w-                (Q2.*sin(L)-Q1.*cos(L)).*P1.*an./w);');
        cada1f1dV = p.dV./mu.f;
        cada1f1dV = adigatorVarAnalyzer('cada1f1dV = p.dV./mu.f;',cada1f1dV,'cada1f1dV',0);
        cada1f1 = p.f/mu.f;
        cada1f1 = adigatorVarAnalyzer('cada1f1 = p.f/mu.f;',cada1f1,'cada1f1',0);
        cada1tf1 = cada1f1(:,Gator1Data.Index202);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f1(:,Gator1Data.Index202);',cada1tf1,'cada1tf1',0);
        cada1f2dV = (1/2)./sqrt(cada1tf1).*cada1f1dV;
        cada1f2dV = adigatorVarAnalyzer('cada1f2dV = (1/2)./sqrt(cada1tf1).*cada1f1dV;',cada1f2dV,'cada1f2dV',0);
        if ~exist('cada1f2dV','var'); cada1f2dV = cadastruct([],'cada1f2dV',[],0); end
        cada1f2dV(cada1tf1 == 0 & cada1f1dV == 0) = 0;
        cada1f2dV = adigatorVarAnalyzer('cada1f2dV(cada1tf1 == 0 & cada1f1dV == 0) = 0;',cada1f2dV,'cada1f2dV',1);
        cada1f2 = sqrt(cada1f1);
        cada1f2 = adigatorVarAnalyzer('cada1f2 = sqrt(cada1f1);',cada1f2,'cada1f2',0);
        cada1f3dV = 2.*w.dV;
        cada1f3dV = adigatorVarAnalyzer('cada1f3dV = 2.*w.dV;',cada1f3dV,'cada1f3dV',0);
        cada1f3 = 2*w.f;
        cada1f3 = adigatorVarAnalyzer('cada1f3 = 2*w.f;',cada1f3,'cada1f3',0);
        cada1tf1 = cada1f3(:,Gator1Data.Index203);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f3(:,Gator1Data.Index203);',cada1tf1,'cada1tf1',0);
        cada1td1 = zeros(size(sSquare.dV,1),20);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(sSquare.dV,1),20);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index204) = sSquare.dV./cada1tf1;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index204) = sSquare.dV./cada1tf1;',cada1td1,'cada1td1',1);
        cada1tf1 = sSquare.f(:,Gator1Data.Index205);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = sSquare.f(:,Gator1Data.Index205);',cada1tf1,'cada1tf1',0);
        cada1tf2 = cada1f3(:,Gator1Data.Index206);
        cada1tf2 = adigatorVarAnalyzer('cada1tf2 = cada1f3(:,Gator1Data.Index206);',cada1tf2,'cada1tf2',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index207) = cada1td1(:,Gator1Data.Index207) + -cada1tf1./cada1tf2.^2.*cada1f3dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index207) = cada1td1(:,Gator1Data.Index207) + -cada1tf1./cada1tf2.^2.*cada1f3dV;',cada1td1,'cada1td1',1);
        cada1f4dV = cada1td1;
        cada1f4dV = adigatorVarAnalyzer('cada1f4dV = cada1td1;',cada1f4dV,'cada1f4dV',0);
        cada1f4 = sSquare.f./cada1f3;
        cada1f4 = adigatorVarAnalyzer('cada1f4 = sSquare.f./cada1f3;',cada1f4,'cada1f4',0);
        cada1tf1 = cada1f4(:,Gator1Data.Index208);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f4(:,Gator1Data.Index208);',cada1tf1,'cada1tf1',0);
        cada1td1 = zeros(size(cada1f2dV,1),24);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(cada1f2dV,1),24);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index209) = cada1tf1.*cada1f2dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index209) = cada1tf1.*cada1f2dV;',cada1td1,'cada1td1',1);
        cada1tf1 = cada1f2(:,Gator1Data.Index210);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f2(:,Gator1Data.Index210);',cada1tf1,'cada1tf1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index211) = cada1td1(:,Gator1Data.Index211) + cada1tf1.*cada1f4dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index211) = cada1td1(:,Gator1Data.Index211) + cada1tf1.*cada1f4dV;',cada1td1,'cada1td1',1);
        cada1f5dV = cada1td1;
        cada1f5dV = adigatorVarAnalyzer('cada1f5dV = cada1td1;',cada1f5dV,'cada1f5dV',0);
        cada1f5 = cada1f2.*cada1f4;
        cada1f5 = adigatorVarAnalyzer('cada1f5 = cada1f2.*cada1f4;',cada1f5,'cada1f5',0);
        cada1tf1 = an.f(:,Gator1Data.Index212);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = an.f(:,Gator1Data.Index212);',cada1tf1,'cada1tf1',0);
        cada1td1 = zeros(size(cada1f5dV,1),32);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(cada1f5dV,1),32);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index213) = cada1tf1.*cada1f5dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index213) = cada1tf1.*cada1f5dV;',cada1td1,'cada1td1',1);
        cada1tf1 = cada1f5(:,Gator1Data.Index214);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f5(:,Gator1Data.Index214);',cada1tf1,'cada1tf1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index215) = cada1td1(:,Gator1Data.Index215) + cada1tf1.*an.dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index215) = cada1td1(:,Gator1Data.Index215) + cada1tf1.*an.dV;',cada1td1,'cada1td1',1);
        cada1f6dV = cada1td1;
        cada1f6dV = adigatorVarAnalyzer('cada1f6dV = cada1td1;',cada1f6dV,'cada1f6dV',0);
        cada1f6 = cada1f5.*an.f;
        cada1f6 = adigatorVarAnalyzer('cada1f6 = cada1f5.*an.f;',cada1f6,'cada1f6',0);
        cada1tf1 = L.f(:,Gator1Data.Index216);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = L.f(:,Gator1Data.Index216);',cada1tf1,'cada1tf1',0);
        cada1f7dV = cos(cada1tf1).*L.dV;
        cada1f7dV = adigatorVarAnalyzer('cada1f7dV = cos(cada1tf1).*L.dV;',cada1f7dV,'cada1f7dV',0);
        cada1f7 = sin(L.f);
        cada1f7 = adigatorVarAnalyzer('cada1f7 = sin(L.f);',cada1f7,'cada1f7',0);
        cada1tf1 = cada1f7(:,Gator1Data.Index217);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f7(:,Gator1Data.Index217);',cada1tf1,'cada1tf1',0);
        cada1td1 = cada1tf1.*cada1f6dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1 = cada1tf1.*cada1f6dV;',cada1td1,'cada1td1',0);
        cada1tf1 = cada1f6(:,Gator1Data.Index218);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f6(:,Gator1Data.Index218);',cada1tf1,'cada1tf1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index219) = cada1td1(:,Gator1Data.Index219) + cada1tf1.*cada1f7dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index219) = cada1td1(:,Gator1Data.Index219) + cada1tf1.*cada1f7dV;',cada1td1,'cada1td1',1);
        if ~exist('Q1dot','var'); Q1dot = cadastruct([],'Q1dot',[],0); end
        Q1dot.dV = cada1td1;
        Q1dot = adigatorVarAnalyzer('Q1dot.dV = cada1td1;',Q1dot,'Q1dot',1);
        if ~exist('Q1dot','var'); Q1dot = cadastruct([],'Q1dot',[],0); end
        Q1dot.f = cada1f6.*cada1f7;
        Q1dot = adigatorVarAnalyzer('Q1dot.f = cada1f6.*cada1f7;',Q1dot,'Q1dot',1);
        adigatorVarAnalyzer('%User Line: Q1dot  = sqrt(p./mu).*(sSquare./(2*w)).*an.*sin(L);');
        cada1f1dV = p.dV./mu.f;
        cada1f1dV = adigatorVarAnalyzer('cada1f1dV = p.dV./mu.f;',cada1f1dV,'cada1f1dV',0);
        cada1f1 = p.f/mu.f;
        cada1f1 = adigatorVarAnalyzer('cada1f1 = p.f/mu.f;',cada1f1,'cada1f1',0);
        cada1tf1 = cada1f1(:,Gator1Data.Index220);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f1(:,Gator1Data.Index220);',cada1tf1,'cada1tf1',0);
        cada1f2dV = (1/2)./sqrt(cada1tf1).*cada1f1dV;
        cada1f2dV = adigatorVarAnalyzer('cada1f2dV = (1/2)./sqrt(cada1tf1).*cada1f1dV;',cada1f2dV,'cada1f2dV',0);
        if ~exist('cada1f2dV','var'); cada1f2dV = cadastruct([],'cada1f2dV',[],0); end
        cada1f2dV(cada1tf1 == 0 & cada1f1dV == 0) = 0;
        cada1f2dV = adigatorVarAnalyzer('cada1f2dV(cada1tf1 == 0 & cada1f1dV == 0) = 0;',cada1f2dV,'cada1f2dV',1);
        cada1f2 = sqrt(cada1f1);
        cada1f2 = adigatorVarAnalyzer('cada1f2 = sqrt(cada1f1);',cada1f2,'cada1f2',0);
        cada1f3dV = 2.*w.dV;
        cada1f3dV = adigatorVarAnalyzer('cada1f3dV = 2.*w.dV;',cada1f3dV,'cada1f3dV',0);
        cada1f3 = 2*w.f;
        cada1f3 = adigatorVarAnalyzer('cada1f3 = 2*w.f;',cada1f3,'cada1f3',0);
        cada1tf1 = cada1f3(:,Gator1Data.Index221);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f3(:,Gator1Data.Index221);',cada1tf1,'cada1tf1',0);
        cada1td1 = zeros(size(sSquare.dV,1),20);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(sSquare.dV,1),20);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index222) = sSquare.dV./cada1tf1;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index222) = sSquare.dV./cada1tf1;',cada1td1,'cada1td1',1);
        cada1tf1 = sSquare.f(:,Gator1Data.Index223);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = sSquare.f(:,Gator1Data.Index223);',cada1tf1,'cada1tf1',0);
        cada1tf2 = cada1f3(:,Gator1Data.Index224);
        cada1tf2 = adigatorVarAnalyzer('cada1tf2 = cada1f3(:,Gator1Data.Index224);',cada1tf2,'cada1tf2',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index225) = cada1td1(:,Gator1Data.Index225) + -cada1tf1./cada1tf2.^2.*cada1f3dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index225) = cada1td1(:,Gator1Data.Index225) + -cada1tf1./cada1tf2.^2.*cada1f3dV;',cada1td1,'cada1td1',1);
        cada1f4dV = cada1td1;
        cada1f4dV = adigatorVarAnalyzer('cada1f4dV = cada1td1;',cada1f4dV,'cada1f4dV',0);
        cada1f4 = sSquare.f./cada1f3;
        cada1f4 = adigatorVarAnalyzer('cada1f4 = sSquare.f./cada1f3;',cada1f4,'cada1f4',0);
        cada1tf1 = cada1f4(:,Gator1Data.Index226);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f4(:,Gator1Data.Index226);',cada1tf1,'cada1tf1',0);
        cada1td1 = zeros(size(cada1f2dV,1),24);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(cada1f2dV,1),24);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index227) = cada1tf1.*cada1f2dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index227) = cada1tf1.*cada1f2dV;',cada1td1,'cada1td1',1);
        cada1tf1 = cada1f2(:,Gator1Data.Index228);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f2(:,Gator1Data.Index228);',cada1tf1,'cada1tf1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index229) = cada1td1(:,Gator1Data.Index229) + cada1tf1.*cada1f4dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index229) = cada1td1(:,Gator1Data.Index229) + cada1tf1.*cada1f4dV;',cada1td1,'cada1td1',1);
        cada1f5dV = cada1td1;
        cada1f5dV = adigatorVarAnalyzer('cada1f5dV = cada1td1;',cada1f5dV,'cada1f5dV',0);
        cada1f5 = cada1f2.*cada1f4;
        cada1f5 = adigatorVarAnalyzer('cada1f5 = cada1f2.*cada1f4;',cada1f5,'cada1f5',0);
        cada1tf1 = an.f(:,Gator1Data.Index230);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = an.f(:,Gator1Data.Index230);',cada1tf1,'cada1tf1',0);
        cada1td1 = zeros(size(cada1f5dV,1),32);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(cada1f5dV,1),32);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index231) = cada1tf1.*cada1f5dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index231) = cada1tf1.*cada1f5dV;',cada1td1,'cada1td1',1);
        cada1tf1 = cada1f5(:,Gator1Data.Index232);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f5(:,Gator1Data.Index232);',cada1tf1,'cada1tf1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index233) = cada1td1(:,Gator1Data.Index233) + cada1tf1.*an.dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index233) = cada1td1(:,Gator1Data.Index233) + cada1tf1.*an.dV;',cada1td1,'cada1td1',1);
        cada1f6dV = cada1td1;
        cada1f6dV = adigatorVarAnalyzer('cada1f6dV = cada1td1;',cada1f6dV,'cada1f6dV',0);
        cada1f6 = cada1f5.*an.f;
        cada1f6 = adigatorVarAnalyzer('cada1f6 = cada1f5.*an.f;',cada1f6,'cada1f6',0);
        cada1tf1 = L.f(:,Gator1Data.Index234);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = L.f(:,Gator1Data.Index234);',cada1tf1,'cada1tf1',0);
        cada1f7dV = -sin(cada1tf1).*L.dV;
        cada1f7dV = adigatorVarAnalyzer('cada1f7dV = -sin(cada1tf1).*L.dV;',cada1f7dV,'cada1f7dV',0);
        cada1f7 = cos(L.f);
        cada1f7 = adigatorVarAnalyzer('cada1f7 = cos(L.f);',cada1f7,'cada1f7',0);
        cada1tf1 = cada1f7(:,Gator1Data.Index235);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f7(:,Gator1Data.Index235);',cada1tf1,'cada1tf1',0);
        cada1td1 = cada1tf1.*cada1f6dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1 = cada1tf1.*cada1f6dV;',cada1td1,'cada1td1',0);
        cada1tf1 = cada1f6(:,Gator1Data.Index236);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f6(:,Gator1Data.Index236);',cada1tf1,'cada1tf1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index237) = cada1td1(:,Gator1Data.Index237) + cada1tf1.*cada1f7dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index237) = cada1td1(:,Gator1Data.Index237) + cada1tf1.*cada1f7dV;',cada1td1,'cada1td1',1);
        if ~exist('Q2dot','var'); Q2dot = cadastruct([],'Q2dot',[],0); end
        Q2dot.dV = cada1td1;
        Q2dot = adigatorVarAnalyzer('Q2dot.dV = cada1td1;',Q2dot,'Q2dot',1);
        if ~exist('Q2dot','var'); Q2dot = cadastruct([],'Q2dot',[],0); end
        Q2dot.f = cada1f6.*cada1f7;
        Q2dot = adigatorVarAnalyzer('Q2dot.f = cada1f6.*cada1f7;',Q2dot,'Q2dot',1);
        adigatorVarAnalyzer('%User Line: Q2dot  = sqrt(p./mu).*(sSquare./(2*w)).*an.*cos(L);');
        cada1f1dV = mu.f.*p.dV;
        cada1f1dV = adigatorVarAnalyzer('cada1f1dV = mu.f.*p.dV;',cada1f1dV,'cada1f1dV',0);
        cada1f1 = mu.f*p.f;
        cada1f1 = adigatorVarAnalyzer('cada1f1 = mu.f*p.f;',cada1f1,'cada1f1',0);
        cada1tf1 = cada1f1(:,Gator1Data.Index238);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f1(:,Gator1Data.Index238);',cada1tf1,'cada1tf1',0);
        cada1f2dV = (1/2)./sqrt(cada1tf1).*cada1f1dV;
        cada1f2dV = adigatorVarAnalyzer('cada1f2dV = (1/2)./sqrt(cada1tf1).*cada1f1dV;',cada1f2dV,'cada1f2dV',0);
        if ~exist('cada1f2dV','var'); cada1f2dV = cadastruct([],'cada1f2dV',[],0); end
        cada1f2dV(cada1tf1 == 0 & cada1f1dV == 0) = 0;
        cada1f2dV = adigatorVarAnalyzer('cada1f2dV(cada1tf1 == 0 & cada1f1dV == 0) = 0;',cada1f2dV,'cada1f2dV',1);
        cada1f2 = sqrt(cada1f1);
        cada1f2 = adigatorVarAnalyzer('cada1f2 = sqrt(cada1f1);',cada1f2,'cada1f2',0);
        cada1tf1 = p.f(:,Gator1Data.Index239);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = p.f(:,Gator1Data.Index239);',cada1tf1,'cada1tf1',0);
        cada1td1 = zeros(size(w.dV,1),16);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(w.dV,1),16);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index240) = w.dV./cada1tf1;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index240) = w.dV./cada1tf1;',cada1td1,'cada1td1',1);
        cada1tf1 = w.f(:,Gator1Data.Index241);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = w.f(:,Gator1Data.Index241);',cada1tf1,'cada1tf1',0);
        cada1tf2 = p.f(:,Gator1Data.Index242);
        cada1tf2 = adigatorVarAnalyzer('cada1tf2 = p.f(:,Gator1Data.Index242);',cada1tf2,'cada1tf2',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index243) = cada1td1(:,Gator1Data.Index243) + -cada1tf1./cada1tf2.^2.*p.dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index243) = cada1td1(:,Gator1Data.Index243) + -cada1tf1./cada1tf2.^2.*p.dV;',cada1td1,'cada1td1',1);
        cada1f3dV = cada1td1;
        cada1f3dV = adigatorVarAnalyzer('cada1f3dV = cada1td1;',cada1f3dV,'cada1f3dV',0);
        cada1f3 = w.f./p.f;
        cada1f3 = adigatorVarAnalyzer('cada1f3 = w.f./p.f;',cada1f3,'cada1f3',0);
        cada1tf2 = cada1f3(:,Gator1Data.Index244);
        cada1tf2 = adigatorVarAnalyzer('cada1tf2 = cada1f3(:,Gator1Data.Index244);',cada1tf2,'cada1tf2',0);
        cada1f4dV = 2.*cada1tf2.^(2-1).*cada1f3dV;
        cada1f4dV = adigatorVarAnalyzer('cada1f4dV = 2.*cada1tf2.^(2-1).*cada1f3dV;',cada1f4dV,'cada1f4dV',0);
        cada1f4 = cada1f3.^2;
        cada1f4 = adigatorVarAnalyzer('cada1f4 = cada1f3.^2;',cada1f4,'cada1f4',0);
        cada1tf1 = cada1f4(:,Gator1Data.Index245);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f4(:,Gator1Data.Index245);',cada1tf1,'cada1tf1',0);
        cada1td1 = zeros(size(cada1f2dV,1),16);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(cada1f2dV,1),16);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index246) = cada1tf1.*cada1f2dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index246) = cada1tf1.*cada1f2dV;',cada1td1,'cada1td1',1);
        cada1tf1 = cada1f2(:,Gator1Data.Index247);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f2(:,Gator1Data.Index247);',cada1tf1,'cada1tf1',0);
        cada1td1 = cada1td1 + cada1tf1.*cada1f4dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1 = cada1td1 + cada1tf1.*cada1f4dV;',cada1td1,'cada1td1',0);
        cada1f5dV = cada1td1;
        cada1f5dV = adigatorVarAnalyzer('cada1f5dV = cada1td1;',cada1f5dV,'cada1f5dV',0);
        cada1f5 = cada1f2.*cada1f4;
        cada1f5 = adigatorVarAnalyzer('cada1f5 = cada1f2.*cada1f4;',cada1f5,'cada1f5',0);
        cada1f6dV = p.dV./mu.f;
        cada1f6dV = adigatorVarAnalyzer('cada1f6dV = p.dV./mu.f;',cada1f6dV,'cada1f6dV',0);
        cada1f6 = p.f/mu.f;
        cada1f6 = adigatorVarAnalyzer('cada1f6 = p.f/mu.f;',cada1f6,'cada1f6',0);
        cada1tf1 = cada1f6(:,Gator1Data.Index248);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f6(:,Gator1Data.Index248);',cada1tf1,'cada1tf1',0);
        cada1f7dV = (1/2)./sqrt(cada1tf1).*cada1f6dV;
        cada1f7dV = adigatorVarAnalyzer('cada1f7dV = (1/2)./sqrt(cada1tf1).*cada1f6dV;',cada1f7dV,'cada1f7dV',0);
        if ~exist('cada1f7dV','var'); cada1f7dV = cadastruct([],'cada1f7dV',[],0); end
        cada1f7dV(cada1tf1 == 0 & cada1f6dV == 0) = 0;
        cada1f7dV = adigatorVarAnalyzer('cada1f7dV(cada1tf1 == 0 & cada1f6dV == 0) = 0;',cada1f7dV,'cada1f7dV',1);
        cada1f7 = sqrt(cada1f6);
        cada1f7 = adigatorVarAnalyzer('cada1f7 = sqrt(cada1f6);',cada1f7,'cada1f7',0);
        cada1tf1 = L.f(:,Gator1Data.Index249);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = L.f(:,Gator1Data.Index249);',cada1tf1,'cada1tf1',0);
        cada1f8dV = cos(cada1tf1).*L.dV;
        cada1f8dV = adigatorVarAnalyzer('cada1f8dV = cos(cada1tf1).*L.dV;',cada1f8dV,'cada1f8dV',0);
        cada1f8 = sin(L.f);
        cada1f8 = adigatorVarAnalyzer('cada1f8 = sin(L.f);',cada1f8,'cada1f8',0);
        cada1tf1 = cada1f8(:,Gator1Data.Index250);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f8(:,Gator1Data.Index250);',cada1tf1,'cada1tf1',0);
        cada1td1 = zeros(size(Q2.dV,1),8);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(Q2.dV,1),8);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index251) = cada1tf1.*Q2.dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index251) = cada1tf1.*Q2.dV;',cada1td1,'cada1td1',1);
        cada1tf1 = Q2.f(:,Gator1Data.Index252);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = Q2.f(:,Gator1Data.Index252);',cada1tf1,'cada1tf1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index253) = cada1td1(:,Gator1Data.Index253) + cada1tf1.*cada1f8dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index253) = cada1td1(:,Gator1Data.Index253) + cada1tf1.*cada1f8dV;',cada1td1,'cada1td1',1);
        cada1f9dV = cada1td1;
        cada1f9dV = adigatorVarAnalyzer('cada1f9dV = cada1td1;',cada1f9dV,'cada1f9dV',0);
        cada1f9 = Q2.f.*cada1f8;
        cada1f9 = adigatorVarAnalyzer('cada1f9 = Q2.f.*cada1f8;',cada1f9,'cada1f9',0);
        cada1tf1 = L.f(:,Gator1Data.Index254);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = L.f(:,Gator1Data.Index254);',cada1tf1,'cada1tf1',0);
        cada1f10dV = -sin(cada1tf1).*L.dV;
        cada1f10dV = adigatorVarAnalyzer('cada1f10dV = -sin(cada1tf1).*L.dV;',cada1f10dV,'cada1f10dV',0);
        cada1f10 = cos(L.f);
        cada1f10 = adigatorVarAnalyzer('cada1f10 = cos(L.f);',cada1f10,'cada1f10',0);
        cada1tf1 = cada1f10(:,Gator1Data.Index255);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f10(:,Gator1Data.Index255);',cada1tf1,'cada1tf1',0);
        cada1td1 = zeros(size(Q1.dV,1),8);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(Q1.dV,1),8);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index256) = cada1tf1.*Q1.dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index256) = cada1tf1.*Q1.dV;',cada1td1,'cada1td1',1);
        cada1tf1 = Q1.f(:,Gator1Data.Index257);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = Q1.f(:,Gator1Data.Index257);',cada1tf1,'cada1tf1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index258) = cada1td1(:,Gator1Data.Index258) + cada1tf1.*cada1f10dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index258) = cada1td1(:,Gator1Data.Index258) + cada1tf1.*cada1f10dV;',cada1td1,'cada1td1',1);
        cada1f11dV = cada1td1;
        cada1f11dV = adigatorVarAnalyzer('cada1f11dV = cada1td1;',cada1f11dV,'cada1f11dV',0);
        cada1f11 = Q1.f.*cada1f10;
        cada1f11 = adigatorVarAnalyzer('cada1f11 = Q1.f.*cada1f10;',cada1f11,'cada1f11',0);
        cada1td1 = zeros(size(cada1f9dV,1),12);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(cada1f9dV,1),12);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index259) = cada1f9dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index259) = cada1f9dV;',cada1td1,'cada1td1',1);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index260) = cada1td1(:,Gator1Data.Index260) + -cada1f11dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index260) = cada1td1(:,Gator1Data.Index260) + -cada1f11dV;',cada1td1,'cada1td1',1);
        cada1f12dV = cada1td1;
        cada1f12dV = adigatorVarAnalyzer('cada1f12dV = cada1td1;',cada1f12dV,'cada1f12dV',0);
        cada1f12 = cada1f9 - cada1f11;
        cada1f12 = adigatorVarAnalyzer('cada1f12 = cada1f9 - cada1f11;',cada1f12,'cada1f12',0);
        cada1tf1 = cada1f12(:,Gator1Data.Index261);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f12(:,Gator1Data.Index261);',cada1tf1,'cada1tf1',0);
        cada1td1 = zeros(size(cada1f7dV,1),16);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(cada1f7dV,1),16);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index262) = cada1tf1.*cada1f7dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index262) = cada1tf1.*cada1f7dV;',cada1td1,'cada1td1',1);
        cada1tf1 = cada1f7(:,Gator1Data.Index263);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f7(:,Gator1Data.Index263);',cada1tf1,'cada1tf1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index264) = cada1td1(:,Gator1Data.Index264) + cada1tf1.*cada1f12dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index264) = cada1td1(:,Gator1Data.Index264) + cada1tf1.*cada1f12dV;',cada1td1,'cada1td1',1);
        cada1f13dV = cada1td1;
        cada1f13dV = adigatorVarAnalyzer('cada1f13dV = cada1td1;',cada1f13dV,'cada1f13dV',0);
        cada1f13 = cada1f7.*cada1f12;
        cada1f13 = adigatorVarAnalyzer('cada1f13 = cada1f7.*cada1f12;',cada1f13,'cada1f13',0);
        cada1tf1 = an.f(:,Gator1Data.Index265);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = an.f(:,Gator1Data.Index265);',cada1tf1,'cada1tf1',0);
        cada1td1 = zeros(size(cada1f13dV,1),24);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(cada1f13dV,1),24);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index266) = cada1tf1.*cada1f13dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index266) = cada1tf1.*cada1f13dV;',cada1td1,'cada1td1',1);
        cada1tf1 = cada1f13(:,Gator1Data.Index267);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f13(:,Gator1Data.Index267);',cada1tf1,'cada1tf1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index268) = cada1td1(:,Gator1Data.Index268) + cada1tf1.*an.dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index268) = cada1td1(:,Gator1Data.Index268) + cada1tf1.*an.dV;',cada1td1,'cada1td1',1);
        cada1f14dV = cada1td1;
        cada1f14dV = adigatorVarAnalyzer('cada1f14dV = cada1td1;',cada1f14dV,'cada1f14dV',0);
        cada1f14 = cada1f13.*an.f;
        cada1f14 = adigatorVarAnalyzer('cada1f14 = cada1f13.*an.f;',cada1f14,'cada1f14',0);
        cada1tf1 = w.f(:,Gator1Data.Index269);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = w.f(:,Gator1Data.Index269);',cada1tf1,'cada1tf1',0);
        cada1td1 = zeros(size(cada1f14dV,1),32);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(cada1f14dV,1),32);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index270) = cada1f14dV./cada1tf1;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index270) = cada1f14dV./cada1tf1;',cada1td1,'cada1td1',1);
        cada1tf1 = cada1f14(:,Gator1Data.Index271);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f14(:,Gator1Data.Index271);',cada1tf1,'cada1tf1',0);
        cada1tf2 = w.f(:,Gator1Data.Index272);
        cada1tf2 = adigatorVarAnalyzer('cada1tf2 = w.f(:,Gator1Data.Index272);',cada1tf2,'cada1tf2',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index273) = cada1td1(:,Gator1Data.Index273) + -cada1tf1./cada1tf2.^2.*w.dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index273) = cada1td1(:,Gator1Data.Index273) + -cada1tf1./cada1tf2.^2.*w.dV;',cada1td1,'cada1td1',1);
        cada1f15dV = cada1td1;
        cada1f15dV = adigatorVarAnalyzer('cada1f15dV = cada1td1;',cada1f15dV,'cada1f15dV',0);
        cada1f15 = cada1f14./w.f;
        cada1f15 = adigatorVarAnalyzer('cada1f15 = cada1f14./w.f;',cada1f15,'cada1f15',0);
        cada1td1 = zeros(size(cada1f5dV,1),32);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(cada1f5dV,1),32);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index274) = cada1f5dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index274) = cada1f5dV;',cada1td1,'cada1td1',1);
        cada1td1 = cada1td1 + cada1f15dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1 = cada1td1 + cada1f15dV;',cada1td1,'cada1td1',0);
        if ~exist('Ldot','var'); Ldot = cadastruct([],'Ldot',[],0); end
        Ldot.dV = cada1td1;
        Ldot = adigatorVarAnalyzer('Ldot.dV = cada1td1;',Ldot,'Ldot',1);
        if ~exist('Ldot','var'); Ldot = cadastruct([],'Ldot',[],0); end
        Ldot.f = cada1f5 + cada1f15;
        Ldot = adigatorVarAnalyzer('Ldot.f = cada1f5 + cada1f15;',Ldot,'Ldot',1);
        adigatorVarAnalyzer('%User Line: Ldot  = sqrt(mu.*p).*(w./p).^2+                sqrt(p./mu).*(Q2.*sin(L)-Q1.*cos(L)).*an./w;');
        cada1f1 = uminus(T.f);
        cada1f1 = adigatorVarAnalyzer('cada1f1 = uminus(T.f);',cada1f1,'cada1f1',0);
        cada1f2 = g0.f*Isp.f;
        cada1f2 = adigatorVarAnalyzer('cada1f2 = g0.f*Isp.f;',cada1f2,'cada1f2',0);
        cada1f3 = cada1f1/cada1f2;
        cada1f3 = adigatorVarAnalyzer('cada1f3 = cada1f1/cada1f2;',cada1f3,'cada1f3',0);
        cada1f4 = size(t.f);
        cada1f4 = adigatorVarAnalyzer('cada1f4 = size(t.f);',cada1f4,'cada1f4',0);
        cada1f5 = ones(cada1f4(1),1);
        cada1f5 = adigatorVarAnalyzer('cada1f5 = ones(cada1f4(1),1);',cada1f5,'cada1f5',0);
        if ~exist('mdot','var'); mdot = cadastruct([],'mdot',[],0); end
        mdot.f = cada1f3*cada1f5;
        mdot = adigatorVarAnalyzer('mdot.f = cada1f3*cada1f5;',mdot,'mdot',1);
        adigatorVarAnalyzer('%User Line: mdot    = -T/(g0*Isp)*ones(size(t));');
        adigatorVarAnalyzer('%User Line: %dyna  = [pdot,P1dot,P2dot,Q1dot,Q2dot,Ldot,mdot];');
        adigatorVarAnalyzer('%User Line: %dyna4 = [dyna4 dyna];');
        cada1td1 = zeros(size(pdot.f,1),196);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(pdot.f,1),196);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index275) = pdot.dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index275) = pdot.dV;',cada1td1,'cada1td1',1);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index276) = P1dot.dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index276) = P1dot.dV;',cada1td1,'cada1td1',1);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index277) = P2dot.dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index277) = P2dot.dV;',cada1td1,'cada1td1',1);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index278) = Q1dot.dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index278) = Q1dot.dV;',cada1td1,'cada1td1',1);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index279) = Q2dot.dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index279) = Q2dot.dV;',cada1td1,'cada1td1',1);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index280) = Ldot.dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index280) = Ldot.dV;',cada1td1,'cada1td1',1);
        cada1f1dV = cada1td1;
        cada1f1dV = adigatorVarAnalyzer('cada1f1dV = cada1td1;',cada1f1dV,'cada1f1dV',0);
        cada1f1 = [pdot.f P1dot.f P2dot.f Q1dot.f Q2dot.f Ldot.f mdot.f];
        cada1f1 = adigatorVarAnalyzer('cada1f1 = [pdot.f P1dot.f P2dot.f Q1dot.f Q2dot.f Ldot.f mdot.f];',cada1f1,'cada1f1',0);
        cada1f2 = i.f - 1;
        cada1f2 = adigatorVarAnalyzer('cada1f2 = i.f - 1;',cada1f2,'cada1f2',0);
        cada1f3 = cada1f2*7;
        cada1f3 = adigatorVarAnalyzer('cada1f3 = cada1f2*7;',cada1f3,'cada1f3',0);
        cada1f4 = Gator1Data.Data1 + cada1f3;
        cada1f4 = adigatorVarAnalyzer('cada1f4 = Gator1Data.Data1 + cada1f3;',cada1f4,'cada1f4',0);
        if ~exist('dyna4','var'); dyna4 = cadastruct([],'dyna4',[],0); end
        dyna4.dV(:,logical(Gator1Data.Index17(:,cadaforcount4))) = cada1f1dV(:,nonzeros(Gator1Data.Index17(:,cadaforcount4)));
        dyna4 = adigatorVarAnalyzer('dyna4.dV(:,logical(Gator1Data.Index17(:,cadaforcount4))) = cada1f1dV(:,nonzeros(Gator1Data.Index17(:,cadaforcount4)));',dyna4,'dyna4',1);
        if ~exist('dyna4','var'); dyna4 = cadastruct([],'dyna4',[],0); end
        dyna4.f(:,cada1f4) = cada1f1;
        dyna4 = adigatorVarAnalyzer('dyna4.f(:,cada1f4) = cada1f1;',dyna4,'dyna4',1);
        adigatorVarAnalyzer('%User Line: dyna4(:,(1:7)+(i-1)*7) = [pdot,P1dot,P2dot,Q1dot,Q2dot,Ldot,mdot];');
    [adigatorForEvalStr, adigatorForEvalVar]= adigatorForIterEnd(4,adigatorForVariable4i);
    if ~isempty(adigatorForEvalStr)
        adigatorSetCellEvalFlag(1); cellfun(@eval,adigatorForEvalStr); adigatorSetCellEvalFlag(0);
    end
    end
    % ADiGator FOR Statement #4: END
    if ~exist('output','var'); output = cadastruct([],'output',[],0); end
    output(iphase.f).dynamics.dV = dyna4.dV;
    output = adigatorVarAnalyzer('output(iphase.f).dynamics.dV = dyna4.dV;',output,'output',1);
    if ~exist('output','var'); output = cadastruct([],'output',[],0); end
    output(iphase.f).dynamics.f = dyna4.f;
    output = adigatorVarAnalyzer('output(iphase.f).dynamics.f = dyna4.f;',output,'output',1);
    adigatorVarAnalyzer('%User Line: output(iphase).dynamics  = dyna4;');
    if ~exist('output','var'); output = cadastruct([],'output',[],0); end
    output(iphase.f).path.dV = path4.dV;
    output = adigatorVarAnalyzer('output(iphase.f).path.dV = path4.dV;',output,'output',1);
    if ~exist('output','var'); output = cadastruct([],'output',[],0); end
    output(iphase.f).path.f = path4.f;
    output = adigatorVarAnalyzer('output(iphase.f).path.f = path4.f;',output,'output',1);
    adigatorVarAnalyzer('%User Line: output(iphase).path      = path4;');
[adigatorForEvalStr, adigatorForEvalVar]= adigatorForIterEnd(3,adigatorForVariable3i);
if ~isempty(adigatorForEvalStr)
    adigatorSetCellEvalFlag(1); cellfun(@eval,adigatorForEvalStr); adigatorSetCellEvalFlag(0);
end
end
% ADiGator FOR Statement #3: END
if ~exist('cadaforvar5','var'); cadaforvar5 = cadastruct([],'cadaforvar5',[],0); end
cadaforvar5.f =  5;
cadaforvar5 = adigatorVarAnalyzer('cadaforvar5.f =  5;',cadaforvar5,'cadaforvar5',1);
adigatorVarAnalyzer('%User Line: cadaforvar5 = 5;');
if ~exist('output','var'); output = cadastruct([],'output',[],0); end
output(1,5).dynamics.dV = zeros(0,48);
output = adigatorVarAnalyzer('output(1,5).dynamics.dV = zeros(0,48);',output,'output',1);
if ~exist('output','var'); output = cadastruct([],'output',[],0); end
output(1,5).dynamics.f = zeros(0,24);
output = adigatorVarAnalyzer('output(1,5).dynamics.f = zeros(0,24);',output,'output',1);
% ADiGator FOR Statement #5: START
[adigatorForVariable5, adigatorForEvalStr, adigatorForEvalVar] = adigatorForInitialize(5,1:1,0);%#ok<NASGU>
if ~isempty(adigatorForEvalStr)
    adigatorSetCellEvalFlag(1); cellfun(@eval,adigatorForEvalStr); adigatorSetCellEvalFlag(0);
end
for adigatorForVariable5i = adigatorForVariable5
cadaforcount5 = adigatorForIterStart(5,adigatorForVariable5i);
    if ~exist('iphase','var'); iphase = cadastruct([],'iphase',[],0); end
    iphase.f = cadaforvar5.f(:,cadaforcount5);
    iphase = adigatorVarAnalyzer('iphase.f = cadaforvar5.f(:,cadaforcount5);',iphase,'iphase',1);
    adigatorVarAnalyzer('%User Line: iphase = cadaforvar5(:,cadaforcount5);');
    adigatorVarAnalyzer('%User Line: %dyna4 = [];');
    cada1tempf1 = input.phase(iphase.f).time.f;
    cada1tempf1 = adigatorVarAnalyzer('cada1tempf1 = input.phase(iphase.f).time.f;',cada1tempf1,'cada1tempf1',0);
    cada1f1 = cada1tempf1;
    cada1f1 = adigatorVarAnalyzer('cada1f1 = cada1tempf1;',cada1f1,'cada1f1',0);
    cada1f2 = length(cada1f1);
    cada1f2 = adigatorVarAnalyzer('cada1f2 = length(cada1f1);',cada1f2,'cada1f2',0);
    if ~exist('dyna4','var'); dyna4 = cadastruct([],'dyna4',[],0); end
    dyna4.f = zeros(cada1f2,24);
    dyna4 = adigatorVarAnalyzer('dyna4.f = zeros(cada1f2,24);',dyna4,'dyna4',1);
    if ~exist('dyna4','var'); dyna4 = cadastruct([],'dyna4',[],0); end
    dyna4.dV = zeros(size(dyna4.f,1),48);
    dyna4 = adigatorVarAnalyzer('dyna4.dV = zeros(size(dyna4.f,1),48);',dyna4,'dyna4',1);
    adigatorVarAnalyzer('%User Line: dyna4 = zeros(length(input.phase(iphase).time),24);');
    if ~exist('cadaforvar6','var'); cadaforvar6 = cadastruct([],'cadaforvar6',[],0); end
    cadaforvar6.f =  1:4;
    cadaforvar6 = adigatorVarAnalyzer('cadaforvar6.f =  1:4;',cadaforvar6,'cadaforvar6',1);
    adigatorVarAnalyzer('%User Line: cadaforvar6 = 1:4;');
    % ADiGator FOR Statement #6: START
    adigatorForVariable6 = adigatorForInitialize(6,1:4,0);
    for adigatorForVariable6i = adigatorForVariable6
    cadaforcount6 = adigatorForIterStart(6,adigatorForVariable6i);
        if ~exist('i','var'); i = cadastruct([],'i',[],0); end
        i.f = cadaforvar6.f(:,cadaforcount6);
        i = adigatorVarAnalyzer('i.f = cadaforvar6.f(:,cadaforcount6);',i,'i',1);
        adigatorVarAnalyzer('%User Line: i = cadaforvar6(:,cadaforcount6);');
        cada1f1 = i.f - 1;
        cada1f1 = adigatorVarAnalyzer('cada1f1 = i.f - 1;',cada1f1,'cada1f1',0);
        cada1f2 = 6*cada1f1;
        cada1f2 = adigatorVarAnalyzer('cada1f2 = 6*cada1f1;',cada1f2,'cada1f2',0);
        cada1f3 = cada1f2 + 1;
        cada1f3 = adigatorVarAnalyzer('cada1f3 = cada1f2 + 1;',cada1f3,'cada1f3',0);
        cada1tempf1 = input.phase(iphase.f).state.f;
        cada1tempf1 = adigatorVarAnalyzer('cada1tempf1 = input.phase(iphase.f).state.f;',cada1tempf1,'cada1tempf1',0);
        if ~exist('rx','var'); rx = cadastruct([],'rx',[],0); end
        rx.dV = input.phase(iphase.f).state.dV;
        rx = adigatorVarAnalyzer('rx.dV = input.phase(iphase.f).state.dV;',rx,'rx',1);
        if ~exist('rx','var'); rx = cadastruct([],'rx',[],0); end
        rx.f = cada1tempf1;
        rx = adigatorVarAnalyzer('rx.f = cada1tempf1;',rx,'rx',1);
        cada1td1 = zeros(size(rx.f,1),4);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(rx.f,1),4);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,logical(Gator1Data.Index18(:,cadaforcount6))) = rx.dV(:,nonzeros(Gator1Data.Index18(:,cadaforcount6)));
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,logical(Gator1Data.Index18(:,cadaforcount6))) = rx.dV(:,nonzeros(Gator1Data.Index18(:,cadaforcount6)));',cada1td1,'cada1td1',1);
        if ~exist('rx','var'); rx = cadastruct([],'rx',[],0); end
        rx.dV = cada1td1;
        rx = adigatorVarAnalyzer('rx.dV = cada1td1;',rx,'rx',1);
        if ~exist('rx','var'); rx = cadastruct([],'rx',[],0); end
        rx.f = rx.f(:,cada1f3);
        rx = adigatorVarAnalyzer('rx.f = rx.f(:,cada1f3);',rx,'rx',1);
        adigatorVarAnalyzer('%User Line: rx = input.phase(iphase).state(:, 6*(i - 1) + 1);');
        cada1f1 = i.f - 1;
        cada1f1 = adigatorVarAnalyzer('cada1f1 = i.f - 1;',cada1f1,'cada1f1',0);
        cada1f2 = 6*cada1f1;
        cada1f2 = adigatorVarAnalyzer('cada1f2 = 6*cada1f1;',cada1f2,'cada1f2',0);
        cada1f3 = cada1f2 + 2;
        cada1f3 = adigatorVarAnalyzer('cada1f3 = cada1f2 + 2;',cada1f3,'cada1f3',0);
        cada1tempf1 = input.phase(iphase.f).state.f;
        cada1tempf1 = adigatorVarAnalyzer('cada1tempf1 = input.phase(iphase.f).state.f;',cada1tempf1,'cada1tempf1',0);
        if ~exist('ry','var'); ry = cadastruct([],'ry',[],0); end
        ry.dV = input.phase(iphase.f).state.dV;
        ry = adigatorVarAnalyzer('ry.dV = input.phase(iphase.f).state.dV;',ry,'ry',1);
        if ~exist('ry','var'); ry = cadastruct([],'ry',[],0); end
        ry.f = cada1tempf1;
        ry = adigatorVarAnalyzer('ry.f = cada1tempf1;',ry,'ry',1);
        cada1td1 = zeros(size(ry.f,1),4);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(ry.f,1),4);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,logical(Gator1Data.Index19(:,cadaforcount6))) = ry.dV(:,nonzeros(Gator1Data.Index19(:,cadaforcount6)));
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,logical(Gator1Data.Index19(:,cadaforcount6))) = ry.dV(:,nonzeros(Gator1Data.Index19(:,cadaforcount6)));',cada1td1,'cada1td1',1);
        if ~exist('ry','var'); ry = cadastruct([],'ry',[],0); end
        ry.dV = cada1td1;
        ry = adigatorVarAnalyzer('ry.dV = cada1td1;',ry,'ry',1);
        if ~exist('ry','var'); ry = cadastruct([],'ry',[],0); end
        ry.f = ry.f(:,cada1f3);
        ry = adigatorVarAnalyzer('ry.f = ry.f(:,cada1f3);',ry,'ry',1);
        adigatorVarAnalyzer('%User Line: ry = input.phase(iphase).state(:, 6*(i - 1) + 2);');
        cada1f1 = i.f - 1;
        cada1f1 = adigatorVarAnalyzer('cada1f1 = i.f - 1;',cada1f1,'cada1f1',0);
        cada1f2 = 6*cada1f1;
        cada1f2 = adigatorVarAnalyzer('cada1f2 = 6*cada1f1;',cada1f2,'cada1f2',0);
        cada1f3 = cada1f2 + 3;
        cada1f3 = adigatorVarAnalyzer('cada1f3 = cada1f2 + 3;',cada1f3,'cada1f3',0);
        cada1tempf1 = input.phase(iphase.f).state.f;
        cada1tempf1 = adigatorVarAnalyzer('cada1tempf1 = input.phase(iphase.f).state.f;',cada1tempf1,'cada1tempf1',0);
        if ~exist('rz','var'); rz = cadastruct([],'rz',[],0); end
        rz.dV = input.phase(iphase.f).state.dV;
        rz = adigatorVarAnalyzer('rz.dV = input.phase(iphase.f).state.dV;',rz,'rz',1);
        if ~exist('rz','var'); rz = cadastruct([],'rz',[],0); end
        rz.f = cada1tempf1;
        rz = adigatorVarAnalyzer('rz.f = cada1tempf1;',rz,'rz',1);
        cada1td1 = zeros(size(rz.f,1),4);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(rz.f,1),4);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,logical(Gator1Data.Index20(:,cadaforcount6))) = rz.dV(:,nonzeros(Gator1Data.Index20(:,cadaforcount6)));
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,logical(Gator1Data.Index20(:,cadaforcount6))) = rz.dV(:,nonzeros(Gator1Data.Index20(:,cadaforcount6)));',cada1td1,'cada1td1',1);
        if ~exist('rz','var'); rz = cadastruct([],'rz',[],0); end
        rz.dV = cada1td1;
        rz = adigatorVarAnalyzer('rz.dV = cada1td1;',rz,'rz',1);
        if ~exist('rz','var'); rz = cadastruct([],'rz',[],0); end
        rz.f = rz.f(:,cada1f3);
        rz = adigatorVarAnalyzer('rz.f = rz.f(:,cada1f3);',rz,'rz',1);
        adigatorVarAnalyzer('%User Line: rz = input.phase(iphase).state(:, 6*(i - 1) + 3);');
        cada1f1 = i.f - 1;
        cada1f1 = adigatorVarAnalyzer('cada1f1 = i.f - 1;',cada1f1,'cada1f1',0);
        cada1f2 = 6*cada1f1;
        cada1f2 = adigatorVarAnalyzer('cada1f2 = 6*cada1f1;',cada1f2,'cada1f2',0);
        cada1f3 = cada1f2 + 4;
        cada1f3 = adigatorVarAnalyzer('cada1f3 = cada1f2 + 4;',cada1f3,'cada1f3',0);
        cada1tempf1 = input.phase(iphase.f).state.f;
        cada1tempf1 = adigatorVarAnalyzer('cada1tempf1 = input.phase(iphase.f).state.f;',cada1tempf1,'cada1tempf1',0);
        if ~exist('vx','var'); vx = cadastruct([],'vx',[],0); end
        vx.dV = input.phase(iphase.f).state.dV;
        vx = adigatorVarAnalyzer('vx.dV = input.phase(iphase.f).state.dV;',vx,'vx',1);
        if ~exist('vx','var'); vx = cadastruct([],'vx',[],0); end
        vx.f = cada1tempf1;
        vx = adigatorVarAnalyzer('vx.f = cada1tempf1;',vx,'vx',1);
        cada1td1 = zeros(size(vx.f,1),4);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(vx.f,1),4);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,logical(Gator1Data.Index21(:,cadaforcount6))) = vx.dV(:,nonzeros(Gator1Data.Index21(:,cadaforcount6)));
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,logical(Gator1Data.Index21(:,cadaforcount6))) = vx.dV(:,nonzeros(Gator1Data.Index21(:,cadaforcount6)));',cada1td1,'cada1td1',1);
        if ~exist('vx','var'); vx = cadastruct([],'vx',[],0); end
        vx.dV = cada1td1;
        vx = adigatorVarAnalyzer('vx.dV = cada1td1;',vx,'vx',1);
        if ~exist('vx','var'); vx = cadastruct([],'vx',[],0); end
        vx.f = vx.f(:,cada1f3);
        vx = adigatorVarAnalyzer('vx.f = vx.f(:,cada1f3);',vx,'vx',1);
        adigatorVarAnalyzer('%User Line: vx = input.phase(iphase).state(:, 6*(i - 1) + 4);');
        cada1f1 = i.f - 1;
        cada1f1 = adigatorVarAnalyzer('cada1f1 = i.f - 1;',cada1f1,'cada1f1',0);
        cada1f2 = 6*cada1f1;
        cada1f2 = adigatorVarAnalyzer('cada1f2 = 6*cada1f1;',cada1f2,'cada1f2',0);
        cada1f3 = cada1f2 + 5;
        cada1f3 = adigatorVarAnalyzer('cada1f3 = cada1f2 + 5;',cada1f3,'cada1f3',0);
        cada1tempf1 = input.phase(iphase.f).state.f;
        cada1tempf1 = adigatorVarAnalyzer('cada1tempf1 = input.phase(iphase.f).state.f;',cada1tempf1,'cada1tempf1',0);
        if ~exist('vy','var'); vy = cadastruct([],'vy',[],0); end
        vy.dV = input.phase(iphase.f).state.dV;
        vy = adigatorVarAnalyzer('vy.dV = input.phase(iphase.f).state.dV;',vy,'vy',1);
        if ~exist('vy','var'); vy = cadastruct([],'vy',[],0); end
        vy.f = cada1tempf1;
        vy = adigatorVarAnalyzer('vy.f = cada1tempf1;',vy,'vy',1);
        cada1td1 = zeros(size(vy.f,1),4);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(vy.f,1),4);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,logical(Gator1Data.Index22(:,cadaforcount6))) = vy.dV(:,nonzeros(Gator1Data.Index22(:,cadaforcount6)));
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,logical(Gator1Data.Index22(:,cadaforcount6))) = vy.dV(:,nonzeros(Gator1Data.Index22(:,cadaforcount6)));',cada1td1,'cada1td1',1);
        if ~exist('vy','var'); vy = cadastruct([],'vy',[],0); end
        vy.dV = cada1td1;
        vy = adigatorVarAnalyzer('vy.dV = cada1td1;',vy,'vy',1);
        if ~exist('vy','var'); vy = cadastruct([],'vy',[],0); end
        vy.f = vy.f(:,cada1f3);
        vy = adigatorVarAnalyzer('vy.f = vy.f(:,cada1f3);',vy,'vy',1);
        adigatorVarAnalyzer('%User Line: vy = input.phase(iphase).state(:, 6*(i - 1) + 5);');
        cada1f1 = i.f - 1;
        cada1f1 = adigatorVarAnalyzer('cada1f1 = i.f - 1;',cada1f1,'cada1f1',0);
        cada1f2 = 6*cada1f1;
        cada1f2 = adigatorVarAnalyzer('cada1f2 = 6*cada1f1;',cada1f2,'cada1f2',0);
        cada1f3 = cada1f2 + 6;
        cada1f3 = adigatorVarAnalyzer('cada1f3 = cada1f2 + 6;',cada1f3,'cada1f3',0);
        cada1tempf1 = input.phase(iphase.f).state.f;
        cada1tempf1 = adigatorVarAnalyzer('cada1tempf1 = input.phase(iphase.f).state.f;',cada1tempf1,'cada1tempf1',0);
        if ~exist('vz','var'); vz = cadastruct([],'vz',[],0); end
        vz.dV = input.phase(iphase.f).state.dV;
        vz = adigatorVarAnalyzer('vz.dV = input.phase(iphase.f).state.dV;',vz,'vz',1);
        if ~exist('vz','var'); vz = cadastruct([],'vz',[],0); end
        vz.f = cada1tempf1;
        vz = adigatorVarAnalyzer('vz.f = cada1tempf1;',vz,'vz',1);
        cada1td1 = zeros(size(vz.f,1),4);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(vz.f,1),4);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,logical(Gator1Data.Index23(:,cadaforcount6))) = vz.dV(:,nonzeros(Gator1Data.Index23(:,cadaforcount6)));
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,logical(Gator1Data.Index23(:,cadaforcount6))) = vz.dV(:,nonzeros(Gator1Data.Index23(:,cadaforcount6)));',cada1td1,'cada1td1',1);
        if ~exist('vz','var'); vz = cadastruct([],'vz',[],0); end
        vz.dV = cada1td1;
        vz = adigatorVarAnalyzer('vz.dV = cada1td1;',vz,'vz',1);
        if ~exist('vz','var'); vz = cadastruct([],'vz',[],0); end
        vz.f = vz.f(:,cada1f3);
        vz = adigatorVarAnalyzer('vz.f = vz.f(:,cada1f3);',vz,'vz',1);
        adigatorVarAnalyzer('%User Line: vz = input.phase(iphase).state(:, 6*(i - 1) + 6);');
        cada1tf2 = rx.f(:,Gator1Data.Index281);
        cada1tf2 = adigatorVarAnalyzer('cada1tf2 = rx.f(:,Gator1Data.Index281);',cada1tf2,'cada1tf2',0);
        cada1f1dV = 2.*cada1tf2.^(2-1).*rx.dV;
        cada1f1dV = adigatorVarAnalyzer('cada1f1dV = 2.*cada1tf2.^(2-1).*rx.dV;',cada1f1dV,'cada1f1dV',0);
        cada1f1 = rx.f.^2;
        cada1f1 = adigatorVarAnalyzer('cada1f1 = rx.f.^2;',cada1f1,'cada1f1',0);
        cada1tf2 = ry.f(:,Gator1Data.Index282);
        cada1tf2 = adigatorVarAnalyzer('cada1tf2 = ry.f(:,Gator1Data.Index282);',cada1tf2,'cada1tf2',0);
        cada1f2dV = 2.*cada1tf2.^(2-1).*ry.dV;
        cada1f2dV = adigatorVarAnalyzer('cada1f2dV = 2.*cada1tf2.^(2-1).*ry.dV;',cada1f2dV,'cada1f2dV',0);
        cada1f2 = ry.f.^2;
        cada1f2 = adigatorVarAnalyzer('cada1f2 = ry.f.^2;',cada1f2,'cada1f2',0);
        cada1td1 = zeros(size(cada1f1dV,1),8);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(cada1f1dV,1),8);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index283) = cada1f1dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index283) = cada1f1dV;',cada1td1,'cada1td1',1);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index284) = cada1td1(:,Gator1Data.Index284) + cada1f2dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index284) = cada1td1(:,Gator1Data.Index284) + cada1f2dV;',cada1td1,'cada1td1',1);
        cada1f3dV = cada1td1;
        cada1f3dV = adigatorVarAnalyzer('cada1f3dV = cada1td1;',cada1f3dV,'cada1f3dV',0);
        cada1f3 = cada1f1 + cada1f2;
        cada1f3 = adigatorVarAnalyzer('cada1f3 = cada1f1 + cada1f2;',cada1f3,'cada1f3',0);
        cada1tf2 = rz.f(:,Gator1Data.Index285);
        cada1tf2 = adigatorVarAnalyzer('cada1tf2 = rz.f(:,Gator1Data.Index285);',cada1tf2,'cada1tf2',0);
        cada1f4dV = 2.*cada1tf2.^(2-1).*rz.dV;
        cada1f4dV = adigatorVarAnalyzer('cada1f4dV = 2.*cada1tf2.^(2-1).*rz.dV;',cada1f4dV,'cada1f4dV',0);
        cada1f4 = rz.f.^2;
        cada1f4 = adigatorVarAnalyzer('cada1f4 = rz.f.^2;',cada1f4,'cada1f4',0);
        cada1td1 = zeros(size(cada1f3dV,1),12);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(cada1f3dV,1),12);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index286) = cada1f3dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index286) = cada1f3dV;',cada1td1,'cada1td1',1);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index287) = cada1td1(:,Gator1Data.Index287) + cada1f4dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index287) = cada1td1(:,Gator1Data.Index287) + cada1f4dV;',cada1td1,'cada1td1',1);
        cada1f5dV = cada1td1;
        cada1f5dV = adigatorVarAnalyzer('cada1f5dV = cada1td1;',cada1f5dV,'cada1f5dV',0);
        cada1f5 = cada1f3 + cada1f4;
        cada1f5 = adigatorVarAnalyzer('cada1f5 = cada1f3 + cada1f4;',cada1f5,'cada1f5',0);
        cada1tf1 = cada1f5(:,Gator1Data.Index288);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f5(:,Gator1Data.Index288);',cada1tf1,'cada1tf1',0);
        if ~exist('r','var'); r = cadastruct([],'r',[],0); end
        r.dV = (1/2)./sqrt(cada1tf1).*cada1f5dV;
        r = adigatorVarAnalyzer('r.dV = (1/2)./sqrt(cada1tf1).*cada1f5dV;',r,'r',1);
        if ~exist('r','var'); r = cadastruct([],'r',[],0); end
        r.dV(cada1tf1 == 0 & cada1f5dV == 0) = 0;
        r = adigatorVarAnalyzer('r.dV(cada1tf1 == 0 & cada1f5dV == 0) = 0;',r,'r',1);
        if ~exist('r','var'); r = cadastruct([],'r',[],0); end
        r.f = sqrt(cada1f5);
        r = adigatorVarAnalyzer('r.f = sqrt(cada1f5);',r,'r',1);
        adigatorVarAnalyzer('%User Line: r = sqrt(rx.^2 + ry.^2 + rz.^2);');
        if ~exist('rdotx','var'); rdotx = cadastruct([],'rdotx',[],0); end
        rdotx.dV = vx.dV;
        rdotx = adigatorVarAnalyzer('rdotx.dV = vx.dV;',rdotx,'rdotx',1);
        if ~exist('rdotx','var'); rdotx = cadastruct([],'rdotx',[],0); end
        rdotx.f = vx.f;
        rdotx = adigatorVarAnalyzer('rdotx.f = vx.f;',rdotx,'rdotx',1);
        adigatorVarAnalyzer('%User Line: rdotx  = vx;');
        if ~exist('rdoty','var'); rdoty = cadastruct([],'rdoty',[],0); end
        rdoty.dV = vy.dV;
        rdoty = adigatorVarAnalyzer('rdoty.dV = vy.dV;',rdoty,'rdoty',1);
        if ~exist('rdoty','var'); rdoty = cadastruct([],'rdoty',[],0); end
        rdoty.f = vy.f;
        rdoty = adigatorVarAnalyzer('rdoty.f = vy.f;',rdoty,'rdoty',1);
        adigatorVarAnalyzer('%User Line: rdoty  = vy;');
        if ~exist('rdotz','var'); rdotz = cadastruct([],'rdotz',[],0); end
        rdotz.dV = vz.dV;
        rdotz = adigatorVarAnalyzer('rdotz.dV = vz.dV;',rdotz,'rdotz',1);
        if ~exist('rdotz','var'); rdotz = cadastruct([],'rdotz',[],0); end
        rdotz.f = vz.f;
        rdotz = adigatorVarAnalyzer('rdotz.f = vz.f;',rdotz,'rdotz',1);
        adigatorVarAnalyzer('%User Line: rdotz  = vz;');
        cada1f1 = uminus(mu.f);
        cada1f1 = adigatorVarAnalyzer('cada1f1 = uminus(mu.f);',cada1f1,'cada1f1',0);
        cada1f2dV = cada1f1.*rx.dV;
        cada1f2dV = adigatorVarAnalyzer('cada1f2dV = cada1f1.*rx.dV;',cada1f2dV,'cada1f2dV',0);
        cada1f2 = cada1f1*rx.f;
        cada1f2 = adigatorVarAnalyzer('cada1f2 = cada1f1*rx.f;',cada1f2,'cada1f2',0);
        cada1tf2 = r.f(:,Gator1Data.Index289);
        cada1tf2 = adigatorVarAnalyzer('cada1tf2 = r.f(:,Gator1Data.Index289);',cada1tf2,'cada1tf2',0);
        cada1f3dV = 3.*cada1tf2.^(3-1).*r.dV;
        cada1f3dV = adigatorVarAnalyzer('cada1f3dV = 3.*cada1tf2.^(3-1).*r.dV;',cada1f3dV,'cada1f3dV',0);
        cada1f3 = r.f.^3;
        cada1f3 = adigatorVarAnalyzer('cada1f3 = r.f.^3;',cada1f3,'cada1f3',0);
        cada1tf1 = cada1f3(:,Gator1Data.Index290);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f3(:,Gator1Data.Index290);',cada1tf1,'cada1tf1',0);
        cada1td1 = zeros(size(cada1f2dV,1),12);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(cada1f2dV,1),12);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index291) = cada1f2dV./cada1tf1;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index291) = cada1f2dV./cada1tf1;',cada1td1,'cada1td1',1);
        cada1tf1 = cada1f2(:,Gator1Data.Index292);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f2(:,Gator1Data.Index292);',cada1tf1,'cada1tf1',0);
        cada1tf2 = cada1f3(:,Gator1Data.Index293);
        cada1tf2 = adigatorVarAnalyzer('cada1tf2 = cada1f3(:,Gator1Data.Index293);',cada1tf2,'cada1tf2',0);
        cada1td1 = cada1td1 + -cada1tf1./cada1tf2.^2.*cada1f3dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1 = cada1td1 + -cada1tf1./cada1tf2.^2.*cada1f3dV;',cada1td1,'cada1td1',0);
        if ~exist('vdotx','var'); vdotx = cadastruct([],'vdotx',[],0); end
        vdotx.dV = cada1td1;
        vdotx = adigatorVarAnalyzer('vdotx.dV = cada1td1;',vdotx,'vdotx',1);
        if ~exist('vdotx','var'); vdotx = cadastruct([],'vdotx',[],0); end
        vdotx.f = cada1f2./cada1f3;
        vdotx = adigatorVarAnalyzer('vdotx.f = cada1f2./cada1f3;',vdotx,'vdotx',1);
        adigatorVarAnalyzer('%User Line: vdotx  = -mu*rx./r.^3;');
        cada1f1 = uminus(mu.f);
        cada1f1 = adigatorVarAnalyzer('cada1f1 = uminus(mu.f);',cada1f1,'cada1f1',0);
        cada1f2dV = cada1f1.*ry.dV;
        cada1f2dV = adigatorVarAnalyzer('cada1f2dV = cada1f1.*ry.dV;',cada1f2dV,'cada1f2dV',0);
        cada1f2 = cada1f1*ry.f;
        cada1f2 = adigatorVarAnalyzer('cada1f2 = cada1f1*ry.f;',cada1f2,'cada1f2',0);
        cada1tf2 = r.f(:,Gator1Data.Index294);
        cada1tf2 = adigatorVarAnalyzer('cada1tf2 = r.f(:,Gator1Data.Index294);',cada1tf2,'cada1tf2',0);
        cada1f3dV = 3.*cada1tf2.^(3-1).*r.dV;
        cada1f3dV = adigatorVarAnalyzer('cada1f3dV = 3.*cada1tf2.^(3-1).*r.dV;',cada1f3dV,'cada1f3dV',0);
        cada1f3 = r.f.^3;
        cada1f3 = adigatorVarAnalyzer('cada1f3 = r.f.^3;',cada1f3,'cada1f3',0);
        cada1tf1 = cada1f3(:,Gator1Data.Index295);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f3(:,Gator1Data.Index295);',cada1tf1,'cada1tf1',0);
        cada1td1 = zeros(size(cada1f2dV,1),12);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(cada1f2dV,1),12);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index296) = cada1f2dV./cada1tf1;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index296) = cada1f2dV./cada1tf1;',cada1td1,'cada1td1',1);
        cada1tf1 = cada1f2(:,Gator1Data.Index297);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f2(:,Gator1Data.Index297);',cada1tf1,'cada1tf1',0);
        cada1tf2 = cada1f3(:,Gator1Data.Index298);
        cada1tf2 = adigatorVarAnalyzer('cada1tf2 = cada1f3(:,Gator1Data.Index298);',cada1tf2,'cada1tf2',0);
        cada1td1 = cada1td1 + -cada1tf1./cada1tf2.^2.*cada1f3dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1 = cada1td1 + -cada1tf1./cada1tf2.^2.*cada1f3dV;',cada1td1,'cada1td1',0);
        if ~exist('vdoty','var'); vdoty = cadastruct([],'vdoty',[],0); end
        vdoty.dV = cada1td1;
        vdoty = adigatorVarAnalyzer('vdoty.dV = cada1td1;',vdoty,'vdoty',1);
        if ~exist('vdoty','var'); vdoty = cadastruct([],'vdoty',[],0); end
        vdoty.f = cada1f2./cada1f3;
        vdoty = adigatorVarAnalyzer('vdoty.f = cada1f2./cada1f3;',vdoty,'vdoty',1);
        adigatorVarAnalyzer('%User Line: vdoty  = -mu*ry./r.^3;');
        cada1f1 = uminus(mu.f);
        cada1f1 = adigatorVarAnalyzer('cada1f1 = uminus(mu.f);',cada1f1,'cada1f1',0);
        cada1f2dV = cada1f1.*rz.dV;
        cada1f2dV = adigatorVarAnalyzer('cada1f2dV = cada1f1.*rz.dV;',cada1f2dV,'cada1f2dV',0);
        cada1f2 = cada1f1*rz.f;
        cada1f2 = adigatorVarAnalyzer('cada1f2 = cada1f1*rz.f;',cada1f2,'cada1f2',0);
        cada1tf2 = r.f(:,Gator1Data.Index299);
        cada1tf2 = adigatorVarAnalyzer('cada1tf2 = r.f(:,Gator1Data.Index299);',cada1tf2,'cada1tf2',0);
        cada1f3dV = 3.*cada1tf2.^(3-1).*r.dV;
        cada1f3dV = adigatorVarAnalyzer('cada1f3dV = 3.*cada1tf2.^(3-1).*r.dV;',cada1f3dV,'cada1f3dV',0);
        cada1f3 = r.f.^3;
        cada1f3 = adigatorVarAnalyzer('cada1f3 = r.f.^3;',cada1f3,'cada1f3',0);
        cada1tf1 = cada1f3(:,Gator1Data.Index300);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f3(:,Gator1Data.Index300);',cada1tf1,'cada1tf1',0);
        cada1td1 = zeros(size(cada1f2dV,1),12);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(cada1f2dV,1),12);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index301) = cada1f2dV./cada1tf1;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index301) = cada1f2dV./cada1tf1;',cada1td1,'cada1td1',1);
        cada1tf1 = cada1f2(:,Gator1Data.Index302);
        cada1tf1 = adigatorVarAnalyzer('cada1tf1 = cada1f2(:,Gator1Data.Index302);',cada1tf1,'cada1tf1',0);
        cada1tf2 = cada1f3(:,Gator1Data.Index303);
        cada1tf2 = adigatorVarAnalyzer('cada1tf2 = cada1f3(:,Gator1Data.Index303);',cada1tf2,'cada1tf2',0);
        cada1td1 = cada1td1 + -cada1tf1./cada1tf2.^2.*cada1f3dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1 = cada1td1 + -cada1tf1./cada1tf2.^2.*cada1f3dV;',cada1td1,'cada1td1',0);
        if ~exist('vdotz','var'); vdotz = cadastruct([],'vdotz',[],0); end
        vdotz.dV = cada1td1;
        vdotz = adigatorVarAnalyzer('vdotz.dV = cada1td1;',vdotz,'vdotz',1);
        if ~exist('vdotz','var'); vdotz = cadastruct([],'vdotz',[],0); end
        vdotz.f = cada1f2./cada1f3;
        vdotz = adigatorVarAnalyzer('vdotz.f = cada1f2./cada1f3;',vdotz,'vdotz',1);
        adigatorVarAnalyzer('%User Line: vdotz  = -mu*rz./r.^3;');
        adigatorVarAnalyzer('%User Line: %dyna  = [rdotx,rdoty,rdotz,vdotx,vdoty,vdotz];');
        adigatorVarAnalyzer('%User Line: %dyna4 = [dyna4 dyna];');
        cada1td1 = zeros(size(rdotx.f,1),48);
        cada1td1 = adigatorVarAnalyzer('cada1td1 = zeros(size(rdotx.f,1),48);',cada1td1,'cada1td1',0);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index304) = rdotx.dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index304) = rdotx.dV;',cada1td1,'cada1td1',1);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index305) = rdoty.dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index305) = rdoty.dV;',cada1td1,'cada1td1',1);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index306) = rdotz.dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index306) = rdotz.dV;',cada1td1,'cada1td1',1);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index307) = vdotx.dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index307) = vdotx.dV;',cada1td1,'cada1td1',1);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index308) = vdoty.dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index308) = vdoty.dV;',cada1td1,'cada1td1',1);
        if ~exist('cada1td1','var'); cada1td1 = cadastruct([],'cada1td1',[],0); end
        cada1td1(:,Gator1Data.Index309) = vdotz.dV;
        cada1td1 = adigatorVarAnalyzer('cada1td1(:,Gator1Data.Index309) = vdotz.dV;',cada1td1,'cada1td1',1);
        cada1f1dV = cada1td1;
        cada1f1dV = adigatorVarAnalyzer('cada1f1dV = cada1td1;',cada1f1dV,'cada1f1dV',0);
        cada1f1 = [rdotx.f rdoty.f rdotz.f vdotx.f vdoty.f vdotz.f];
        cada1f1 = adigatorVarAnalyzer('cada1f1 = [rdotx.f rdoty.f rdotz.f vdotx.f vdoty.f vdotz.f];',cada1f1,'cada1f1',0);
        cada1f2 = i.f - 1;
        cada1f2 = adigatorVarAnalyzer('cada1f2 = i.f - 1;',cada1f2,'cada1f2',0);
        cada1f3 = cada1f2*6;
        cada1f3 = adigatorVarAnalyzer('cada1f3 = cada1f2*6;',cada1f3,'cada1f3',0);
        cada1f4 = Gator1Data.Data2 + cada1f3;
        cada1f4 = adigatorVarAnalyzer('cada1f4 = Gator1Data.Data2 + cada1f3;',cada1f4,'cada1f4',0);
        if ~exist('dyna4','var'); dyna4 = cadastruct([],'dyna4',[],0); end
        dyna4.dV(:,logical(Gator1Data.Index24(:,cadaforcount6))) = cada1f1dV(:,nonzeros(Gator1Data.Index24(:,cadaforcount6)));
        dyna4 = adigatorVarAnalyzer('dyna4.dV(:,logical(Gator1Data.Index24(:,cadaforcount6))) = cada1f1dV(:,nonzeros(Gator1Data.Index24(:,cadaforcount6)));',dyna4,'dyna4',1);
        if ~exist('dyna4','var'); dyna4 = cadastruct([],'dyna4',[],0); end
        dyna4.f(:,cada1f4) = cada1f1;
        dyna4 = adigatorVarAnalyzer('dyna4.f(:,cada1f4) = cada1f1;',dyna4,'dyna4',1);
        adigatorVarAnalyzer('%User Line: dyna4(:,(1:6)+(i-1)*6) = [rdotx,rdoty,rdotz,vdotx,vdoty,vdotz];');
    [adigatorForEvalStr, adigatorForEvalVar]= adigatorForIterEnd(6,adigatorForVariable6i);
    if ~isempty(adigatorForEvalStr)
        adigatorSetCellEvalFlag(1); cellfun(@eval,adigatorForEvalStr); adigatorSetCellEvalFlag(0);
    end
    end
    % ADiGator FOR Statement #6: END
    if ~exist('output','var'); output = cadastruct([],'output',[],0); end
    output(iphase.f).dynamics.dV = dyna4.dV;
    output = adigatorVarAnalyzer('output(iphase.f).dynamics.dV = dyna4.dV;',output,'output',1);
    if ~exist('output','var'); output = cadastruct([],'output',[],0); end
    output(iphase.f).dynamics.f = dyna4.f;
    output = adigatorVarAnalyzer('output(iphase.f).dynamics.f = dyna4.f;',output,'output',1);
    adigatorVarAnalyzer('%User Line: output(iphase).dynamics  = dyna4;');
[adigatorForEvalStr, adigatorForEvalVar]= adigatorForIterEnd(5,adigatorForVariable5i);
if ~isempty(adigatorForEvalStr)
    adigatorSetCellEvalFlag(1); cellfun(@eval,adigatorForEvalStr); adigatorSetCellEvalFlag(0);
end
end
% ADiGator FOR Statement #5: END
if ~exist('output','var'); output = cadastruct([],'output',[],0); end
output(1).dynamics.dV_size = [4,53];
output = adigatorVarAnalyzer('output(1).dynamics.dV_size = [4,53];',output,'output',1);
if ~exist('output','var'); output = cadastruct([],'output',[],0); end
output(1).dynamics.dV_location = Gator1Data.Index310;
output = adigatorVarAnalyzer('output(1).dynamics.dV_location = Gator1Data.Index310;',output,'output',1);
if ~exist('output','var'); output = cadastruct([],'output',[],0); end
output(2).dynamics.dV_size = [28,53];
output = adigatorVarAnalyzer('output(2).dynamics.dV_size = [28,53];',output,'output',1);
if ~exist('output','var'); output = cadastruct([],'output',[],0); end
output(2).dynamics.dV_location = Gator1Data.Index311;
output = adigatorVarAnalyzer('output(2).dynamics.dV_location = Gator1Data.Index311;',output,'output',1);
if ~exist('output','var'); output = cadastruct([],'output',[],0); end
output(2).path.dV_size = [4,53];
output = adigatorVarAnalyzer('output(2).path.dV_size = [4,53];',output,'output',1);
if ~exist('output','var'); output = cadastruct([],'output',[],0); end
output(2).path.dV_location = Gator1Data.Index312;
output = adigatorVarAnalyzer('output(2).path.dV_location = Gator1Data.Index312;',output,'output',1);
if ~exist('output','var'); output = cadastruct([],'output',[],0); end
output(3).dynamics.dV_size = [4,53];
output = adigatorVarAnalyzer('output(3).dynamics.dV_size = [4,53];',output,'output',1);
if ~exist('output','var'); output = cadastruct([],'output',[],0); end
output(3).dynamics.dV_location = Gator1Data.Index313;
output = adigatorVarAnalyzer('output(3).dynamics.dV_location = Gator1Data.Index313;',output,'output',1);
if ~exist('output','var'); output = cadastruct([],'output',[],0); end
output(4).dynamics.dV_size = [28,53];
output = adigatorVarAnalyzer('output(4).dynamics.dV_size = [28,53];',output,'output',1);
if ~exist('output','var'); output = cadastruct([],'output',[],0); end
output(4).dynamics.dV_location = Gator1Data.Index314;
output = adigatorVarAnalyzer('output(4).dynamics.dV_location = Gator1Data.Index314;',output,'output',1);
if ~exist('output','var'); output = cadastruct([],'output',[],0); end
output(4).path.dV_size = [4,53];
output = adigatorVarAnalyzer('output(4).path.dV_size = [4,53];',output,'output',1);
if ~exist('output','var'); output = cadastruct([],'output',[],0); end
output(4).path.dV_location = Gator1Data.Index315;
output = adigatorVarAnalyzer('output(4).path.dV_location = Gator1Data.Index315;',output,'output',1);
if ~exist('output','var'); output = cadastruct([],'output',[],0); end
output(5).dynamics.dV_size = [24,53];
output = adigatorVarAnalyzer('output(5).dynamics.dV_size = [24,53];',output,'output',1);
if ~exist('output','var'); output = cadastruct([],'output',[],0); end
output(5).dynamics.dV_location = Gator1Data.Index316;
output = adigatorVarAnalyzer('output(5).dynamics.dV_location = Gator1Data.Index316;',output,'output',1);
adigatorOutputs = {output};
[adigatorFunInfo, adigatorOutputs] = adigatorFunctionEnd(1,adigatorFunInfo,adigatorOutputs);
