function funcstr = cadastructname(VarID,refstr)
% Get function string of an object and a flag stating whether or not we
% need to calculate derivatives.
%
% Copyright 2011-2014 Matthew J. Weinstein and Anil V. Rao
% Distributed under the GNU General Public License version 3.0
global ADIGATOR

if ADIGATOR.PRINT.FLAG
  if ADIGATOR.DERNUMBER == 1
    if isinf(ADIGATOR.VARINFO.NAMELOCS(VarID,3)) || ...
        any(ADIGATOR.VARINFO.NAMELOCS(ADIGATOR.VARINFO.NAMELOCS(VarID,1)...
        ==ADIGATOR.VARINFO.NAMELOCS(:,1),3) == -Inf)
      funcstr = refstr;
    elseif ADIGATOR.VARINFO.NAMELOCS(VarID,2) < 0
      funcstr = refstr;
    else
      funcstr = [refstr,'.f'];
    end
  else
    funcstr = refstr;
  end
else
  funcstr = sprintf('f%1.0d',VarID);
end

end