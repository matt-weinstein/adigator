function [val, name, id, arrayflag] = cadastructDecomp(x)

val = x.val;
name = x.name;
id = x.id;
arrayflag = x.arrayflag;