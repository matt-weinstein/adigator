function y = numel(varargin)
y = 1;
end