function aflag = cadaIsArray(x)

aflag = x.arrayflag;