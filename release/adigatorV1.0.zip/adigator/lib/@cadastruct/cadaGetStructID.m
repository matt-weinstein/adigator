function val = cadaGetStructID(y)
val = y.id;
end