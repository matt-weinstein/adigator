function y = acscd(x)
% CADA overloaded ACSCD function: calls cadaunarymath
y = cadaunarymath(x,0,'acscd');