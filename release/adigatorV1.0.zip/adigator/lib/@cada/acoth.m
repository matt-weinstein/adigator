function y = acoth(x)
% CADA overloaded ACOTH function: calls cadaunarymath
y = cadaunarymath(x,0,'acoth');