function y = asech(x)
% CADA overloaded ASECH function: calls cadaunarymath
y = cadaunarymath(x,0,'asech');