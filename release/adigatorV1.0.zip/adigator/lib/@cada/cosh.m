function y = cosh(x)
% CADA overloaded COSH function: calls cadaunarymath
y = cadaunarymath(x,0,'cosh');