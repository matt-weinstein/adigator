function z = rem(x,y)
% CADA overloaded REM function: calls cadabinaryarraymath
z = cadabinaryarraymath(x,y,1,0,'rem');