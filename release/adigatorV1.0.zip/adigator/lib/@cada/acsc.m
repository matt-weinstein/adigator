function y = acsc(x)
% CADA overloaded ACSC function: calls cadaunarymath
y = cadaunarymath(x,0,'acsc');