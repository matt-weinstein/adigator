function x = adigatorFindCellStruc(x,xStr,structflag)
%function x = adigatorFindCellStruc(x,xStr)
% This routine recursively calls itself to find numeric and/or overloaded
% objects which are embedded within cells and/or structures.
% --------------------------- Input Information ------------------------- %
% x:    the cell or structure
% xStr: the user defined string name of the cell/structure
% -------------------------- Output Information ------------------------- %
% x:    the cell or structure with all of its old numeric fields now
%       overloaded
%
% Copyright 2011-214 Matthew J. Weinstein and Anil V. Rao
% Distributed under the GNU General Public License version 3.0
global ADIGATOR
ADIGATOR.VARINFO.LASTOCC(x.id,1) = ADIGATOR.VARINFO.COUNT;
x.id = ADIGATOR.VARINFO.COUNT;
if ~structflag
  if ~ADIGATOR.RUNFLAG
    % ------------------------------------------------------------------- %
    %                            Empty Run                                %
    % ------------------------------------------------------------------- %
    % Set VarName
    adigatorAssignImpVarNames(ADIGATOR.VARINFO.COUNT,xStr,0);
    if ADIGATOR.VARINFO.NAMELOCS(x.id,3) == inf
      ADIGATOR.VARINFO.NAMELOCS(ADIGATOR.VARINFO.COUNT,3) = inf;
    elseif ADIGATOR.VARINFO.NAMELOCS(x.id,3) == -inf
      ADIGATOR.VARINFO.NAMELOCS(ADIGATOR.VARINFO.COUNT,3) = -inf;
    end
    if ADIGATOR.VARINFO.NAMELOCS(x.id,2) < 0
      ADIGATOR.VARINFO.NAMELOCS(ADIGATOR.VARINFO.COUNT,2) = ADIGATOR.VARINFO.NAMELOCS(x.id,2);
    end
    ADIGATOR.VARINFO.LASTOCC(ADIGATOR.VARINFO.COUNT,1) = ...
      ADIGATOR.VARINFO.COUNT;
  elseif ADIGATOR.RUNFLAG == 1
    % ------------------------------------------------------------------- %
    %                           OverMap Run                               %
    % ------------------------------------------------------------------- %
    % x is Overloaded
    OverOp = x.id;
    x.id   = ADIGATOR.VARINFO.COUNT;
    x      = cadaOverMap(x,OverOp);
  else
    % ------------------------------------------------------------------- %
    %                           Printing Run                              %
    % ------------------------------------------------------------------- %
    % x is overloaded
    xOp   = ADIGATOR.VARINFO.COUNT;
    oldID = x.id;
    x.id  = xOp;
    
    if isinf(ADIGATOR.VARINFO.NAMELOCS(oldID,2))
      ADIGATOR.VARINFO.NAMELOCS(xOp,2) = Inf;
      ADIGATOR.VARINFO.NAMELOCS(xOp,3) = ADIGATOR.VARINFO.NAMELOCS(oldID,3);
    end
    x           = cadaOverMap(x);
    funcname    = cadafuncname(xOp);
    x.func.name = funcname;
    for Vcount = 1:ADIGATOR.NVAROFDIFF
      if ~isempty(x.deriv(Vcount).name)
        x.deriv(Vcount).name = cadadername(funcname,Vcount);
      end
    end
    ADIGATOR.VARINFO.LASTOCC(ADIGATOR.VARINFO.COUNT,1) = ...
      ADIGATOR.VARINFO.COUNT;
  end
  ADIGATOR.VARINFO.COUNT = ADIGATOR.VARINFO.COUNT+1;
end
return
end