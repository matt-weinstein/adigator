function y = logical(x)
% CADA overloaded version of function LOGICAL - calls cadaunarylogical  
y = cadaunarylogical(x,'logical',0);