function y = erf(x)
% CADA overloaded ERF function: calls cadaunarymath
y = cadaunarymath(x,1,'erf');