function z = minus(x,y)
% CADA overloaded MINUS function: calls cadabinaryarraymath
z = cadabinaryarraymath(x,y,0,0,'minus');