function y = sin(x)
% CADA overloaded SIN function: calls cadaunarymath
y = cadaunarymath(x,1,'sin');