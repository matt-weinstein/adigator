function y = nan(varargin)
% CADA overloaded version of function NAN.
y = cadacreatearray('nan',varargin);