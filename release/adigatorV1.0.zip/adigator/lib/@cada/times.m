function z = times(x,y)
% CADA overloaded TIMES function: calls cadabinaryarraymath
z = cadabinaryarraymath(x,y,1,1,'times');