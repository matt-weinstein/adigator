function y = false(varargin)
% CADA overloaded version of function FALSE
y = cadacreatearray('false',varargin);