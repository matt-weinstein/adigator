function y = sqrt(x)
% CADA overloaded SQRT function: calls cadaunarymath
y = cadaunarymath(x,1,'sqrt');