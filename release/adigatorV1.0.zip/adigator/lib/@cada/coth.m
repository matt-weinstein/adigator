function y = coth(x)
% CADA overloaded COTH function: calls cadaunarymath
y = cadaunarymath(x,0,'coth');