
n = 3;
m = n;

nd = ceil(m*n*.5);

I = randi(m,nd,1);
J = randi(n,nd,1);
a = rand(nd,1);

x = rand(m,1)+1;




tic
for i = 1:100
  tf1 = prod(x);
  dy = tf1./x(I).*a;
end
toc

II = repmat((1:m).',1,m);
II(logical(eye(m))) = [];
II = reshape(II,m,m-1);
tic
for i = 1:100
  tf1 = prod(x);
  tf2 = prod(x(II),2);
  keyboard
end
toc


