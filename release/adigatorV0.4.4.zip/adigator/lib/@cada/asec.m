function y = asec(x)
% CADA overloaded ASEC function: calls cadaunarymath
y = cadaunarymath(x,0,'asec');