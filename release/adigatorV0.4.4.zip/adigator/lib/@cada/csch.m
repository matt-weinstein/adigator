function y = csch(x)
% CADA overloaded CSCH function: calls cadaunarymath
y = cadaunarymath(x,0,'csch');