function z = xor(x,y)
% CADA overloaded version of function XOR - calls cadabinarylogical
z = cadabinarylogical(x,y,'xor');