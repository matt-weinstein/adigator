function y = secd(x)
% CADA overloaded SECD function: calls cadaunarymath
y = cadaunarymath(x,0,'secd');