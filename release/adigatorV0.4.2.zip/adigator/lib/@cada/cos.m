function y = cos(x)
% CADA overloaded COS function: calls cadaunarymath
y = cadaunarymath(x,0,'cos');