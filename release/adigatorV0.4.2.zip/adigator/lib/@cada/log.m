function y = log(x)
% CADA overloaded LOG function: calls cadaunarymath
y = cadaunarymath(x,0,'log');