function y = acotd(x)
% CADA overloaded ACOTD function: calls cadaunarymath
y = cadaunarymath(x,0,'acotd');