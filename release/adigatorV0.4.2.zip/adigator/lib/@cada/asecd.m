function y = asecd(x)
% CADA overloaded ASECD function: calls cadaunarymath
y = cadaunarymath(x,0,'asecd');