function z = or(x,y)
% CADA overloaded version of function OR - calls cadabinarylogical
z = cadabinarylogical(x,y,'or');