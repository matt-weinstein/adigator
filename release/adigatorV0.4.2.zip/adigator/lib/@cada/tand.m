function y = tand(x)
% CADA overloaded TAND function: calls cadaunarymath
y = cadaunarymath(x,1,'tand');