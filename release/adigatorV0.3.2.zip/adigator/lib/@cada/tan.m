function y = tan(x)
% CADA overloaded TAN function: calls cadaunarymath
y = cadaunarymath(x,1,'tan');