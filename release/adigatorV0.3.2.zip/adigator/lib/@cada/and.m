function z = and(x,y)
% CADA overloaded version of function AND - calls cadabinarylogical
z = cadabinarylogical(x,y,'and');