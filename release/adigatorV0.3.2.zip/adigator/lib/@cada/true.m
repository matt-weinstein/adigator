function y = true(varargin)
% CADA overloaded version of function TRUE
y = cadacreatearray('true',varargin);