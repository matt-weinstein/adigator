function y = sec(x)
% CADA overloaded SEC function: calls cadaunarymath
y = cadaunarymath(x,0,'sec');