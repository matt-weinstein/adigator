function y = not(x)
% CADA overloaded version of function NOT - calls cadaunarylogical  
y = cadaunarylogical(x,'not',0);