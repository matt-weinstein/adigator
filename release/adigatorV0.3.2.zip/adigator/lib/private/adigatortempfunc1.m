function [adigatorFunInfo, adigatorOutputs] = adigatortempfunc1(adigatorFunInfo,adigatorInputs)
[flag, adigatorFunInfo, adigatorInputs] = adigatorFunctionInitialize(1,adigatorFunInfo,adigatorInputs);
if flag; adigatorOutputs = adigatorInputs; return; end;
t = adigatorInputs{1};
x = adigatorInputs{2};
p = adigatorInputs{3};
q = adigatorInputs{4};
rwh = adigatorInputs{5};
iwh = adigatorInputs{6};
% ADiGator IF Statement #1: START
cadaconditional1 = (iwh(3) == 0 | iwh(3) == 1);
cadaconditional1 = adigatorVarAnalyzer('cadaconditional1 = (iwh(3) == 0 | iwh(3) == 1)',cadaconditional1,'cadaconditional1',0);
cadaconditional2 = (iwh(3) == 2 | iwh(3) == 3);
cadaconditional2 = adigatorVarAnalyzer('cadaconditional2 = (iwh(3) == 2 | iwh(3) == 3)',cadaconditional2,'cadaconditional2',0);
adigatorIfInitialize(1,cadaconditional1,cadaconditional2);
adigatorIfIterStart(1,1);
    Tc = q(iwh(2)+iwh(4)-1);
    Tc = adigatorVarAnalyzer('Tc = q(iwh(2)+iwh(4)-1);',Tc,'Tc',0);
adigatorIfIterEnd(1,1);
[adigatorIfEvalStr, adigatorIfEvalVar] = adigatorIfIterStart(1,2);%#ok<NASGU>
if ~isempty(adigatorIfEvalStr); cellfun(@eval,adigatorIfEvalStr); end
    Tc = q(iwh(2)+2*iwh(4)-2) + (t-rwh(2))*q(iwh(2)+2*iwh(4)-1);
    Tc = adigatorVarAnalyzer('Tc = q(iwh(2)+2*iwh(4)-2) + (t-rwh(2))*q(iwh(2)+2*iwh(4)-1);',Tc,'Tc',0);
[adigatorIfEvalStr, adigatorIfEvalVar] = adigatorIfIterEnd(1,2);%#ok<NASGU>
if ~isempty(adigatorIfEvalStr); cellfun(@eval,adigatorIfEvalStr); end
% ADiGator IF Statement #1: END
k0 = p([1 3])' .* [1e-2; 0.1];
k0 = adigatorVarAnalyzer('k0 = p([1 3])'' .* [1e-2; 0.1];',k0,'k0',0);
EA = p([2 4])' .* [60000; 40000];
EA = adigatorVarAnalyzer('EA = p([2 4])'' .* [60000; 40000];',EA,'EA',0);
lambda = p(5) * 0.25;
lambda = adigatorVarAnalyzer('lambda = p(5) * 0.25;',lambda,'lambda',0);
M = [0.1362 0.09806 0 0.236];
M = adigatorVarAnalyzer('M = [0.1362 0.09806 0 0.236];',M,'M',0);
M(3) = M(1) + M(2);
M = adigatorVarAnalyzer('M(3) = M(1) + M(2);',M,'M',1);
Temp = Tc + 273.0;
Temp = adigatorVarAnalyzer('Temp = Tc + 273.0;',Temp,'Temp',0);
Rg = 8.314;
Rg = adigatorVarAnalyzer('Rg = 8.314;',Rg,'Rg',0);
T1 = 293.0;
T1 = adigatorVarAnalyzer('T1 = 293.0;',T1,'T1',0);
k = k0 .* exp(-(EA./Rg) .* (1/Temp - 1/T1));
k = adigatorVarAnalyzer('k = k0 .* exp(-(EA./Rg) .* (1/Temp - 1/T1));',k,'k',0);
r1 = (k(1) + k(2) * q(4) * exp(-lambda * t)) * x(1) * x(2) ./ (M*x');
r1 = adigatorVarAnalyzer('r1 = (k(1) + k(2) * q(4) * exp(-lambda * t)) * x(1) * x(2) ./ (M*x'');',r1,'r1',0);
f = [-r1 -r1 r1 0];
f = adigatorVarAnalyzer('f = [-r1 -r1 r1 0];',f,'f',0);
iflag = 0;
iflag = adigatorVarAnalyzer('iflag = 0;',iflag,'iflag',0);
adigatorOutputs = {f;iflag};
[adigatorFunInfo, adigatorOutputs] = adigatorFunctionEnd(1,adigatorFunInfo,adigatorOutputs);
