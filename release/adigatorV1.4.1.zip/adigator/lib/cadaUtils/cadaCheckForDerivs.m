function flag = cadaCheckForDerivs(x)
% Dummy routine for non-overloaded variables, just returns false
%
% Copyright 2011-2014 Matthew J. Weinstein and Anil V. Rao
% Distributed under the GNU General Public License version 3.0

flag = false;

end