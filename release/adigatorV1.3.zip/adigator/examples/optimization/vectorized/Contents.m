% ADiGator direct collocation (vectorized) example problems
%
% Copyright 2011-2015 Matthew J. Weinstein and Anil V. Rao
% Distributed under the GNU General Public License version 3.0
%
% ----------------------------------------------------------------------- %
% DIRECTORIES:
% brachistochrone  - classical brachistochrone problem
% minimumclimb     - minimum time to climb of supersonic aircraft