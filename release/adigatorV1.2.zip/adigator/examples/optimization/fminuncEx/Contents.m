% ADiGator unconstrained minimization example
%
% Copyright 2011-2015 Matthew J. Weinstein and Anil V. Rao
% Distributed under the GNU General Public License version 3.0
%
% ----------------------------------------------------------------------- %
% FILES:
% brownf.m  - brown objective function
% main.m    - solves optimization problem using ADiGator derivatives and
%             fminunc