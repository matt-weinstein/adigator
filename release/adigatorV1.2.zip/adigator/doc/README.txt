ADiGator Version 1.2

A Source Transformation via Operator Overloading Tool for the Automatic Differentiation of Mathematical Functions Defined by MATLAB Code

Please see ADiGatorUserGuide.pdf for User's Guide.

Copyright 2011-2014 Matthew J. Weinstein and Anil V. Rao
Distributed under the GNU General Public License version 3.0
Please see COPYING.txt for full License.

Contact Info:
weinstein87@gmail.com