function s = num2str(x)
% CADA overloaded version of function NUM2STR.
%
% Copyright 2011-2014 Matthew J. Weinstein and Anil V. Rao
% Distributed under the GNU General Public License version 3.0

s = num2str(x.func.value);