function y = atan(x)
% CADA overloaded ATAN function: calls cadaunarymath
y = cadaunarymath(x,1,'atan');