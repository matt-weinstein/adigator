function y = real(x)
% CADA overloaded REAL function: calls cadaunarymath
y = cadaunarymath(x,1,'real');