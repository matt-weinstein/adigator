function y = zeros(varargin)
% CADA overloaded version of function ZEROS.
y = cadacreatearray('zeros',varargin);