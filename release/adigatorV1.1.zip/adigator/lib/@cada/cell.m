function y = cell(varargin)
% CADA overloaded version of function CELL.
y = cadacreatearray('cell',varargin);