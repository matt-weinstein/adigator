function y = cosd(x)
% CADA overloaded COSD function: calls cadaunarymath
y = cadaunarymath(x,0,'cosd');