function y = acosd(x)
% CADA overloaded ACOSD function: calls cadaunarymath
y = cadaunarymath(x,0,'acosd');