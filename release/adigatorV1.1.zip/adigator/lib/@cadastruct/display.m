function display(x)


fprintf('    id:')
disp(x.id)
fprintf('    name:');
disp(x.name)
fprintf('\n    val:\n');
disp(x.val)
fprintf('    arrayflag: ');
disp(x.arrayflag)