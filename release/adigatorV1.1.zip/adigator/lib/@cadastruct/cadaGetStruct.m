function val = cadaGetStruct(y)
val = y.val;
end