function y = sinh(x)
% CADA overloaded SINH function: calls cadaunarymath
y = cadaunarymath(x,1,'sinh');