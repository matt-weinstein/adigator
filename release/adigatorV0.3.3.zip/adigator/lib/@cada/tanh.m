function y = tanh(x)
% CADA overloaded TANH function: calls cadaunarymath
y = cadaunarymath(x,1,'tanh');