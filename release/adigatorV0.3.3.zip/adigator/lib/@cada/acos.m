function y = acos(x)
% CADA overloaded ACOS function: calls cadaunarymath
y = cadaunarymath(x,0,'acos');