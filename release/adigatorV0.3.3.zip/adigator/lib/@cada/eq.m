function z = eq(x,y)
% CADA overloaded version of function EQ - calls cadabinarylogical
z = cadabinarylogical(x,y,'eq');