function y = cot(x)
% CADA overloaded COT function: calls cadaunarymath
y = cadaunarymath(x,0,'cot');