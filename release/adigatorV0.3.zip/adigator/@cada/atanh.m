function y = atanh(x)
% CADA overloaded ATANH function: calls cadaunarymath
y = cadaunarymath(x,1,'atanh');