function y = ones(varargin)
% CADA overloaded version of function ONES
y = cadacreatearray('ones',varargin);