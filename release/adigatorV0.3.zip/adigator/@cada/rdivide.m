function z = rdivide(x,y)
% CADA overloaded RDIVIDE function: calls cadabinaryarraymath
z = cadabinaryarraymath(x,y,1,0,'rdivide');