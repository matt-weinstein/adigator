function y = eye(varargin)
% CADA overloaded version of function EYE
y = cadacreatearray('eye',varargin);