function y = uminus(x)
% CADA overloaded UMINUS function: calls cadaunarymath
y = cadaunarymath(x,1,'uminus');