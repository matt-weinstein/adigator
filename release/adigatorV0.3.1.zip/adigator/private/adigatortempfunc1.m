function [adigatorFunInfo, adigatorOutputs] = adigatortempfunc1(adigatorFunInfo,adigatorInputs)
[flag, adigatorFunInfo, adigatorInputs] = adigatorFunctionInitialize(1,adigatorFunInfo,adigatorInputs);
if flag; adigatorOutputs = adigatorInputs; return; end;
x = adigatorInputs{1};
adigatorVarAnalyzer('% Copyright 2011-2014 Matthew J. Weinstein and Anil V. Rao');
adigatorVarAnalyzer('% Distributed under the GNU General Public License version 3.0');
N = length(x);
N = adigatorVarAnalyzer('N = length(x);',N,'N',0);
y = zeros(N,1);
y = adigatorVarAnalyzer('y = zeros(N,1);',y,'y',0);
y(1) = 2*x(1)^2+sum(x.^2);
y = adigatorVarAnalyzer('y(1) = 2*x(1)^2+sum(x.^2);',y,'y',1);
y(2:N) = x(1)^2+x(2:N).^2;
y = adigatorVarAnalyzer('y(2:N) = x(1)^2+x(2:N).^2;',y,'y',1);
adigatorOutputs = {y};
[adigatorFunInfo, adigatorOutputs] = adigatorFunctionEnd(1,adigatorFunInfo,adigatorOutputs);
