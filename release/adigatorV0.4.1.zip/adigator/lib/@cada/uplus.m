function y = uplus(x)
% CADA overloaded UPLUS function: calls cadaunarymath
y = cadaunarymath(x,1,'uplus');