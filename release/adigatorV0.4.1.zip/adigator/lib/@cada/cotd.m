function y = cotd(x)
% CADA overloaded COTD function: calls cadaunarymath
y = cadaunarymath(x,0,'cotd');