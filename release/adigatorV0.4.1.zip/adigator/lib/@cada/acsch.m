function y = acsch(x)
% CADA overloaded ACSCH function: calls cadaunarymath
y = cadaunarymath(x,0,'acsch');