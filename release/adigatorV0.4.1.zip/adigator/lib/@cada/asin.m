function y = asin(x)
% CADA overloaded ASIN function: calls cadaunarymath
y = cadaunarymath(x,1,'asin');