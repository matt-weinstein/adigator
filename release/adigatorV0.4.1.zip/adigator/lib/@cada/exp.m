function y = exp(x)
% CADA overloaded EXP function: calls cadaunarymath
y = cadaunarymath(x,0,'exp');