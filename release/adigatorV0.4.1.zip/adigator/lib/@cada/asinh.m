function y = asinh(x)
% CADA overloaded ASINH function: calls cadaunarymath
y = cadaunarymath(x,1,'asinh');