function z = atan2(x,y)
% CADA overloaded ATAN2 function: calls cadabinaryarraymath
z = cadabinaryarraymath(x,y,1,1,'atan2');