function y = acot(x)
% CADA overloaded ACOT function: calls cadaunarymath
y = cadaunarymath(x,0,'acot');