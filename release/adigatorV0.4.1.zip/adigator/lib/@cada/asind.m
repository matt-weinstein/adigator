function y = asind(x)
% CADA overloaded ASIND function: calls cadaunarymath
y = cadaunarymath(x,1,'asind');