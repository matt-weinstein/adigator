function y = abs(x)
% CADA overloaded ABS function: calls cadaunarymath
y = cadaunarymath(x,1,'abs');