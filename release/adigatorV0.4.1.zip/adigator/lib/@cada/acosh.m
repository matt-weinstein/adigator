function y = acosh(x)
% CADA overloaded ACOSH function: calls cadaunarymath
y = cadaunarymath(x,0,'acosh');